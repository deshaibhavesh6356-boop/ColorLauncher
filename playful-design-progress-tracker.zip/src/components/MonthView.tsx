"use client";

import { useEffect, useMemo, useState } from "react";
import { addMonths, hourLabel, monthStr, prettyMonth, toDateStr } from "@/lib/date";
import type { MonthStats, Settings } from "@/lib/types";

const pad = (n: number) => String(n).padStart(2, "0");

function cellColor(count: number, goal: number) {
  if (count === 0) return "#ffffff";
  const r = count / goal;
  if (r < 0.34) return "#ffe0ec";
  if (r < 0.67) return "#ffb3cf";
  if (r < 1) return "#ffd93d";
  return "#6bcb77";
}

export default function MonthView({
  settings,
  onPickDay,
}: {
  settings: Settings;
  onPickDay: (d: string) => void;
}) {
  const [month, setMonth] = useState(() => monthStr(new Date()));
  const [stats, setStats] = useState<MonthStats | null>(null);
  const [loadedMonth, setLoadedMonth] = useState<string | null>(null);

  useEffect(() => {
    let cancelled = false;
    fetch(`/api/stats?month=${month}`, { cache: "no-store" })
      .then((r) => r.json())
      .then((d: MonthStats) => {
        if (cancelled) return;
        setStats(d);
        setLoadedMonth(month);
      });
    return () => {
      cancelled = true;
    };
  }, [month]);

  const loading = loadedMonth !== month;
  const [y, mo] = month.split("-").map(Number);
  const daysInMonth = new Date(y, mo, 0).getDate();
  const firstWeekday = new Date(y, mo - 1, 1).getDay();
  const todayStr = toDateStr(new Date());

  const summary = useMemo(() => {
    const days = stats?.days ?? {};
    let total = 0;
    let active = 0;
    let goalDays = 0;
    let bestDay: { d: number; c: number } | null = null;
    let streak = 0;
    let longest = 0;
    for (let d = 1; d <= daysInMonth; d++) {
      const c = days[`${month}-${pad(d)}`] ?? 0;
      total += c;
      if (c > 0) active++;
      if (c >= settings.dailyGoal) {
        goalDays++;
        streak++;
        longest = Math.max(longest, streak);
      } else streak = 0;
      if (c > 0 && (!bestDay || c > bestDay.c)) bestDay = { d, c };
    }
    return { total, active, goalDays, bestDay, longest, avg: active ? total / active : 0 };
  }, [stats, month, daysInMonth, settings.dailyGoal]);

  const hourBars = useMemo(() => {
    const by = stats?.byHour ?? {};
    const set = new Set<number>();
    for (let h = settings.startHour; h < settings.endHour; h++) set.add(h);
    Object.keys(by).forEach((h) => set.add(Number(h)));
    const list = Array.from(set)
      .sort((a, b) => a - b)
      .map((h) => ({ h, c: by[String(h)] ?? 0 }));
    const max = Math.max(1, ...list.map((x) => x.c));
    const top = list.reduce<{ h: number; c: number } | null>(
      (b, x) => (x.c > 0 && (!b || x.c > b.c) ? x : b),
      null,
    );
    return { list, max, top };
  }, [stats, settings]);

  const blanks = Array.from({ length: firstWeekday });
  const monthGoal = settings.dailyGoal * daysInMonth;

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between gap-3">
        <button
          onClick={() => setMonth(addMonths(month, -1))}
          className="press chunky-sm h-11 w-11 rounded-full bg-white text-xl font-black"
          aria-label="Previous month"
        >
          ‹
        </button>
        <h2 className="chunky-sm rounded-2xl bg-white px-6 py-2 text-2xl font-black">
          📅 {prettyMonth(month)}
        </h2>
        <button
          onClick={() => setMonth(addMonths(month, 1))}
          className="press chunky-sm h-11 w-11 rounded-full bg-white text-xl font-black"
          aria-label="Next month"
        >
          ›
        </button>
      </div>

      <section className="chunky float-in rounded-[2rem] bg-[#ffb3cf] p-6 text-center sm:p-8">
        <div className="text-sm font-extrabold uppercase tracking-widest opacity-70">
          Designs completed this month
        </div>
        <div key={summary.total + month} className="pop text-7xl font-black leading-tight sm:text-8xl">
          {loading ? "…" : summary.total}
        </div>
        <div className="mx-auto mt-2 h-5 max-w-md overflow-hidden rounded-full border-[3px] border-[#2b1b4a] bg-white">
          <div
            className="h-full bg-[#6bcb77] transition-all duration-700"
            style={{ width: `${Math.min(100, (summary.total / monthGoal) * 100)}%` }}
          />
        </div>
        <div className="mt-1 text-xs font-bold opacity-70">
          {Math.round((summary.total / monthGoal) * 100)}% of the {monthGoal}-design monthly goal (
          {settings.dailyGoal}/day)
        </div>
      </section>

      <div className="grid grid-cols-2 gap-3 md:grid-cols-4">
        <Stat emoji="🗓️" label="Active days" value={String(summary.active)} bg="#d9e8ff" />
        <Stat emoji="📈" label="Avg / active day" value={summary.avg.toFixed(1)} bg="#fff1b8" />
        <Stat
          emoji="🏆"
          label="Best day"
          value={summary.bestDay ? `${summary.bestDay.c} (day ${summary.bestDay.d})` : "—"}
          bg="#d6f5dc"
        />
        <Stat
          emoji="🎯"
          label="Goal days"
          value={`${summary.goalDays}${summary.longest > 1 ? ` · ${summary.longest}🔥 streak` : ""}`}
          bg="#eadcff"
        />
      </div>

      {/* calendar */}
      <section className="chunky rounded-3xl bg-white/70 p-4">
        <div className="mb-2 grid grid-cols-7 gap-2 text-center text-xs font-black uppercase text-purple-500">
          {["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"].map((d) => (
            <div key={d}>{d}</div>
          ))}
        </div>
        <div className="grid grid-cols-7 gap-1.5 sm:gap-2">
          {blanks.map((_, i) => (
            <div key={`b${i}`} />
          ))}
          {Array.from({ length: daysInMonth }, (_, i) => i + 1).map((d) => {
            const key = `${month}-${pad(d)}`;
            const c = stats?.days[key] ?? 0;
            const isToday = key === todayStr;
            return (
              <button
                key={d}
                onClick={() => onPickDay(key)}
                title={`${c} designs — click to open`}
                style={{ background: cellColor(c, settings.dailyGoal) }}
                className={`press chunky-sm relative flex aspect-square flex-col items-center justify-center rounded-xl sm:rounded-2xl ${
                  isToday ? "ring-4 ring-[#b388ff]" : ""
                }`}
              >
                <span className="absolute left-1.5 top-0.5 text-[10px] font-extrabold opacity-60 sm:text-xs">
                  {d}
                </span>
                <span className="text-lg font-black leading-none sm:text-2xl">{c > 0 ? c : ""}</span>
                {c >= settings.dailyGoal && (
                  <span className="absolute bottom-0.5 right-1 text-xs sm:text-base">⭐</span>
                )}
              </button>
            );
          })}
        </div>
        <div className="mt-3 flex flex-wrap items-center justify-center gap-3 text-xs font-bold">
          <Legend color="#fff" label="0" />
          <Legend color="#ffe0ec" label="Getting started" />
          <Legend color="#ffb3cf" label="Cooking" />
          <Legend color="#ffd93d" label="Almost" />
          <Legend color="#6bcb77" label="Goal! ⭐" />
        </div>
      </section>

      {/* hours */}
      <section className="chunky rounded-3xl bg-[#d9e8ff] p-5">
        <h3 className="text-xl font-black">⏱️ Your power hours</h3>
        <p className="text-sm font-bold opacity-70">
          {hourBars.top
            ? `You're most productive at ${hourLabel(hourBars.top.h)} (${hourBars.top.c} designs this month). Schedule your best work then!`
            : "Log some hours and I'll find your most productive time of day."}
        </p>
        <div className="mt-4 flex h-40 items-end gap-1.5 sm:gap-2">
          {hourBars.list.map(({ h, c }) => (
            <div key={h} className="flex h-full flex-1 flex-col items-center justify-end">
              <span className="text-xs font-black">{c > 0 ? c : ""}</span>
              <div
                className="chunky-sm w-full rounded-t-lg transition-all duration-700"
                style={{
                  height: `${Math.max(4, (c / hourBars.max) * 100)}%`,
                  background: hourBars.top?.h === h ? "#ff6b9d" : "#b388ff",
                  maxHeight: "85%",
                }}
              />
              <span className="mt-1 text-[10px] font-extrabold sm:text-xs">
                {hourLabel(h).replace(" ", "")}
              </span>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
}

function Stat({ emoji, label, value, bg }: { emoji: string; label: string; value: string; bg: string }) {
  return (
    <div className="chunky-sm float-in rounded-2xl p-3" style={{ background: bg }}>
      <div className="text-2xl">{emoji}</div>
      <div className="text-[11px] font-extrabold uppercase tracking-wide opacity-70">{label}</div>
      <div className="text-xl font-black leading-tight">{value}</div>
    </div>
  );
}

function Legend({ color, label }: { color: string; label: string }) {
  return (
    <span className="flex items-center gap-1">
      <span className="inline-block h-4 w-4 rounded border-2 border-[#2b1b4a]" style={{ background: color }} />
      {label}
    </span>
  );
}
