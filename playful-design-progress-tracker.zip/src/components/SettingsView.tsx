"use client";

import { useState } from "react";
import { hourLabel } from "@/lib/date";
import type { Settings } from "@/lib/types";

export default function SettingsView({
  settings,
  onSaved,
}: {
  settings: Settings;
  onSaved: (s: Settings) => void;
}) {
  const [draft, setDraft] = useState<Settings>(settings);
  const [msg, setMsg] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  const save = async () => {
    setBusy(true);
    setMsg(null);
    const res = await fetch("/api/settings", {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(draft),
    });
    setBusy(false);
    if (res.ok) {
      onSaved(await res.json());
      setMsg("Saved! 🎉");
    } else {
      setMsg("Hmm, start must be before end and goal must be 1–99 🤔");
    }
  };

  const hoursOpts = Array.from({ length: 25 }, (_, h) => h);
  const selectCls = "chunky-sm w-full rounded-xl bg-white px-3 py-2 font-black outline-none";

  return (
    <div className="chunky float-in mx-auto max-w-xl space-y-6 rounded-[2rem] bg-[#d6f5dc] p-6 sm:p-8">
      <h2 className="text-3xl font-black">⚙️ Your design day</h2>

      <label className="block">
        <span className="font-extrabold">🎯 Daily goal (designs per day)</span>
        <div className="mt-2 flex items-center gap-3">
          <button
            onClick={() => setDraft({ ...draft, dailyGoal: Math.max(1, draft.dailyGoal - 1) })}
            className="press chunky-sm h-11 w-11 rounded-full bg-white text-xl font-black"
          >
            −
          </button>
          <input
            type="number"
            min={1}
            max={99}
            value={draft.dailyGoal}
            onChange={(e) => setDraft({ ...draft, dailyGoal: Number(e.target.value) })}
            className="chunky-sm w-24 rounded-xl bg-white px-3 py-2 text-center text-2xl font-black outline-none"
          />
          <button
            onClick={() => setDraft({ ...draft, dailyGoal: Math.min(99, draft.dailyGoal + 1) })}
            className="press chunky-sm h-11 w-11 rounded-full bg-[#ff6b9d] text-xl font-black text-white"
          >
            +
          </button>
        </div>
      </label>

      <div className="grid grid-cols-2 gap-4">
        <label className="block">
          <span className="font-extrabold">🌅 Start of day</span>
          <select
            className={`${selectCls} mt-2`}
            value={draft.startHour}
            onChange={(e) => setDraft({ ...draft, startHour: Number(e.target.value) })}
          >
            {hoursOpts.slice(0, 24).map((h) => (
              <option key={h} value={h}>
                {hourLabel(h)}
              </option>
            ))}
          </select>
        </label>
        <label className="block">
          <span className="font-extrabold">🌙 End of day</span>
          <select
            className={`${selectCls} mt-2`}
            value={draft.endHour}
            onChange={(e) => setDraft({ ...draft, endHour: Number(e.target.value) })}
          >
            {hoursOpts.slice(1).map((h) => (
              <option key={h} value={h}>
                {h === 24 ? "12 AM (midnight)" : hourLabel(h)}
              </option>
            ))}
          </select>
        </label>
      </div>

      <p className="text-sm font-bold opacity-70">
        You&apos;ll get one card per hour between these times —{" "}
        {Math.max(0, draft.endHour - draft.startHour)} slots to log your designs.
      </p>

      <div className="flex items-center gap-4">
        <button
          onClick={save}
          disabled={busy}
          className="press chunky rounded-full bg-[#ff6b9d] px-8 py-3 text-lg font-black text-white disabled:opacity-60"
        >
          {busy ? "Saving…" : "Save settings"}
        </button>
        {msg && <span className="font-extrabold">{msg}</span>}
      </div>
    </div>
  );
}
