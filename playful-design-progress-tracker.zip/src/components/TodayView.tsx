"use client";

import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import Confetti from "./Confetti";
import { addDays, hourLabel, prettyDate, toDateStr } from "@/lib/date";
import type { HourLog, Settings } from "@/lib/types";

type LogMap = Record<number, { count: number; note: string }>;

const CARD_COLORS = ["#ffe0ec", "#fff1b8", "#d6f5dc", "#d9e8ff", "#eadcff", "#ffe3c7"];

function mascot(pct: number, total: number) {
  if (total === 0) return { face: "😴", text: "Zzz… let's ship the first design!" };
  if (pct < 40) return { face: "🎨", text: "Warming up the pixels!" };
  if (pct < 80) return { face: "😎", text: "Smooth moves, designer!" };
  if (pct < 100) return { face: "🔥", text: "So close! One more push!" };
  if (pct < 150) return { face: "🤩", text: "GOAL SMASHED! You're a legend!" };
  return { face: "🦄", text: "Absolutely unstoppable!!" };
}

function Ring({ pct, children }: { pct: number; children: React.ReactNode }) {
  const r = 70;
  const c = 2 * Math.PI * r;
  const clamped = Math.min(100, pct);
  return (
    <div className="relative h-44 w-44 shrink-0">
      <svg viewBox="0 0 180 180" className="h-full w-full -rotate-90">
        <circle cx="90" cy="90" r={r} fill="#fff" stroke="#e7dcff" strokeWidth="18" />
        <circle
          cx="90"
          cy="90"
          r={r}
          fill="none"
          stroke={pct >= 100 ? "#35c76a" : "#ff6b9d"}
          strokeWidth="18"
          strokeLinecap="round"
          strokeDasharray={c}
          strokeDashoffset={c - (c * clamped) / 100}
          style={{ transition: "stroke-dashoffset 0.6s cubic-bezier(.3,1.6,.5,1), stroke 0.3s" }}
        />
      </svg>
      <div className="absolute inset-0 flex flex-col items-center justify-center">{children}</div>
    </div>
  );
}

export default function TodayView({
  settings,
  date,
  setDate,
}: {
  settings: Settings;
  date: string;
  setDate: (d: string) => void;
}) {
  const [logs, setLogs] = useState<LogMap>({});
  const [loading, setLoading] = useState(true);
  const [now, setNow] = useState<Date | null>(null);
  const [burst, setBurst] = useState(0);
  const [toast, setToast] = useState<string | null>(null);
  const [saving, setSaving] = useState(false);
  const [remind, setRemind] = useState(false);

  const logsRef = useRef<LogMap>({});
  const timers = useRef<Record<number, ReturnType<typeof setTimeout>>>({});
  const dateRef = useRef(date);
  const lastNotified = useRef<number>(-1);

  const today = now ? toDateStr(now) : date;
  const isToday = date === today;
  const currentHour = now ? now.getHours() : -1;

  // clock
  useEffect(() => {
    const tick = () => setNow(new Date());
    tick();
    const id = setInterval(tick, 15000);
    return () => clearInterval(id);
  }, []);

  // load logs for the day
  useEffect(() => {
    let cancelled = false;
    dateRef.current = date;
    setLoading(true);
    fetch(`/api/logs?date=${date}`, { cache: "no-store" })
      .then((r) => r.json())
      .then((data: { logs: HourLog[] }) => {
        if (cancelled) return;
        const map: LogMap = {};
        for (const l of data.logs) map[l.hour] = { count: l.count, note: l.note };
        logsRef.current = map;
        setLogs(map);
        setLoading(false);
      })
      .catch(() => !cancelled && setLoading(false));
    return () => {
      cancelled = true;
    };
  }, [date]);

  // hourly reminder
  useEffect(() => {
    setRemind(
      localStorage.getItem("dd-remind") === "1" &&
        typeof Notification !== "undefined" &&
        Notification.permission === "granted",
    );
  }, []);

  useEffect(() => {
    if (!remind || !now) return;
    if (now.getMinutes() === 0 && lastNotified.current !== now.getHours()) {
      lastNotified.current = now.getHours();
      new Notification("⏰ DesignDash", {
        body: `New hour! How many designs did you finish in the last hour?`,
      });
    }
  }, [now, remind]);

  const toggleRemind = async () => {
    if (remind) {
      localStorage.setItem("dd-remind", "0");
      setRemind(false);
      return;
    }
    if (typeof Notification === "undefined") {
      flash("Your browser doesn't support reminders 😢");
      return;
    }
    const perm = await Notification.requestPermission();
    if (perm === "granted") {
      localStorage.setItem("dd-remind", "1");
      setRemind(true);
      flash("Hourly reminders ON 🔔");
    } else {
      flash("Notifications are blocked in your browser");
    }
  };

  const flash = (msg: string) => {
    setToast(msg);
    setTimeout(() => setToast((t) => (t === msg ? null : t)), 2600);
  };

  const persist = useCallback(async (hour: number) => {
    const entry = logsRef.current[hour];
    if (!entry) return;
    setSaving(true);
    try {
      await fetch("/api/logs", {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ date: dateRef.current, hour, count: entry.count, note: entry.note }),
      });
    } finally {
      setSaving(false);
    }
  }, []);

  const schedule = useCallback(
    (hour: number, delay: number) => {
      clearTimeout(timers.current[hour]);
      timers.current[hour] = setTimeout(() => {
        delete timers.current[hour];
        void persist(hour);
      }, delay);
    },
    [persist],
  );

  const total = useMemo(() => Object.values(logs).reduce((s, l) => s + l.count, 0), [logs]);

  const update = (hour: number, patch: Partial<{ count: number; note: string }>, delay: number) => {
    const prevTotal = Object.values(logsRef.current).reduce((s, l) => s + l.count, 0);
    const cur = logsRef.current[hour] ?? { count: 0, note: "" };
    const next = { ...cur, ...patch };
    next.count = Math.max(0, Math.min(99, next.count));
    logsRef.current = { ...logsRef.current, [hour]: next };
    setLogs(logsRef.current);
    schedule(hour, delay);

    const newTotal = prevTotal - cur.count + next.count;
    if (prevTotal < settings.dailyGoal && newTotal >= settings.dailyGoal) {
      setBurst((b) => b + 1);
      flash("🎉 DAILY GOAL SMASHED! 🎉");
    } else if (patch.count !== undefined && patch.count > cur.count) {
      const cheers = ["Nice one! ✨", "Pixel perfect! 🎯", "Ka-ching! 💥", "Another one! 🚀", "Yesss! 🙌"];
      flash(cheers[Math.floor(Math.random() * cheers.length)]);
    }
  };

  // flush pending saves when leaving
  useEffect(() => {
    const t = timers.current;
    return () => {
      Object.entries(t).forEach(([h, id]) => {
        clearTimeout(id);
        delete t[Number(h)];
        void persist(Number(h));
      });
    };
  }, [persist, date]);

  const hours = useMemo(() => {
    const set = new Set<number>();
    for (let h = settings.startHour; h < settings.endHour; h++) set.add(h);
    for (const [h, l] of Object.entries(logs)) if (l.count > 0 || l.note) set.add(Number(h));
    return Array.from(set).sort((a, b) => a - b);
  }, [logs, settings]);

  const pct = Math.round((total / settings.dailyGoal) * 100);
  const m = mascot(pct, total);
  const activeHours = Object.values(logs).filter((l) => l.count > 0).length;
  const best = Object.entries(logs).reduce<{ h: number; c: number } | null>(
    (b, [h, l]) => (l.count > 0 && (!b || l.count > b.c) ? { h: Number(h), c: l.count } : b),
    null,
  );
  const minsLeft = now ? 60 - now.getMinutes() : 0;

  return (
    <div className="space-y-6">
      <Confetti burstId={burst} />
      {toast && (
        <div
          key={toast}
          className="toast chunky fixed bottom-6 left-1/2 z-50 rounded-full bg-[#ffd93d] px-6 py-3 text-lg font-extrabold"
        >
          {toast}
        </div>
      )}

      {/* date nav */}
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-2">
          <button
            onClick={() => setDate(addDays(date, -1))}
            className="press chunky-sm h-11 w-11 rounded-full bg-white text-xl font-black"
            aria-label="Previous day"
          >
            ‹
          </button>
          <div className="chunky-sm rounded-2xl bg-white px-4 py-2 text-center">
            <div className="text-lg font-black leading-tight">{prettyDate(date)}</div>
            <div className="text-xs font-bold text-purple-500">
              {isToday ? "✨ Today" : date > today ? "🔮 Future" : "🕰️ Past day"}
            </div>
          </div>
          <button
            onClick={() => setDate(addDays(date, 1))}
            className="press chunky-sm h-11 w-11 rounded-full bg-white text-xl font-black"
            aria-label="Next day"
          >
            ›
          </button>
          {!isToday && (
            <button
              onClick={() => setDate(today)}
              className="press chunky-sm rounded-full bg-[#b388ff] px-4 py-2 text-sm font-black text-white"
            >
              Back to today
            </button>
          )}
        </div>
        <button
          onClick={toggleRemind}
          className={`press chunky-sm rounded-full px-4 py-2 text-sm font-black ${
            remind ? "bg-[#6bcb77]" : "bg-white"
          }`}
        >
          {remind ? "🔔 Hourly reminder ON" : "🔕 Remind me every hour"}
        </button>
      </div>

      {/* hero summary */}
      <section className="chunky float-in flex flex-col items-center gap-6 rounded-[2rem] bg-[#c9b6ff] p-6 sm:flex-row sm:p-8">
        <Ring pct={pct}>
          <div key={total} className="pop text-6xl font-black leading-none">
            {total}
          </div>
          <div className="text-sm font-extrabold">of {settings.dailyGoal} designs</div>
        </Ring>
        <div className="flex-1 text-center sm:text-left">
          <div className="flex items-center justify-center gap-3 sm:justify-start">
            <span className="bounce-soft text-6xl">{m.face}</span>
            <h2 className="text-2xl font-black sm:text-3xl">{m.text}</h2>
          </div>
          <div className="mt-4 flex flex-wrap justify-center gap-3 sm:justify-start">
            <Chip label="Progress" value={`${pct}%`} bg="#ffd93d" />
            <Chip label="Active hours" value={String(activeHours)} bg="#ffb3cf" />
            <Chip
              label="Best hour"
              value={best ? `${hourLabel(best.h)} · ${best.c}` : "—"}
              bg="#a8e6b5"
            />
            <Chip
              label="Left to goal"
              value={total >= settings.dailyGoal ? "Done! 🏆" : String(settings.dailyGoal - total)}
              bg="#a9d0ff"
            />
          </div>
          <div className="mt-3 text-xs font-bold opacity-70">
            {saving ? "💾 Saving…" : "✅ All saved"}
          </div>
        </div>
      </section>

      {/* nudge for current hour */}
      {isToday && now && currentHour >= 0 && (
        <div className="chunky-sm wobble flex items-center gap-3 rounded-2xl bg-[#fff1b8] px-5 py-3 font-bold">
          <span className="text-2xl">⏰</span>
          <span>
            It&apos;s {hourLabel(currentHour)} — update this hour&apos;s count! Next hour starts in{" "}
            <b>{minsLeft} min</b>.
          </span>
        </div>
      )}

      {/* hour grid */}
      {loading ? (
        <div className="py-16 text-center text-xl font-black">
          <span className="bounce-soft inline-block text-5xl">🎨</span>
          <div>Mixing colors…</div>
        </div>
      ) : (
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {hours.map((h, i) => {
            const l = logs[h] ?? { count: 0, note: "" };
            const isNow = isToday && h === currentHour;
            const isPastEmpty = (isToday ? h < currentHour : date < today) && l.count === 0;
            return (
              <div
                key={h}
                style={{
                  background: l.count > 0 ? CARD_COLORS[h % CARD_COLORS.length] : "#fff",
                  animationDelay: `${i * 40}ms`,
                }}
                className={`chunky float-in relative rounded-3xl p-4 ${isNow ? "wobble ring-4 ring-[#ff6b9d]" : ""} ${
                  isPastEmpty ? "opacity-60" : ""
                }`}
              >
                {isNow && (
                  <span className="chunky-sm absolute -top-3 right-4 rounded-full bg-[#ff6b9d] px-3 py-0.5 text-xs font-black text-white">
                    NOW
                  </span>
                )}
                <div className="flex items-baseline justify-between">
                  <div className="text-lg font-black">
                    {hourLabel(h)} <span className="opacity-50">→ {hourLabel((h + 1) % 24)}</span>
                  </div>
                  {l.count >= 3 && <span title="On fire">🔥</span>}
                </div>

                <div className="my-3 flex items-center justify-between">
                  <button
                    onClick={() => update(h, { count: l.count - 1 }, 350)}
                    disabled={l.count === 0}
                    className="press chunky-sm h-12 w-12 rounded-full bg-white text-2xl font-black disabled:opacity-30"
                    aria-label={`Remove a design at ${hourLabel(h)}`}
                  >
                    −
                  </button>
                  <div key={l.count} className="pop text-5xl font-black tabular-nums">
                    {l.count}
                  </div>
                  <button
                    onClick={() => update(h, { count: l.count + 1 }, 350)}
                    className="press chunky-sm h-12 w-12 rounded-full bg-[#ff6b9d] text-2xl font-black text-white"
                    aria-label={`Add a design at ${hourLabel(h)}`}
                  >
                    +
                  </button>
                </div>

                <input
                  value={l.note}
                  maxLength={200}
                  onChange={(e) => update(h, { note: e.target.value }, 800)}
                  placeholder="What did you design? (optional)"
                  className="chunky-sm w-full rounded-xl bg-white px-3 py-2 text-sm font-semibold outline-none placeholder:text-purple-300 focus:bg-[#fffdf2]"
                />
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}

function Chip({ label, value, bg }: { label: string; value: string; bg: string }) {
  return (
    <div className="chunky-sm rounded-2xl px-4 py-2" style={{ background: bg }}>
      <div className="text-[11px] font-extrabold uppercase tracking-wide opacity-70">{label}</div>
      <div className="text-lg font-black leading-tight">{value}</div>
    </div>
  );
}
