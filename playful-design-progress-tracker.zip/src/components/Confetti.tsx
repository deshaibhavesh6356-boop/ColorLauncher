"use client";

import { useMemo } from "react";
import type { CSSProperties } from "react";

const COLORS = ["#ff6b9d", "#ffd93d", "#6bcB77", "#4d96ff", "#b388ff", "#ff9f45"];

export default function Confetti({ burstId }: { burstId: number }) {
  const pieces = useMemo(
    () =>
      Array.from({ length: 70 }, (_, i) => ({
        id: `${burstId}-${i}`,
        left: Math.random() * 100,
        dx: (Math.random() - 0.5) * 300,
        rot: 360 + Math.random() * 720,
        dur: 1.8 + Math.random() * 1.6,
        delay: Math.random() * 0.4,
        color: COLORS[i % COLORS.length],
      })),
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [burstId],
  );

  if (burstId === 0) return null;

  return (
    <>
      {pieces.map((p) => (
        <span
          key={p.id}
          className="confetti-piece"
          style={
            {
              left: `${p.left}vw`,
              background: p.color,
              animationDelay: `${p.delay}s`,
              "--dx": `${p.dx}px`,
              "--rot": `${p.rot}deg`,
              "--dur": `${p.dur}s`,
            } as CSSProperties
          }
        />
      ))}
    </>
  );
}
