import { integer, pgTable, serial, text, timestamp, unique } from "drizzle-orm/pg-core";

export const hourlyLogs = pgTable(
  "hourly_logs",
  {
    id: serial("id").primaryKey(),
    date: text("date").notNull(), // YYYY-MM-DD (user's local date)
    hour: integer("hour").notNull(), // 0-23
    count: integer("count").notNull().default(0),
    note: text("note").notNull().default(""),
    updatedAt: timestamp("updated_at").notNull().defaultNow(),
  },
  (t) => [unique("hourly_logs_date_hour_uq").on(t.date, t.hour)],
);

export const settings = pgTable("settings", {
  id: integer("id").primaryKey(),
  dailyGoal: integer("daily_goal").notNull().default(8),
  startHour: integer("start_hour").notNull().default(9),
  endHour: integer("end_hour").notNull().default(19), // exclusive
});
