import { NextResponse } from "next/server";
import { db } from "@/db";
import { settings } from "@/db/schema";
import { getSettings } from "@/lib/settings";

export const dynamic = "force-dynamic";

export async function GET() {
  return NextResponse.json(await getSettings());
}

export async function PUT(req: Request) {
  const body = await req.json().catch(() => null);
  if (!body) return NextResponse.json({ error: "Invalid body" }, { status: 400 });

  const dailyGoal = Math.floor(Number(body.dailyGoal));
  const startHour = Math.floor(Number(body.startHour));
  const endHour = Math.floor(Number(body.endHour));

  if (
    !(dailyGoal >= 1 && dailyGoal <= 99) ||
    !(startHour >= 0 && startHour <= 23) ||
    !(endHour >= 1 && endHour <= 24) ||
    startHour >= endHour
  ) {
    return NextResponse.json({ error: "Invalid settings" }, { status: 400 });
  }

  await db
    .insert(settings)
    .values({ id: 1, dailyGoal, startHour, endHour })
    .onConflictDoUpdate({ target: settings.id, set: { dailyGoal, startHour, endHour } });

  return NextResponse.json({ dailyGoal, startHour, endHour });
}
