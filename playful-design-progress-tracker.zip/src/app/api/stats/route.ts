import { NextResponse } from "next/server";
import { like, sql } from "drizzle-orm";
import { db } from "@/db";
import { hourlyLogs } from "@/db/schema";
import { isValidMonth } from "@/lib/date";

export const dynamic = "force-dynamic";

export async function GET(req: Request) {
  const month = new URL(req.url).searchParams.get("month");
  if (!isValidMonth(month)) {
    return NextResponse.json({ error: "Invalid month" }, { status: 400 });
  }
  const where = like(hourlyLogs.date, `${month}-%`);

  const dayRows = await db
    .select({ date: hourlyLogs.date, total: sql<number>`coalesce(sum(${hourlyLogs.count}), 0)::int` })
    .from(hourlyLogs)
    .where(where)
    .groupBy(hourlyLogs.date);

  const hourRows = await db
    .select({ hour: hourlyLogs.hour, total: sql<number>`coalesce(sum(${hourlyLogs.count}), 0)::int` })
    .from(hourlyLogs)
    .where(where)
    .groupBy(hourlyLogs.hour);

  const days: Record<string, number> = {};
  for (const r of dayRows) days[r.date] = r.total;
  const byHour: Record<string, number> = {};
  for (const r of hourRows) byHour[String(r.hour)] = r.total;

  return NextResponse.json({ days, byHour });
}
