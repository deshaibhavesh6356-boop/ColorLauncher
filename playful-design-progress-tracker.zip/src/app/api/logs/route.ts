import { NextResponse } from "next/server";
import { eq, sql } from "drizzle-orm";
import { db } from "@/db";
import { hourlyLogs } from "@/db/schema";
import { isValidDate } from "@/lib/date";

export const dynamic = "force-dynamic";

export async function GET(req: Request) {
  const date = new URL(req.url).searchParams.get("date");
  if (!isValidDate(date)) {
    return NextResponse.json({ error: "Invalid date" }, { status: 400 });
  }
  const rows = await db.select().from(hourlyLogs).where(eq(hourlyLogs.date, date));
  return NextResponse.json({
    logs: rows.map((r) => ({ hour: r.hour, count: r.count, note: r.note })),
  });
}

export async function PUT(req: Request) {
  const body = await req.json().catch(() => null);
  if (!body || !isValidDate(body.date)) {
    return NextResponse.json({ error: "Invalid date" }, { status: 400 });
  }
  const hour = Number(body.hour);
  const count = Math.max(0, Math.min(99, Math.floor(Number(body.count ?? 0))));
  const note = String(body.note ?? "").slice(0, 200);
  if (!Number.isInteger(hour) || hour < 0 || hour > 23 || Number.isNaN(count)) {
    return NextResponse.json({ error: "Invalid hour or count" }, { status: 400 });
  }

  await db
    .insert(hourlyLogs)
    .values({ date: body.date, hour, count, note })
    .onConflictDoUpdate({
      target: [hourlyLogs.date, hourlyLogs.hour],
      set: { count, note, updatedAt: sql`now()` },
    });

  return NextResponse.json({ ok: true, hour, count, note });
}
