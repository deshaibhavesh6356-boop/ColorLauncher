"use client";

import { useEffect, useState } from "react";
import TodayView from "@/components/TodayView";
import MonthView from "@/components/MonthView";
import SettingsView from "@/components/SettingsView";
import { toDateStr } from "@/lib/date";
import { DEFAULT_SETTINGS } from "@/lib/types";
import type { Settings } from "@/lib/types";

type Tab = "day" | "month" | "settings";

const TABS: { id: Tab; label: string; emoji: string; bg: string }[] = [
  { id: "day", label: "Day", emoji: "☀️", bg: "#ffd93d" },
  { id: "month", label: "Month", emoji: "📅", bg: "#ff9fc4" },
  { id: "settings", label: "Settings", emoji: "⚙️", bg: "#a8e6b5" },
];

export default function Home() {
  const [tab, setTab] = useState<Tab>("day");
  const [settings, setSettings] = useState<Settings | null>(null);
  const [date, setDate] = useState(() => toDateStr(new Date()));

  useEffect(() => {
    fetch("/api/settings", { cache: "no-store" })
      .then((r) => r.json())
      .then(setSettings)
      .catch(() => setSettings(DEFAULT_SETTINGS));
  }, []);

  return (
    <main className="mx-auto max-w-5xl px-4 pb-24 pt-6">
      <header className="mb-6 flex flex-wrap items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="chunky wobble flex h-14 w-14 items-center justify-center rounded-2xl bg-[#ff6b9d] text-3xl">
            🎨
          </div>
          <div>
            <h1 className="text-3xl font-black leading-none sm:text-4xl">DesignDash</h1>
            <p className="text-sm font-bold text-purple-500">One hour. One design. One happy you.</p>
          </div>
        </div>
        <nav className="flex gap-2">
          {TABS.map((t) => (
            <button
              key={t.id}
              onClick={() => setTab(t.id)}
              style={{ background: tab === t.id ? t.bg : "#fff" }}
              className={`press chunky-sm rounded-full px-4 py-2 text-sm font-black sm:px-5 sm:text-base ${
                tab === t.id ? "-translate-y-0.5" : ""
              }`}
            >
              <span className="mr-1">{t.emoji}</span>
              {t.label}
            </button>
          ))}
        </nav>
      </header>

      {!settings ? (
        <div className="py-20 text-center text-xl font-black">
          <span className="bounce-soft inline-block text-5xl">🖌️</span>
          <div>Warming up…</div>
        </div>
      ) : tab === "day" ? (
        <TodayView settings={settings} date={date} setDate={setDate} />
      ) : tab === "month" ? (
        <MonthView
          settings={settings}
          onPickDay={(d) => {
            setDate(d);
            setTab("day");
          }}
        />
      ) : (
        <SettingsView settings={settings} onSaved={setSettings} />
      )}
    </main>
  );
}
