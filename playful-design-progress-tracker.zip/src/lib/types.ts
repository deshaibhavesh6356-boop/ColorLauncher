export type Settings = {
  dailyGoal: number;
  startHour: number;
  endHour: number;
};

export type HourLog = { hour: number; count: number; note: string };

export type MonthStats = {
  days: Record<string, number>;
  byHour: Record<string, number>;
};

export const DEFAULT_SETTINGS: Settings = { dailyGoal: 8, startHour: 9, endHour: 19 };
