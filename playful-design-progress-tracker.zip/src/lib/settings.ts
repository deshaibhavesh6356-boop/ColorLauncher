import { eq } from "drizzle-orm";
import { db } from "@/db";
import { settings } from "@/db/schema";
import type { Settings } from "./types";
import { DEFAULT_SETTINGS } from "./types";

export async function getSettings(): Promise<Settings> {
  const rows = await db.select().from(settings).where(eq(settings.id, 1));
  if (rows.length === 0) {
    await db.insert(settings).values({ id: 1, ...DEFAULT_SETTINGS }).onConflictDoNothing();
    return DEFAULT_SETTINGS;
  }
  const r = rows[0];
  return { dailyGoal: r.dailyGoal, startHour: r.startHour, endHour: r.endHour };
}
