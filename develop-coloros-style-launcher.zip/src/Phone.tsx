import { useEffect, useRef, useState } from "react";

type DemoApp = { id: string; name: string; emoji: string; from: string; to: string };

const grid: DemoApp[] = [
  { id: "clock", name: "Clock", emoji: "⏰", from: "#2b2f3a", to: "#0f1218" },
  { id: "gallery", name: "Photos", emoji: "🌸", from: "#ff9a9e", to: "#fad0c4" },
  { id: "music", name: "Music", emoji: "🎵", from: "#ff5f6d", to: "#ffc371" },
  { id: "settings", name: "Settings", emoji: "⚙️", from: "#8e9eab", to: "#5b6b78" },
  { id: "weather", name: "Weather", emoji: "⛅", from: "#4facfe", to: "#00c6fb" },
  { id: "notes", name: "Notes", emoji: "📝", from: "#f7d794", to: "#f6b93b" },
  { id: "files", name: "Files", emoji: "📁", from: "#43e97b", to: "#1fbf8f" },
  { id: "store", name: "Store", emoji: "🛍️", from: "#a18cd1", to: "#7f6bd1" },
  { id: "calendar", name: "Calendar", emoji: "📅", from: "#ff758c", to: "#ff4e63" },
  { id: "calc", name: "Calculator", emoji: "🧮", from: "#434343", to: "#111" },
  { id: "health", name: "Health", emoji: "💚", from: "#38ef7d", to: "#11998e" },
  { id: "themes", name: "Themes", emoji: "🎨", from: "#fc5c7d", to: "#6a82fb" },
  { id: "video", name: "Videos", emoji: "🎬", from: "#f093fb", to: "#f5576c" },
  { id: "maps", name: "Maps", emoji: "🗺️", from: "#56ab2f", to: "#a8e063" },
  { id: "recorder", name: "Recorder", emoji: "🎙️", from: "#e96443", to: "#904e95" },
  { id: "mail", name: "Mail", emoji: "✉️", from: "#36d1dc", to: "#5b86e5" },
];

const dockApps: DemoApp[] = [
  { id: "phone", name: "Phone", emoji: "📞", from: "#3ddc84", to: "#12a65a" },
  { id: "msg", name: "Messages", emoji: "💬", from: "#4facfe", to: "#2a7de1" },
  { id: "browser", name: "Browser", emoji: "🌐", from: "#667eea", to: "#764ba2" },
  { id: "camera", name: "Camera", emoji: "📷", from: "#434343", to: "#1c1c1e" },
];

type Rect = { l: number; t: number; w: number; h: number };

function Icon({ app, size = 54 }: { app: DemoApp; size?: number }) {
  return (
    <div
      data-ic
      className="flex items-center justify-center shadow-lg shadow-black/25"
      style={{
        width: size,
        height: size,
        borderRadius: size * 0.31,
        background: `linear-gradient(145deg, ${app.from}, ${app.to})`,
        fontSize: size * 0.5,
      }}
    >
      {app.emoji}
    </div>
  );
}

export default function Phone() {
  const phone = useRef<HTMLDivElement>(null);
  const [now, setNow] = useState(new Date());
  const [open, setOpen] = useState<{ app: DemoApp; rect: Rect; expanded: boolean } | null>(null);
  const [returning, setReturning] = useState(false);
  const [drawer, setDrawer] = useState(false);
  const [q, setQ] = useState("");
  const startY = useRef(0);

  useEffect(() => {
    const t = setInterval(() => setNow(new Date()), 15000);
    return () => clearInterval(t);
  }, []);

  const launch = (app: DemoApp, el: HTMLElement) => {
    const p = phone.current!.getBoundingClientRect();
    const target = (el.querySelector("[data-ic]") as HTMLElement) ?? el;
    const r = target.getBoundingClientRect();
    setOpen({ app, rect: { l: r.left - p.left, t: r.top - p.top, w: r.width, h: r.height }, expanded: false });
    requestAnimationFrame(() => requestAnimationFrame(() => setOpen((o) => (o ? { ...o, expanded: true } : o))));
  };

  const goHome = () => {
    if (!open) {
      setDrawer(false);
      return;
    }
    setOpen((o) => (o ? { ...o, expanded: false } : o));
    setDrawer(false);
    setReturning(true);
    setTimeout(() => setOpen(null), 380);
    setTimeout(() => setReturning(false), 520);
  };

  const hh = now.getHours() % 12 || 12;
  const mm = String(now.getMinutes()).padStart(2, "0");
  const date = now.toLocaleDateString("en-GB", { weekday: "long", day: "numeric", month: "long" });
  const hidden = !!open && open.expanded;
  const list = grid.filter((a) => a.name.toLowerCase().includes(q.toLowerCase()));

  return (
    <div className="relative mx-auto" style={{ width: 300 }}>
      <div className="rounded-[52px] bg-zinc-900 p-[9px] shadow-2xl shadow-black/60 ring-1 ring-white/15">
        <div
          ref={phone}
          className="relative overflow-hidden rounded-[44px] select-none"
          style={{
            height: 600,
            background:
              "radial-gradient(120% 70% at 20% 0%, #ffd6a5 0%, transparent 55%), radial-gradient(100% 80% at 100% 40%, #7aa7ff 0%, transparent 60%), linear-gradient(180deg, #3b2f6b 0%, #1d1b3a 100%)",
          }}
        >
          {/* status bar */}
          <div className="absolute inset-x-0 top-0 z-30 flex items-center justify-between px-6 pt-2.5 text-[11px] font-medium text-white">
            <span>
              {hh}:{mm}
            </span>
            <div className="absolute left-1/2 top-2 h-3.5 w-3.5 -translate-x-1/2 rounded-full bg-black" />
            <span>5G ▮▮▮ 🔋</span>
          </div>

          {/* home content */}
          <div
            className={`absolute inset-0 flex flex-col pt-9 ${returning ? "home-return" : ""}`}
            style={{
              transform: drawer ? "scale(0.93)" : hidden ? "scale(0.9)" : "scale(1)",
              opacity: drawer ? 0.4 : hidden ? 0 : 1,
              transition: returning ? undefined : "transform 380ms cubic-bezier(.2,.8,.2,1), opacity 300ms",
            }}
            onPointerDown={(e) => (startY.current = e.clientY)}
            onPointerUp={(e) => {
              if (e.clientY - startY.current < -60) setDrawer(true);
            }}
          >
            <div className="px-6 pt-1 text-white" style={{ textShadow: "0 2px 8px rgba(0,0,0,.25)" }}>
              <div className="text-[62px] font-extralight leading-none tracking-tight">
                {hh}:{mm}
              </div>
              <div className="mt-1 text-[13px] font-medium text-white/90">{date}</div>
            </div>

            <div className="mt-4 grid flex-1 grid-cols-4 content-start gap-y-3 px-1">
              {grid.slice(0, 12).map((a) => (
                <button
                  key={a.id}
                  onClick={(e) => launch(a, e.currentTarget)}
                  className="flex flex-col items-center gap-1 transition-transform duration-150 active:scale-90"
                >
                  <Icon app={a} />
                  <span className="text-[10px] text-white" style={{ textShadow: "0 1px 3px rgba(0,0,0,.5)" }}>
                    {a.name}
                  </span>
                </button>
              ))}
            </div>

            <div className="flex justify-center pb-2">
              <span className="h-1.5 w-4 rounded-full bg-white" />
              <span className="ml-1.5 h-1.5 w-1.5 rounded-full bg-white/50" />
            </div>

            <div className="mx-2.5 mb-5 flex items-center justify-around rounded-[28px] border border-white/20 bg-white/25 py-3 backdrop-blur-xl">
              {dockApps.map((a) => (
                <button
                  key={a.id}
                  onClick={(e) => launch(a, e.currentTarget)}
                  className="transition-transform duration-150 active:scale-90"
                >
                  <Icon app={a} size={52} />
                </button>
              ))}
            </div>
          </div>

          {/* drawer */}
          <div
            className="absolute inset-0 z-20 flex flex-col bg-black/55 pt-12 backdrop-blur-2xl"
            style={{
              transform: drawer && !hidden ? "translateY(0)" : "translateY(102%)",
              transition: "transform 420ms cubic-bezier(.2,.8,.2,1)",
            }}
            onPointerDown={(e) => (startY.current = e.clientY)}
            onPointerUp={(e) => {
              if (e.clientY - startY.current > 70) setDrawer(false);
            }}
          >
            <input
              value={q}
              onChange={(e) => setQ(e.target.value)}
              placeholder="Search apps"
              className="mx-4 rounded-full bg-white/15 px-5 py-2.5 text-[13px] text-white placeholder-white/60 outline-none"
            />
            <div className="mt-4 grid grid-cols-4 content-start gap-y-3 overflow-hidden px-1">
              {list.map((a) => (
                <button
                  key={a.id}
                  onClick={(e) => launch(a, e.currentTarget)}
                  className="flex flex-col items-center gap-1 active:scale-90"
                >
                  <Icon app={a} size={50} />
                  <span className="text-[10px] text-white">{a.name}</span>
                </button>
              ))}
            </div>
          </div>

          {/* app opening / closing overlay */}
          {open && (
            <div
              className="absolute z-40 overflow-hidden"
              style={{
                left: open.expanded ? 0 : open.rect.l,
                top: open.expanded ? 0 : open.rect.t,
                width: open.expanded ? "100%" : open.rect.w,
                height: open.expanded ? "100%" : open.rect.h,
                borderRadius: open.expanded ? 44 : open.rect.w * 0.31,
                background: `linear-gradient(160deg, ${open.app.from}, ${open.app.to})`,
                transition: "all 380ms cubic-bezier(.2,.8,.2,1)",
              }}
            >
              <div
                className="flex h-full flex-col items-center justify-center text-white"
                style={{ opacity: open.expanded ? 1 : 0, transition: "opacity 260ms 100ms" }}
              >
                <div className="text-6xl">{open.app.emoji}</div>
                <div className="mt-3 text-lg font-semibold">{open.app.name}</div>
                <div className="mt-1 text-xs text-white/80">Home bar dabao → closing animation</div>
              </div>
              <button
                onClick={goHome}
                aria-label="Home"
                className="absolute bottom-2 left-1/2 h-1.5 w-28 -translate-x-1/2 rounded-full bg-white/80"
              />
            </div>
          )}

          {/* nav pill when on home/drawer */}
          {!open && (
            <button
              onClick={goHome}
              aria-label="Home"
              className="absolute bottom-2 left-1/2 z-50 h-1.5 w-28 -translate-x-1/2 rounded-full bg-white/80"
            />
          )}
        </div>
      </div>
      <p className="mt-4 text-center text-xs text-white/60">
        Live preview — icon dabao (open animation), neeche bar dabao (close), upar swipe karo (app drawer)
      </p>
    </div>
  );
}
