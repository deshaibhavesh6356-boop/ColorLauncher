import Phone from "./Phone";
import uploadPack from "./assets/ColorLauncher-GitHub-Upload.zip?url";
import projectZip from "./assets/ColorStyleLauncher.zip?url";

const features = [
  ["📱", "ColorOS home screen", "Bada patla clock + date widget, squircle icons, page dots jo pill ban jaate hain."],
  ["⚓", "Floating glass dock", "Rounded frosted dock (Phone, Messages, Browser, Camera). Long-press → Add/Remove from Dock."],
  ["🚀", "Open animation", "Icon se app zoom hoke khulta hai, aur home screen peeche zoom-out hoti hai."],
  ["↩️", "Closing animation", "Back/Home dabane par icons bade hoke wapas zoom-in hote hain (ColorOS jaisa)."],
  ["🔎", "Swipe-up app drawer", "Upar swipe → blurred drawer + search. Neeche swipe → band."],
  ["🔔", "Swipe-down notifications", "Home par neeche swipe karo to notification panel khulta hai."],
  ["🧩", "Long-press menus", "App info, Uninstall, Dock; khali jagah long-press → Wallpapers, Settings."],
  ["🗂️", "Aapke saare apps", "Aapke phone ke sabhi installed apps apne aap dikhte hain. Files/data ki koi alag permission nahi chahiye."],
];

const steps = [
  {
    t: "Naya zip download karo",
    d: "Neeche wala hara button dabao: ColorLauncher-GitHub-Upload.zip. Isse phone ke Files app mein extract karo.",
  },
  {
    t: "GitHub repo mein upload karo",
    d: "Chrome mein ye link kholo: github.com/deshaibhavesh6356-boop/ColorLauncher/upload/main — extract hui files (ColorStyleLauncher.zip + .github folder) choose karo. Purani ColorStyleLauncher.zip ko ye NAYI file replace kar degi (naam same hai).",
  },
  {
    t: "Commit changes dabao",
    d: "Upload ke baad 'Commit changes' dabao. Actions tab mein 'Build APK' apne aap chalega (5–10 minute).",
  },
  {
    t: "APK download karo",
    d: "Build complete (green tick) hone par us run mein neeche 'ColorLauncher-apk' artifact download karo. Usme app-debug.apk hoga.",
  },
  {
    t: "Install karke default chuno",
    d: "APK install karo → Home button dabao → 'Color Home' chuno → 'Always'. Agar na aaye: Settings → Apps → Default apps → Home app.",
  },
];

export default function App() {
  return (
    <div className="min-h-screen bg-[#0b0c12] text-white">
      <div
        className="pointer-events-none absolute inset-x-0 top-0 h-[520px] opacity-60"
        style={{
          background:
            "radial-gradient(60% 60% at 15% 0%, rgba(31,211,138,.35), transparent 70%), radial-gradient(50% 60% at 90% 10%, rgba(122,167,255,.35), transparent 70%)",
        }}
      />
      <div className="relative mx-auto max-w-6xl px-5 py-10 md:py-16">
        <header className="mb-10 flex items-center gap-3">
          <div className="flex h-11 w-11 items-center justify-center rounded-[14px] bg-gradient-to-br from-emerald-400 to-emerald-600 shadow-lg shadow-emerald-500/30">
            <div className="h-5 w-5 rounded-full border-[3.5px] border-white" />
          </div>
          <div>
            <div className="text-lg font-semibold leading-tight">Color Home</div>
            <div className="text-xs text-white/50">ColorOS-style launcher for Android · v2.0</div>
          </div>
        </header>

        <div className="grid items-center gap-12 lg:grid-cols-2">
          <div>
            <h1 className="text-4xl font-semibold leading-tight md:text-5xl">
              Ab <span className="text-emerald-400">sach-much</span> ColorOS jaisa launcher.
            </h1>
            <p className="mt-4 max-w-xl text-white/70">
              Pichhli baar interface alag lag raha tha. Is version mein poora home screen dobara banaya hai: ColorOS
              clock widget, squircle icons, glass dock, pill page-dots, swipe-up blurred drawer aur real open/close
              animations. Aapke Redmi ke saare apps isme dikhenge.
            </p>

            <div className="mt-7 flex flex-col gap-3 sm:flex-row">
              <a
                href={uploadPack}
                download="ColorLauncher-GitHub-Upload.zip"
                className="rounded-2xl bg-emerald-500 px-6 py-3.5 text-center font-semibold text-black shadow-lg shadow-emerald-500/30 transition hover:bg-emerald-400 active:scale-95"
              >
                ⬇ ColorLauncher-GitHub-Upload.zip
                <span className="block text-[11px] font-normal text-black/70">Recommended · zip + .github folder</span>
              </a>
              <a
                href={projectZip}
                download="ColorStyleLauncher.zip"
                className="rounded-2xl border border-white/20 bg-white/5 px-6 py-3.5 text-center font-medium transition hover:bg-white/10 active:scale-95"
              >
                ⬇ ColorStyleLauncher.zip
                <span className="block text-[11px] font-normal text-white/50">Sirf project (Kotlin source)</span>
              </a>
            </div>

            <div className="mt-6 rounded-2xl border border-amber-400/30 bg-amber-400/10 p-4 text-sm text-amber-100/90">
              <b>Seedhi baat:</b> main yahan APK compile nahi kar sakta (Android SDK nahi hai), isliye APK GitHub
              Actions banayega. Agar build fail ho to Actions ka error log mujhe bhej do, main turant fix kar dunga.
              Aur ye Oppo ka asli ColorOS nahi hai — ye uska design aur animations copy karne wala launcher hai,
              jo Redmi ke upar chalega.
            </div>
          </div>

          <Phone />
        </div>

        <section className="mt-20">
          <h2 className="text-2xl font-semibold">Is version mein kya naya hai</h2>
          <div className="mt-6 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
            {features.map(([e, t, d]) => (
              <div key={t} className="rounded-3xl border border-white/10 bg-white/5 p-5 backdrop-blur">
                <div className="text-2xl">{e}</div>
                <div className="mt-3 font-medium">{t}</div>
                <p className="mt-1 text-sm text-white/60">{d}</p>
              </div>
            ))}
          </div>
        </section>

        <section className="mt-20">
          <h2 className="text-2xl font-semibold">APK kaise banayein (sirf phone se)</h2>
          <ol className="mt-6 space-y-3">
            {steps.map((s, i) => (
              <li key={s.t} className="flex gap-4 rounded-3xl border border-white/10 bg-white/5 p-5">
                <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-emerald-500 font-semibold text-black">
                  {i + 1}
                </div>
                <div>
                  <div className="font-medium">{s.t}</div>
                  <p className="mt-1 text-sm text-white/65">{s.d}</p>
                </div>
              </li>
            ))}
          </ol>
        </section>

        <section className="mt-16 rounded-3xl border border-white/10 bg-white/5 p-6">
          <h2 className="text-xl font-semibold">Redmi (HyperOS/MIUI) par tips</h2>
          <ul className="mt-3 list-disc space-y-2 pl-5 text-sm text-white/70">
            <li>Install ke time "Unknown sources" allow karo.</li>
            <li>Settings → Apps → Manage apps → Color Home → Autostart ON, Battery saver → No restrictions.</li>
            <li>Agar Home dabane par purana launcher aaye: Settings → Home screen → Default launcher → Color Home.</li>
            <li>Sabhi apps dikhane ke liye koi extra permission nahi chahiye; launcher khud list banata hai.</li>
            <li>Icon par long-press karke "Add to Dock" se dock apni pasand ka bana lo.</li>
          </ul>
        </section>

        <footer className="mt-12 text-center text-xs text-white/40">Color Home · open-source Kotlin launcher</footer>
      </div>
    </div>
  );
}
