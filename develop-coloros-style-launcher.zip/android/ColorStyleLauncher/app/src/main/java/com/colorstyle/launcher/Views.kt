package com.colorstyle.launcher

import android.content.ComponentName
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.drawable.AdaptiveIconDrawable
import android.graphics.drawable.Drawable
import android.util.AttributeSet
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.animation.DecelerateInterpolator
import android.view.animation.OvershootInterpolator
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import kotlin.math.abs
import kotlin.math.max

data class AppInfo(
    val label: String,
    val pkg: String,
    val component: ComponentName,
    val icon: Bitmap
)

fun Context.dp(v: Int): Int = (v * resources.displayMetrics.density + 0.5f).toInt()
fun Context.dpf(v: Float): Float = v * resources.displayMetrics.density

/** Converts any app icon into the ColorOS "squircle" look. */
object IconFactory {
    fun make(d: Drawable, size: Int): Bitmap {
        val bmp = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val s = size.toFloat()
        val r = s * 0.31f
        val clip = Path().apply { addRoundRect(RectF(0f, 0f, s, s), r, r, Path.Direction.CW) }
        c.save()
        c.clipPath(clip)
        if (d is AdaptiveIconDrawable) {
            val off = (size * 0.25f).toInt()
            val bg = d.background
            val fg = d.foreground
            if (bg != null) {
                bg.setBounds(-off, -off, size + off, size + off)
                bg.draw(c)
            } else {
                c.drawColor(Color.WHITE)
            }
            if (fg != null) {
                fg.setBounds(-off, -off, size + off, size + off)
                fg.draw(c)
            }
        } else {
            c.drawColor(Color.WHITE)
            val inset = (size * 0.14f).toInt()
            d.setBounds(inset, inset, size - inset, size - inset)
            d.draw(c)
        }
        c.restore()
        return bmp
    }
}

/** One icon + label cell (used on home pages, in the dock and in the drawer). */
class IconCell(ctx: Context, showLabel: Boolean = true) : LinearLayout(ctx) {
    val icon = ImageView(ctx)
    val label = TextView(ctx)

    init {
        orientation = VERTICAL
        gravity = Gravity.CENTER
        isClickable = true
        isLongClickable = true
        icon.scaleType = ImageView.ScaleType.FIT_XY
        addView(icon, LayoutParams(ctx.dp(58), ctx.dp(58)))
        label.apply {
            textSize = 11.5f
            setTextColor(Color.WHITE)
            maxLines = 1
            ellipsize = android.text.TextUtils.TruncateAt.END
            gravity = Gravity.CENTER
            setShadowLayer(ctx.dpf(3f), 0f, ctx.dpf(1f), 0x88000000.toInt())
            setPadding(ctx.dp(2), 0, ctx.dp(2), 0)
        }
        val lp = LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT)
        lp.topMargin = ctx.dp(6)
        addView(label, lp)
        if (!showLabel) label.visibility = GONE
    }

    fun bind(app: AppInfo) {
        icon.setImageBitmap(app.icon)
        label.text = app.label
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> animate().scaleX(0.86f).scaleY(0.86f)
                .setDuration(110).setInterpolator(DecelerateInterpolator()).start()
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> animate().scaleX(1f).scaleY(1f)
                .setDuration(320).setInterpolator(OvershootInterpolator(3.2f)).start()
        }
        return super.onTouchEvent(e)
    }
}

/** Simple fixed grid: optional header (clock widget) + cols x rows cells. */
class PageGrid(ctx: Context, private val cols: Int, private val rows: Int, private val headerH: Int) :
    ViewGroup(ctx) {
    var header: View? = null

    override fun onMeasure(widthSpec: Int, heightSpec: Int) {
        val w = MeasureSpec.getSize(widthSpec)
        val h = MeasureSpec.getSize(heightSpec)
        setMeasuredDimension(w, h)
        val cw = w / cols
        val ch = max(1, (h - headerH) / rows)
        for (i in 0 until childCount) {
            val v = getChildAt(i)
            if (v === header) {
                v.measure(
                    MeasureSpec.makeMeasureSpec(w, MeasureSpec.EXACTLY),
                    MeasureSpec.makeMeasureSpec(headerH, MeasureSpec.EXACTLY)
                )
            } else {
                v.measure(
                    MeasureSpec.makeMeasureSpec(cw, MeasureSpec.EXACTLY),
                    MeasureSpec.makeMeasureSpec(ch, MeasureSpec.EXACTLY)
                )
            }
        }
    }

    override fun onLayout(changed: Boolean, l: Int, t: Int, r: Int, b: Int) {
        val w = r - l
        val h = b - t
        val cw = w / cols
        val ch = max(1, (h - headerH) / rows)
        var idx = 0
        for (i in 0 until childCount) {
            val v = getChildAt(i)
            if (v === header) {
                v.layout(0, 0, w, headerH)
            } else {
                val left = (idx % cols) * cw
                val top = headerH + (idx / cols) * ch
                v.layout(left, top, left + cw, top + ch)
                idx++
            }
        }
    }
}

/** ColorOS style page dots: the active one stretches into a pill. */
class PageIndicator @JvmOverloads constructor(ctx: Context, attrs: AttributeSet? = null) :
    View(ctx, attrs) {
    var count = 0
        set(value) {
            field = value
            invalidate()
        }
    var position = 0f
        set(value) {
            field = value
            invalidate()
        }
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE }

    override fun onDraw(canvas: Canvas) {
        if (count <= 1) return
        val d = context.dpf(6f)
        val gap = context.dpf(8f)
        val extra = context.dpf(10f)
        val widths = FloatArray(count) { i -> d + extra * max(0f, 1f - abs(position - i)) }
        val total = widths.sum() + gap * (count - 1)
        var x = (width - total) / 2f
        val cy = height / 2f
        for (i in 0 until count) {
            val t = max(0f, 1f - abs(position - i))
            paint.alpha = (110 + 145 * t).toInt()
            canvas.drawRoundRect(x, cy - d / 2, x + widths[i], cy + d / 2, d / 2, d / 2, paint)
            x += widths[i] + gap
        }
    }
}
