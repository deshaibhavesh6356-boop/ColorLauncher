package com.colorstyle.launcher

import android.animation.ValueAnimator
import android.app.Activity
import android.app.ActivityOptions
import android.content.BroadcastReceiver
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.provider.Settings
import android.text.InputType
import android.view.Gravity
import android.view.GestureDetector
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.view.animation.DecelerateInterpolator
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.PopupWindow
import android.widget.TextClock
import android.widget.TextView
import android.widget.Toast
import androidx.core.content.ContextCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.widget.doAfterTextChanged
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import androidx.viewpager2.widget.ViewPager2
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

class MainActivity : Activity() {

    private val cols = 4
    private val handler = Handler(Looper.getMainLooper())

    private lateinit var prefs: SharedPreferences
    private lateinit var root: FrameLayout
    private lateinit var content: LinearLayout
    private lateinit var pager: ViewPager2
    private lateinit var indicator: PageIndicator
    private lateinit var dock: LinearLayout
    private lateinit var drawer: LinearLayout
    private lateinit var drawerList: RecyclerView
    private lateinit var search: EditText
    private lateinit var drawerAdapter: DrawerAdapter
    private lateinit var detector: GestureDetector

    private var apps: List<AppInfo> = emptyList()
    private var popup: PopupWindow? = null
    private var progress = 0f
    private var drawerOpen = false
    private var anim: ValueAnimator? = null
    private var launched = false
    private var resumed = false
    private var lastX = 0f
    private var lastY = 0f
    private var lastBuiltW = 0
    private var lastBuiltH = 0

    private val pkgReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            loadApps()
        }
    }

    // ---------------------------------------------------------------- lifecycle

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = getSharedPreferences("color_home", MODE_PRIVATE)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        window.statusBarColor = Color.TRANSPARENT
        window.navigationBarColor = Color.TRANSPARENT
        if (Build.VERSION.SDK_INT >= 29) {
            window.isNavigationBarContrastEnforced = false
        }

        buildUi()
        setContentView(root)

        ViewCompat.setOnApplyWindowInsetsListener(root) { _, insets ->
            val b = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            content.setPadding(0, b.top, 0, b.bottom)
            drawer.setPadding(0, b.top, 0, b.bottom)
            insets
        }

        detector = GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onFling(e1: MotionEvent?, e2: MotionEvent, vx: Float, vy: Float): Boolean {
                if (e1 == null) return false
                val dx = e2.x - e1.x
                val dy = e2.y - e1.y
                if (abs(dy) > dp(70) && abs(dy) > abs(dx) * 1.5f && abs(vy) > 700f) {
                    if (drawerOpen) {
                        if (dy > 0 && !drawerList.canScrollVertically(-1)) closeDrawer()
                    } else if (dy < 0) {
                        openDrawer()
                    } else {
                        expandNotifications()
                    }
                    return true
                }
                return false
            }
        })

        val f = IntentFilter().apply {
            addAction(Intent.ACTION_PACKAGE_ADDED)
            addAction(Intent.ACTION_PACKAGE_REMOVED)
            addAction(Intent.ACTION_PACKAGE_CHANGED)
            addDataScheme("package")
        }
        ContextCompat.registerReceiver(this, pkgReceiver, f, ContextCompat.RECEIVER_EXPORTED)

        loadApps()
    }

    override fun onDestroy() {
        super.onDestroy()
        try {
            unregisterReceiver(pkgReceiver)
        } catch (_: Exception) {
        }
    }

    override fun onResume() {
        super.onResume()
        resumed = true
        if (launched) restoreHome()
    }

    override fun onPause() {
        super.onPause()
        resumed = false
        dismissPopup()
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        dismissPopup()
        if (drawerOpen) {
            closeDrawer()
        } else if (pager.currentItem != 0) {
            pager.setCurrentItem(0, true)
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        when {
            popup?.isShowing == true -> dismissPopup()
            drawerOpen -> closeDrawer()
            pager.currentItem != 0 -> pager.setCurrentItem(0, true)
        }
    }

    override fun dispatchTouchEvent(ev: MotionEvent): Boolean {
        lastX = ev.rawX
        lastY = ev.rawY
        detector.onTouchEvent(ev)
        return super.dispatchTouchEvent(ev)
    }

    // ---------------------------------------------------------------- UI

    private fun buildUi() {
        root = FrameLayout(this)

        content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }

        pager = ViewPager2(this).apply {
            offscreenPageLimit = 1
            setPageTransformer { page, position ->
                val a = min(1f, abs(position))
                page.alpha = 1f - 0.55f * a
                page.scaleX = 1f - 0.08f * a
                page.scaleY = 1f - 0.08f * a
            }
            registerOnPageChangeCallback(object : ViewPager2.OnPageChangeCallback() {
                override fun onPageScrolled(position: Int, offset: Float, px: Int) {
                    indicator.position = position + offset
                }
            })
            addOnLayoutChangeListener { _, l, t, r, b, ol, ot, orr, ob ->
                if ((b - t) != (ob - ot) || (r - l) != (orr - ol)) rebuild()
            }
        }
        content.addView(pager, LinearLayout.LayoutParams(-1, 0, 1f))

        indicator = PageIndicator(this)
        content.addView(indicator, LinearLayout.LayoutParams(-1, dp(18)))

        dock = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            background = GradientDrawable().apply {
                setColor(0x3DFFFFFF)
                cornerRadius = dpf(32f)
                setStroke(dp(1), 0x33FFFFFF)
            }
            setPadding(dp(6), 0, dp(6), 0)
        }
        val dlp = LinearLayout.LayoutParams(-1, dp(88))
        dlp.setMargins(dp(14), dp(6), dp(14), dp(10))
        content.addView(dock, dlp)

        root.addView(content, FrameLayout.LayoutParams(-1, -1))

        // ---- app drawer
        drawer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(0xCC0D0F14.toInt())
            isClickable = true
            visibility = View.GONE
        }
        search = EditText(this).apply {
            hint = "Search apps"
            setHintTextColor(0xAAFFFFFF.toInt())
            setTextColor(Color.WHITE)
            textSize = 16f
            maxLines = 1
            inputType = InputType.TYPE_CLASS_TEXT
            imeOptions = EditorInfo.IME_ACTION_SEARCH
            setPadding(dp(22), 0, dp(22), 0)
            background = GradientDrawable().apply {
                setColor(0x26FFFFFF)
                cornerRadius = dpf(26f)
            }
            doAfterTextChanged { drawerAdapter.filter(it?.toString() ?: "") }
            setOnEditorActionListener { v, actionId, _ ->
                if (actionId == EditorInfo.IME_ACTION_SEARCH) {
                    drawerAdapter.items.firstOrNull()?.let { launch(it, v) }
                    true
                } else false
            }
        }
        val slp = LinearLayout.LayoutParams(-1, dp(52))
        slp.setMargins(dp(20), dp(16), dp(20), dp(8))
        drawer.addView(search, slp)

        drawerAdapter = DrawerAdapter()
        drawerList = RecyclerView(this).apply {
            layoutManager = GridLayoutManager(this@MainActivity, cols)
            adapter = drawerAdapter
            clipToPadding = false
            setPadding(dp(4), dp(8), dp(4), dp(16))
            overScrollMode = View.OVER_SCROLL_NEVER
        }
        drawer.addView(drawerList, LinearLayout.LayoutParams(-1, 0, 1f))
        root.addView(drawer, FrameLayout.LayoutParams(-1, -1))
    }

    // ---------------------------------------------------------------- apps

    private fun loadApps() {
        Thread {
            val pm = packageManager
            val main = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
            val list = pm.queryIntentActivities(main, 0)
                .filter { it.activityInfo.packageName != packageName }
                .map { ri ->
                    AppInfo(
                        ri.loadLabel(pm).toString(),
                        ri.activityInfo.packageName,
                        ComponentName(ri.activityInfo.packageName, ri.activityInfo.name),
                        IconFactory.make(ri.loadIcon(pm), 192)
                    )
                }
                .sortedBy { it.label.lowercase() }
            runOnUiThread {
                apps = list
                lastBuiltW = 0
                rebuild()
            }
        }.start()
    }

    private fun defaultDock(): List<String> {
        val res = mutableListOf<String>()
        fun add(i: Intent) {
            val p = packageManager.resolveActivity(i, PackageManager.MATCH_DEFAULT_ONLY)
                ?.activityInfo?.packageName
            if (p != null && apps.any { it.pkg == p } && p !in res) res.add(p)
        }
        add(Intent(Intent.ACTION_DIAL))
        add(Intent(Intent.ACTION_VIEW, Uri.parse("sms:")))
        add(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com")))
        add(Intent(MediaStore.ACTION_IMAGE_CAPTURE))
        return res.take(4)
    }

    private fun dockPkgs(): List<String> {
        val saved = prefs.getString("dock", null) ?: return defaultDock()
        return saved.split(",").filter { p -> p.isNotEmpty() && apps.any { it.pkg == p } }
    }

    private fun rebuild() {
        if (apps.isEmpty()) return
        val w = pager.width
        val h = pager.height
        if (w <= 0 || h <= 0) return
        if (w == lastBuiltW && h == lastBuiltH && pager.adapter != null) return
        lastBuiltW = w
        lastBuiltH = h

        val dockPackages = dockPkgs()
        val dockApps = dockPackages.mapNotNull { p -> apps.find { it.pkg == p } }
        dock.removeAllViews()
        dockApps.forEach { app ->
            val cell = IconCell(this, false)
            cell.bind(app)
            cell.setOnClickListener { launch(app, cell) }
            cell.setOnLongClickListener { showAppMenu(app, cell); true }
            dock.addView(cell, LinearLayout.LayoutParams(0, -1, 1f))
        }

        val rest = apps.filter { a -> dockApps.none { it.pkg == a.pkg } }
        val cellMin = dp(102)
        val headerH = dp(168)
        val rows0 = max(1, (h - headerH) / cellMin)
        val rows = max(1, h / cellMin)
        val pages = mutableListOf<List<AppInfo>>()
        pages.add(rest.take(cols * rows0))
        val remaining = rest.drop(cols * rows0)
        remaining.chunked(cols * rows).forEach { pages.add(it) }

        val keep = min(pager.currentItem, pages.size - 1)
        pager.adapter = PagesAdapter(pages, rows0, rows, headerH)
        pager.setCurrentItem(max(0, keep), false)
        indicator.count = pages.size
        indicator.position = max(0, keep).toFloat()

        drawerAdapter.setAll(apps)
    }

    private inner class PagesAdapter(
        val pages: List<List<AppInfo>>,
        val rows0: Int,
        val rows: Int,
        val headerH: Int
    ) : RecyclerView.Adapter<PagesAdapter.VH>() {

        inner class VH(val box: FrameLayout) : RecyclerView.ViewHolder(box)

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
            val box = FrameLayout(parent.context)
            box.layoutParams = RecyclerView.LayoutParams(-1, -1)
            return VH(box)
        }

        override fun getItemCount() = pages.size

        override fun onBindViewHolder(holder: VH, position: Int) {
            holder.box.removeAllViews()
            val first = position == 0
            val grid = PageGrid(this@MainActivity, cols, if (first) rows0 else rows, if (first) headerH else 0)
            if (first) {
                val header = buildClockWidget()
                grid.addView(header)
                grid.header = header
            }
            pages[position].forEach { app ->
                val cell = IconCell(this@MainActivity)
                cell.bind(app)
                cell.setOnClickListener { launch(app, cell.icon) }
                cell.setOnLongClickListener { showAppMenu(app, cell); true }
                grid.addView(cell)
            }
            grid.setOnLongClickListener {
                showHomeMenu()
                true
            }
            holder.box.addView(grid, FrameLayout.LayoutParams(-1, -1))
        }
    }

    private fun buildClockWidget(): View {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(28), dp(8), dp(28), dp(8))
        }
        val shadow = 0x66000000
        val time = TextClock(this).apply {
            format12Hour = "h:mm"
            format24Hour = "HH:mm"
            textSize = 76f
            typeface = android.graphics.Typeface.create("sans-serif-thin", android.graphics.Typeface.NORMAL)
            setTextColor(Color.WHITE)
            includeFontPadding = false
            setShadowLayer(dpf(6f), 0f, dpf(2f), shadow)
        }
        val date = TextClock(this).apply {
            format12Hour = "EEEE, d MMMM"
            format24Hour = "EEEE, d MMMM"
            textSize = 16f
            typeface = android.graphics.Typeface.create("sans-serif-medium", android.graphics.Typeface.NORMAL)
            setTextColor(0xEEFFFFFF.toInt())
            setShadowLayer(dpf(4f), 0f, dpf(1f), shadow)
        }
        box.addView(time, LinearLayout.LayoutParams(-2, -2))
        box.addView(date, LinearLayout.LayoutParams(-2, -2).apply { topMargin = dp(4) })
        box.setOnClickListener {
            openIntentSafely(Intent(android.provider.AlarmClock.ACTION_SHOW_ALARMS))
        }
        return box
    }

    // ---------------------------------------------------------------- launching / animations

    private fun launch(app: AppInfo, source: View) {
        dismissPopup()
        val intent = Intent(Intent.ACTION_MAIN)
            .addCategory(Intent.CATEGORY_LAUNCHER)
            .setComponent(app.component)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED)
        try {
            val w = max(1, source.width)
            val h = max(1, source.height)
            val opts = ActivityOptions.makeScaleUpAnimation(source, 0, 0, w, h)
            hideKeyboard()
            startActivity(intent, opts.toBundle())
            launched = true
            // ColorOS style: the home screen zooms away while the app grows out of the icon.
            content.animate().cancel()
            content.animate().scaleX(0.9f).scaleY(0.9f).alpha(0f)
                .setDuration(280).setInterpolator(DecelerateInterpolator(1.4f)).start()
            if (drawerOpen) drawer.animate().alpha(0f).setDuration(220).start()
            handler.postDelayed({ if (launched && resumed) restoreHome() }, 2500)
        } catch (e: Exception) {
            Toast.makeText(this, "Can't open ${app.label}", Toast.LENGTH_SHORT).show()
        }
    }

    /** Closing animation: icons zoom back in from slightly larger, like ColorOS. */
    private fun restoreHome() {
        launched = false
        if (drawerOpen) {
            anim?.cancel()
            drawerOpen = false
            setProgress(0f)
            search.setText("")
        }
        drawer.animate().cancel()
        drawer.alpha = 1f
        content.animate().cancel()
        content.scaleX = 1.14f
        content.scaleY = 1.14f
        content.alpha = 0f
        content.animate().scaleX(1f).scaleY(1f).alpha(1f)
            .setDuration(420).setInterpolator(DecelerateInterpolator(1.8f)).start()
    }

    private fun setProgress(p: Float) {
        progress = p
        val hgt = root.height.toFloat()
        drawer.translationY = (1f - p) * hgt
        drawer.visibility = if (p <= 0f) View.GONE else View.VISIBLE
        if (!launched) {
            content.scaleX = 1f - 0.07f * p
            content.scaleY = 1f - 0.07f * p
            content.alpha = 1f - 0.6f * p
        }
        if (Build.VERSION.SDK_INT >= 31) {
            try {
                window.setBackgroundBlurRadius((p * dp(36)).toInt())
            } catch (_: Throwable) {
            }
        }
    }

    private fun animateDrawer(to: Float) {
        anim?.cancel()
        anim = ValueAnimator.ofFloat(progress, to).apply {
            duration = 360
            interpolator = DecelerateInterpolator(1.8f)
            addUpdateListener { setProgress(it.animatedValue as Float) }
            start()
        }
    }

    private fun openDrawer() {
        if (drawerOpen) return
        dismissPopup()
        drawerOpen = true
        animateDrawer(1f)
    }

    private fun closeDrawer() {
        if (!drawerOpen) return
        drawerOpen = false
        hideKeyboard()
        search.setText("")
        drawerList.scrollToPosition(0)
        animateDrawer(0f)
    }

    private fun hideKeyboard() {
        val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
        imm.hideSoftInputFromWindow(root.windowToken, 0)
        search.clearFocus()
    }

    private fun expandNotifications() {
        try {
            val sb = getSystemService("statusbar")
            Class.forName("android.app.StatusBarManager")
                .getMethod("expandNotificationsPanel").invoke(sb)
        } catch (_: Exception) {
        }
    }

    // ---------------------------------------------------------------- menus

    private fun dismissPopup() {
        popup?.dismiss()
        popup = null
    }

    private fun showAppMenu(app: AppInfo, anchor: View) {
        val inDock = dockPkgs().contains(app.pkg)
        val items = listOf<Pair<String, () -> Unit>>(
            "App info" to {
                openIntentSafely(
                    Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${app.pkg}"))
                )
            },
            (if (inDock) "Remove from Dock" else "Add to Dock") to { toggleDock(app) },
            "Uninstall" to {
                openIntentSafely(Intent(Intent.ACTION_DELETE, Uri.parse("package:${app.pkg}")))
            }
        )
        val loc = IntArray(2)
        anchor.getLocationOnScreen(loc)
        showMenu(items, loc[0] + anchor.width / 2, loc[1], loc[1] + anchor.height)
    }

    private fun showHomeMenu() {
        val items = listOf<Pair<String, () -> Unit>>(
            "Wallpapers" to { openIntentSafely(Intent(Intent.ACTION_SET_WALLPAPER)) },
            "App drawer" to { openDrawer() },
            "Phone settings" to { openIntentSafely(Intent(Settings.ACTION_SETTINGS)) },
            "Default home app" to { openIntentSafely(Intent(Settings.ACTION_HOME_SETTINGS)) }
        )
        showMenu(items, lastX.toInt(), lastY.toInt() - dp(10), lastY.toInt() + dp(10))
    }

    private fun showMenu(items: List<Pair<String, () -> Unit>>, cx: Int, top: Int, bottom: Int) {
        dismissPopup()
        val cardW = dp(204)
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = GradientDrawable().apply {
                setColor(0xF5FFFFFF.toInt())
                cornerRadius = dpf(22f)
            }
            setPadding(dp(6), dp(8), dp(6), dp(8))
        }
        val pw = PopupWindow(card, cardW, ViewGroup.LayoutParams.WRAP_CONTENT, true)
        items.forEach { (title, action) ->
            val tv = TextView(this).apply {
                text = title
                textSize = 15f
                setTextColor(0xFF1C1C1E.toInt())
                setPadding(dp(16), dp(13), dp(16), dp(13))
                setOnClickListener {
                    pw.dismiss()
                    action()
                }
            }
            card.addView(tv, LinearLayout.LayoutParams(-1, -2))
        }
        card.measure(
            View.MeasureSpec.makeMeasureSpec(cardW, View.MeasureSpec.EXACTLY),
            View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED)
        )
        val cardH = card.measuredHeight
        val sw = resources.displayMetrics.widthPixels
        val sh = resources.displayMetrics.heightPixels
        val above = bottom + cardH + dp(24) > sh
        val y = if (above) top - cardH - dp(6) else bottom + dp(6)
        val x = min(max(cx - cardW / 2, dp(12)), sw - cardW - dp(12))
        pw.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        pw.elevation = dpf(14f)
        pw.isOutsideTouchable = true
        pw.setOnDismissListener { if (popup === pw) popup = null }
        popup = pw
        pw.showAtLocation(root, Gravity.TOP or Gravity.START, x, max(dp(24), y))
        card.pivotX = (cx - x).toFloat()
        card.pivotY = if (above) cardH.toFloat() else 0f
        card.scaleX = 0.7f
        card.scaleY = 0.7f
        card.alpha = 0f
        card.animate().scaleX(1f).scaleY(1f).alpha(1f).setDuration(220)
            .setInterpolator(DecelerateInterpolator(2f)).start()
    }

    private fun toggleDock(app: AppInfo) {
        val list = dockPkgs().toMutableList()
        if (list.contains(app.pkg)) {
            list.remove(app.pkg)
        } else {
            if (list.size >= 4) {
                Toast.makeText(this, "Dock is full (max 4)", Toast.LENGTH_SHORT).show()
                return
            }
            list.add(app.pkg)
        }
        prefs.edit().putString("dock", list.joinToString(",")).apply()
        lastBuiltW = 0
        rebuild()
    }

    private fun openIntentSafely(i: Intent) {
        try {
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            startActivity(i)
        } catch (_: Exception) {
            Toast.makeText(this, "Not available on this phone", Toast.LENGTH_SHORT).show()
        }
    }

    // ---------------------------------------------------------------- drawer adapter

    private inner class DrawerAdapter : RecyclerView.Adapter<DrawerAdapter.VH>() {
        private var all: List<AppInfo> = emptyList()
        var items: List<AppInfo> = emptyList()

        inner class VH(val cell: IconCell) : RecyclerView.ViewHolder(cell)

        fun setAll(list: List<AppInfo>) {
            all = list
            filter(search.text?.toString() ?: "")
        }

        fun filter(q: String) {
            val s = q.trim().lowercase()
            items = if (s.isEmpty()) all else all.filter { it.label.lowercase().contains(s) }
            notifyDataSetChanged()
        }

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
            val cell = IconCell(parent.context)
            cell.layoutParams = RecyclerView.LayoutParams(-1, dp(104))
            return VH(cell)
        }

        override fun getItemCount() = items.size

        override fun onBindViewHolder(holder: VH, position: Int) {
            val app = items[position]
            holder.cell.bind(app)
            holder.cell.setOnClickListener { launch(app, holder.cell.icon) }
            holder.cell.setOnLongClickListener { showAppMenu(app, holder.cell); true }
        }
    }
}
