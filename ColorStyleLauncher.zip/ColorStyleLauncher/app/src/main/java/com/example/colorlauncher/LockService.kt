package com.example.colorlauncher

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.view.accessibility.AccessibilityEvent

/** Lets the launcher lock the screen on a double-tap. Needs to be switched on in Accessibility settings. */
class LockService : AccessibilityService() {

    companion object {
        var instance: LockService? = null
    }

    override fun onServiceConnected() {
        instance = this
    }

    override fun onUnbind(intent: Intent?): Boolean {
        instance = null
        return super.onUnbind(intent)
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}

    override fun onInterrupt() {}

    fun lock() {
        performGlobalAction(GLOBAL_ACTION_LOCK_SCREEN)
    }
}
