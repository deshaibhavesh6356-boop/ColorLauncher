package com.example.colorlauncher

import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.ViewOutlineProvider
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextClock
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import java.lang.ref.WeakReference

class BuiltinKind(val id: String, val title: String, val spanX: Int, val spanY: Int)

object Builtin {
    val kinds = listOf(
        BuiltinKind("clock", "Clock", 4, 2),
        BuiltinKind("weather", "Weather", 2, 2),
        BuiltinKind("battery", "Battery", 2, 2),
        BuiltinKind("calendar", "Next event", 4, 1),
        BuiltinKind("music", "Music", 4, 2),
        BuiltinKind("actions", "Quick actions", 4, 1),
        BuiltinKind("search", "Search bar", 4, 1)
    )
}

/**
 * Widgets that are part of the launcher itself, in the airy ColorOS 17 look
 * (frosted white cards, big soft numbers, round buttons). They always work, because they do not
 * depend on another app being awake.
 */
class WidgetFactory(
    private val act: AppCompatActivity,
    private val glance: Glance,
    private val onAction: (String) -> Unit
) {
    private class Live(val view: WeakReference<View>, val update: () -> Unit)

    private val live = ArrayList<Live>()
    private val dark = 0xFF1C1B22.toInt()
    private val softDark = 0xB31C1B22.toInt()
    private val green = 0xFF2DBE6C.toInt()
    private val red = 0xFFE5484D.toInt()

    init {
        glance.listeners.add { refresh() }
    }

    private fun dp(v: Int) = (v * act.resources.displayMetrics.density).toInt()

    fun refresh() {
        val iter = live.iterator()
        while (iter.hasNext()) {
            val l = iter.next()
            if (l.view.get() == null) {
                iter.remove()
            } else {
                try {
                    l.update()
                } catch (e: Exception) {
                    // ignore
                }
            }
        }
    }

    private fun register(root: View, update: () -> Unit) {
        live.add(Live(WeakReference(root), update))
        update()
    }

    /** Outer frame (leaves a small gap between neighbouring widgets) holding one frosted card. */
    private fun frame(): Pair<FrameLayout, FrameLayout> {
        val outer = FrameLayout(act)
        outer.setPadding(dp(4), dp(4), dp(4), dp(4))
        val card = FrameLayout(act)
        card.background = UiStyle.panel(act, "light", 28f, 60, card)
        card.setPadding(dp(16), dp(12), dp(16), dp(12))
        outer.addView(card, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        return Pair(outer, card)
    }

    private fun text(size: Float, color: Int, face: String = "sans-serif"): TextView {
        val t = TextView(act)
        t.textSize = size
        t.setTextColor(color)
        t.typeface = Typeface.create(face, Typeface.NORMAL)
        t.maxLines = 1
        t.ellipsize = android.text.TextUtils.TruncateAt.END
        return t
    }

    private fun darkIcon(res: Int, sizeDp: Int): ImageView {
        val i = ImageView(act)
        i.setImageResource(res)
        i.setColorFilter(dark)
        i.layoutParams = LinearLayout.LayoutParams(dp(sizeDp), dp(sizeDp))
        return i
    }

    private fun circleButton(iconRes: Int, sizeDp: Int, onClick: () -> Unit): FrameLayout {
        val f = FrameLayout(act)
        val bg = GradientDrawable()
        bg.shape = GradientDrawable.OVAL
        bg.setColor(Color.argb(150, 255, 255, 255))
        bg.setStroke(dp(1), Color.argb(170, 255, 255, 255))
        f.background = bg
        val icon = ImageView(act)
        icon.setImageResource(iconRes)
        icon.setColorFilter(dark)
        val pad = dp(sizeDp / 4)
        icon.setPadding(pad, pad, pad, pad)
        f.addView(icon, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        f.layoutParams = LinearLayout.LayoutParams(dp(sizeDp), dp(sizeDp))
        f.setOnClickListener { onClick() }
        return f
    }

    fun create(kind: String): View? = when (kind) {
        "clock" -> clockWidget()
        "weather" -> weatherWidget()
        "battery" -> batteryWidget()
        "calendar" -> calendarWidget()
        "music" -> musicWidget()
        "actions" -> actionsWidget()
        "search" -> searchWidget()
        else -> null
    }

    private fun clockWidget(): View {
        val (outer, card) = frame()
        val box = LinearLayout(act)
        box.orientation = LinearLayout.VERTICAL
        box.gravity = Gravity.CENTER_VERTICAL
        val time = TextClock(act)
        time.format12Hour = "hh:mm"
        time.format24Hour = "HH:mm"
        time.textSize = 60f
        time.typeface = Typeface.create("sans-serif-thin", Typeface.NORMAL)
        time.setTextColor(dark)
        time.includeFontPadding = false
        val date = TextClock(act)
        date.format12Hour = "EEEE, d MMMM"
        date.format24Hour = "EEEE, d MMMM"
        date.textSize = 15f
        date.setTextColor(softDark)
        val info = text(14f, softDark)
        box.addView(time)
        box.addView(date)
        box.addView(info)
        card.addView(box, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        register(outer) {
            info.text = if (glance.tempText != "--" && glance.tempText.isNotEmpty()) glance.tempText + "   " + glance.cityText else ""
        }
        return outer
    }

    private fun weatherWidget(): View {
        val (outer, card) = frame()
        val box = LinearLayout(act)
        box.orientation = LinearLayout.VERTICAL
        box.gravity = Gravity.CENTER_VERTICAL
        val icon = darkIcon(R.drawable.ic_cloud, 30)
        val temp = text(44f, dark, "sans-serif-thin")
        val city = text(13f, softDark)
        box.addView(icon)
        box.addView(temp)
        box.addView(city)
        card.addView(box, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        register(outer) {
            icon.setImageResource(glance.weatherIcon)
            temp.text = glance.tempText
            city.text = glance.cityText
        }
        return outer
    }

    private fun batteryWidget(): View {
        val (outer, card) = frame()
        val box = LinearLayout(act)
        box.orientation = LinearLayout.VERTICAL
        box.gravity = Gravity.CENTER_VERTICAL
        val pct = text(44f, dark, "sans-serif-thin")
        val bar = LinearLayout(act)
        bar.orientation = LinearLayout.HORIZONTAL
        val track = GradientDrawable()
        track.cornerRadius = dp(6).toFloat()
        track.setColor(Color.argb(70, 28, 27, 34))
        bar.background = track
        val fill = View(act)
        val rest = View(act)
        bar.addView(fill, LinearLayout.LayoutParams(0, dp(10), 1f))
        bar.addView(rest, LinearLayout.LayoutParams(0, dp(10), 0f))
        val label = text(13f, softDark)
        box.addView(pct)
        val bp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(10))
        bp.topMargin = dp(6)
        bp.bottomMargin = dp(8)
        box.addView(bar, bp)
        box.addView(label)
        card.addView(box, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        register(outer) {
            val p = glance.batteryPct.coerceIn(0, 100)
            pct.text = if (glance.batteryPct < 0) "--" else "$p%"
            (fill.layoutParams as LinearLayout.LayoutParams).weight = p.toFloat()
            (rest.layoutParams as LinearLayout.LayoutParams).weight = (100 - p).toFloat()
            val f = GradientDrawable()
            f.cornerRadius = dp(6).toFloat()
            f.setColor(if (glance.charging) green else if (p <= 20) red else dark)
            fill.background = f
            bar.requestLayout()
            label.text = if (glance.charging) "Charging" else "Battery"
        }
        return outer
    }

    private fun calendarWidget(): View {
        val (outer, card) = frame()
        val row = LinearLayout(act)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        row.addView(darkIcon(R.drawable.ic_calendar, 28))
        val col = LinearLayout(act)
        col.orientation = LinearLayout.VERTICAL
        val time = text(17f, dark)
        val title = text(13f, softDark)
        col.addView(time)
        col.addView(title)
        val lp = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        lp.marginStart = dp(14)
        row.addView(col, lp)
        card.addView(row, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        outer.setOnClickListener {
            if (glance.calendarTime == "Calendar") glance.askCalendar() else onAction("calendar")
        }
        register(outer) {
            time.text = glance.calendarTime
            title.text = glance.calendarTitle
        }
        return outer
    }

    private fun musicWidget(): View {
        val (outer, card) = frame()
        val box = LinearLayout(act)
        box.orientation = LinearLayout.VERTICAL
        box.gravity = Gravity.CENTER_VERTICAL

        val top = LinearLayout(act)
        top.orientation = LinearLayout.HORIZONTAL
        top.gravity = Gravity.CENTER_VERTICAL
        val art = ImageView(act)
        art.scaleType = ImageView.ScaleType.CENTER_CROP
        val artBg = GradientDrawable()
        artBg.cornerRadius = dp(14).toFloat()
        artBg.setColor(Color.argb(60, 28, 27, 34))
        art.background = artBg
        art.clipToOutline = true
        art.outlineProvider = ViewOutlineProvider.BACKGROUND
        top.addView(art, LinearLayout.LayoutParams(dp(60), dp(60)))
        val col = LinearLayout(act)
        col.orientation = LinearLayout.VERTICAL
        val title = text(16f, dark)
        val artist = text(13f, softDark)
        col.addView(title)
        col.addView(artist)
        val cp = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        cp.marginStart = dp(12)
        top.addView(col, cp)
        box.addView(top)

        val controls = LinearLayout(act)
        controls.orientation = LinearLayout.HORIZONTAL
        controls.gravity = Gravity.CENTER
        val prev = circleButton(R.drawable.ic_prev, 40) { glance.skipPrev() }
        val playBtn = circleButton(R.drawable.ic_play, 46) { glance.togglePlay() }
        val next = circleButton(R.drawable.ic_next, 40) { glance.skipNext() }
        val gap = dp(14)
        val p1 = LinearLayout.LayoutParams(dp(40), dp(40))
        p1.marginEnd = gap
        val p2 = LinearLayout.LayoutParams(dp(46), dp(46))
        val p3 = LinearLayout.LayoutParams(dp(40), dp(40))
        p3.marginStart = gap
        controls.addView(prev, p1)
        controls.addView(playBtn, p2)
        controls.addView(next, p3)
        val cl = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        cl.topMargin = dp(8)
        box.addView(controls, cl)

        card.addView(box, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        top.setOnClickListener { glance.openPlayer() }
        register(outer) {
            if (glance.hasMusic) {
                title.text = glance.musicTitle
                artist.text = glance.musicArtist
                art.setImageBitmap(glance.musicArt)
                ((playBtn.getChildAt(0)) as ImageView).setImageResource(if (glance.musicPlaying) R.drawable.ic_pause else R.drawable.ic_play)
            } else {
                title.text = "Nothing playing"
                artist.text = "Allow notification access to control music"
                art.setImageDrawable(null)
                ((playBtn.getChildAt(0)) as ImageView).setImageResource(R.drawable.ic_play)
            }
        }
        return outer
    }

    /** A Google-style search bar: always works, opens the Google app (or the browser). */
    private fun searchWidget(): View {
        val (outer, card) = frame()
        card.setPadding(dp(14), dp(6), dp(8), dp(6))
        val row = LinearLayout(act)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        row.addView(darkIcon(R.drawable.ic_search, 24))
        val label = text(16f, softDark)
        label.text = "Search"
        val lp = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        lp.marginStart = dp(12)
        row.addView(label, lp)
        row.addView(circleButton(R.drawable.ic_mic, 44) { onAction("voice") }, LinearLayout.LayoutParams(dp(44), dp(44)))
        val lens = circleButton(R.drawable.ic_camera, 44) { onAction("lens") }
        val lp2 = LinearLayout.LayoutParams(dp(44), dp(44))
        lp2.marginStart = dp(6)
        row.addView(lens, lp2)
        card.addView(row, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        outer.setOnClickListener { onAction("search") }
        return outer
    }

    private fun actionsWidget(): View {
        val (outer, card) = frame()
        card.setPadding(dp(10), dp(8), dp(10), dp(8))
        val row = LinearLayout(act)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        val items = listOf(
            Pair(R.drawable.ic_torch, "torch"),
            Pair(R.drawable.ic_camera, "camera"),
            Pair(R.drawable.ic_calc, "calc"),
            Pair(R.drawable.ic_clock, "clock"),
            Pair(R.drawable.ic_settings, "settings")
        )
        for ((res, name) in items) {
            val holder = FrameLayout(act)
            val b = circleButton(res, 46) { onAction(name) }
            holder.addView(b, FrameLayout.LayoutParams(dp(46), dp(46), Gravity.CENTER))
            row.addView(holder, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f))
        }
        card.addView(row, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        return outer
    }
}
