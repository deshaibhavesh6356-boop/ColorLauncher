package com.example.colorlauncher

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ColorFilter
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.drawable.Drawable
import android.util.AttributeSet
import android.view.ViewGroup

/** A grid of cols x rows cells. Children sit at (cellX, cellY) and can span several cells. */
class CellLayout(ctx: Context) : ViewGroup(ctx) {

    var cols = 4
    var rows = 6

    class LP(var cellX: Int, var cellY: Int, var spanX: Int, var spanY: Int) :
        ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)

    private val hintPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private var hint: RectF? = null
    private var hintMerge = false

    init {
        setWillNotDraw(false)
        clipChildren = false
        clipToPadding = false
    }

    private fun cw(): Int = (width - paddingLeft - paddingRight) / cols
    private fun ch(): Int = (height - paddingTop - paddingBottom) / rows

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        val w = MeasureSpec.getSize(widthMeasureSpec)
        val h = MeasureSpec.getSize(heightMeasureSpec)
        setMeasuredDimension(w, h)
        val cellW = (w - paddingLeft - paddingRight) / cols
        val cellH = (h - paddingTop - paddingBottom) / rows
        for (i in 0 until childCount) {
            val c = getChildAt(i)
            val lp = c.layoutParams as LP
            c.measure(
                MeasureSpec.makeMeasureSpec(cellW * lp.spanX, MeasureSpec.EXACTLY),
                MeasureSpec.makeMeasureSpec(cellH * lp.spanY, MeasureSpec.EXACTLY)
            )
        }
    }

    override fun onLayout(changed: Boolean, l: Int, t: Int, r: Int, b: Int) {
        val cellW = cw()
        val cellH = ch()
        for (i in 0 until childCount) {
            val c = getChildAt(i)
            val lp = c.layoutParams as LP
            val left = paddingLeft + lp.cellX * cellW
            val top = paddingTop + lp.cellY * cellH
            c.layout(left, top, left + cellW * lp.spanX, top + cellH * lp.spanY)
        }
    }

    /** Returns [cellX, cellY] for a point in this view's own coordinates. */
    fun cellAt(px: Float, py: Float): IntArray {
        val cellW = cw().coerceAtLeast(1)
        val cellH = ch().coerceAtLeast(1)
        val cx = ((px - paddingLeft) / cellW).toInt().coerceIn(0, cols - 1)
        val cy = ((py - paddingTop) / cellH).toInt().coerceIn(0, rows - 1)
        return intArrayOf(cx, cy)
    }

    /** Rectangle of a block of cells, in this view's own coordinates. */
    fun cellRect(cx: Int, cy: Int, sx: Int, sy: Int): Rect {
        val cellW = cw()
        val cellH = ch()
        val l = paddingLeft + cx * cellW
        val t = paddingTop + cy * cellH
        return Rect(l, t, l + cellW * sx, t + cellH * sy)
    }

    fun showHint(cx: Int, cy: Int, sx: Int, sy: Int, merge: Boolean) {
        val cellW = cw()
        val cellH = ch()
        val l = (paddingLeft + cx * cellW + 4).toFloat()
        val t = (paddingTop + cy * cellH + 4).toFloat()
        hint = RectF(l, t, l + cellW * sx - 8, t + cellH * sy - 8)
        hintMerge = merge
        invalidate()
    }

    fun clearHint() {
        if (hint != null) {
            hint = null
            invalidate()
        }
    }

    override fun onDraw(canvas: Canvas) {
        val r = hint ?: return
        hintPaint.color = if (hintMerge) 0x66FFFFFF else 0x33FFFFFF
        val rad = resources.displayMetrics.density * 18f
        canvas.drawRoundRect(r, rad, rad, hintPaint)
    }

    override fun checkLayoutParams(p: ViewGroup.LayoutParams?): Boolean = p is LP
    override fun generateDefaultLayoutParams(): ViewGroup.LayoutParams = LP(0, 0, 1, 1)
    override fun generateLayoutParams(attrs: AttributeSet?): ViewGroup.LayoutParams = LP(0, 0, 1, 1)
    override fun generateLayoutParams(p: ViewGroup.LayoutParams?): ViewGroup.LayoutParams = LP(0, 0, 1, 1)
}

/** Folder icon: translucent rounded square with up to 4 mini app icons. */
class FolderDrawable(private val bitmaps: List<Bitmap>) : Drawable() {
    private val bg = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.argb(95, 255, 255, 255) }
    private val p = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)

    override fun draw(canvas: Canvas) {
        val b = bounds
        val w = b.width().toFloat()
        val rad = w * 0.28f
        canvas.drawRoundRect(RectF(b), rad, rad, bg)
        val pad = w * 0.13f
        val gap = w * 0.06f
        val s = (w - 2 * pad - gap) / 2
        for (i in 0 until minOf(4, bitmaps.size)) {
            val col = i % 2
            val row = i / 2
            val l = b.left + pad + col * (s + gap)
            val t = b.top + pad + row * (s + gap)
            canvas.drawBitmap(bitmaps[i], null, RectF(l, t, l + s, t + s), p)
        }
    }

    override fun setAlpha(alpha: Int) {}
    override fun setColorFilter(colorFilter: ColorFilter?) {}

    @Deprecated("Deprecated in Java")
    override fun getOpacity(): Int = PixelFormat.TRANSLUCENT
}
