package com.example.colorlauncher

import android.app.WallpaperManager
import android.content.Context
import android.content.res.Configuration
import android.graphics.Bitmap
import android.graphics.BitmapShader
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ColorFilter
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.LinearGradient
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.RadialGradient
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.view.View
import androidx.core.content.ContextCompat
import androidx.core.graphics.ColorUtils
import kotlin.math.abs
import kotlin.math.min

/** Shared state for the liquid glass look. */
object Glass {
    /** -1..1. Moves the bright rim light and glint (phone tilt and page scrolling change it). */
    @Volatile
    var shift = 0f

    /** Main colours of the wallpaper (no permission needed). Used to tint glass when we can't read the wallpaper itself. */
    var colors = intArrayOf(0xFF5B5FC7.toInt(), 0xFFB45BC0.toInt(), 0xFFE9806B.toInt())

    fun updateColors(ctx: Context) {
        try {
            val wc = WallpaperManager.getInstance(ctx).getWallpaperColors(WallpaperManager.FLAG_SYSTEM) ?: return
            val p = wc.primaryColor.toArgb()
            val s = wc.secondaryColor?.toArgb() ?: p
            val t = wc.tertiaryColor?.toArgb() ?: s
            colors = intArrayOf(p, s, t)
        } catch (e: Exception) {
            // keep the old colours
        }
    }

    fun colorAt(t: Float): Int {
        val c = colors
        val f = t.coerceIn(0f, 1f)
        return if (f < 0.5f) ColorUtils.blendARGB(c[0], c[1], f * 2f) else ColorUtils.blendARGB(c[1], c[2], (f - 0.5f) * 2f)
    }
}

/** Backgrounds for the dock, search bar, folders and panels in three styles. */
object UiStyle {

    fun isDark(ctx: Context): Boolean =
        (ctx.resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES

    /** Android 12+ wallpaper colours (Material You); a fallback colour on older phones. */
    fun sys(ctx: Context, resId: Int, fallback: Int): Int =
        if (Build.VERSION.SDK_INT >= 31) ContextCompat.getColor(ctx, resId) else fallback

    fun panel(ctx: Context, style: String, radiusDp: Float, strength: Int, anchor: View? = null): Drawable {
        val density = ctx.resources.displayMetrics.density
        val r = radiusDp * density
        return when (style) {
            "glass" -> GlassDrawable(r, strength, density, anchor)
            "material" -> GradientDrawable().apply {
                cornerRadius = r
                val base = sys(ctx, android.R.color.system_neutral2_800, 0xFF2B2D33.toInt())
                setColor(ColorUtils.setAlphaComponent(base, 238))
            }
            else -> GradientDrawable().apply {
                cornerRadius = r
                setColor(Color.argb((strength * 255 / 100).coerceIn(0, 255), 255, 255, 255))
            }
        }
    }
}

/**
 * Liquid glass, in layers (bottom to top):
 *  1. the blurred wallpaper behind the panel (or a wallpaper-coloured fog if we can't read the wallpaper),
 *  2. a smoky tint so white text stays readable,
 *  3. a lens ring around the edge where the wallpaper looks magnified (the "refraction" look),
 *  4. a soft sheen and a moving glint,
 *  5. a thick bright rim that is strongest at the ends, and a dark line just inside it.
 * The rim and glint slide when [Glass.shift] changes, so the glass reacts to motion.
 */
class GlassDrawable(
    private val radius: Float,
    strength: Int,
    private val density: Float,
    private val anchor: View?
) : Drawable() {

    private val a = (strength * 255 / 100).coerceIn(70, 235)

    private val fog = Paint(Paint.ANTI_ALIAS_FLAG)
    private val backPaint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
    private val ringPaint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
    private val ringVeil = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.argb(34, 255, 255, 255) }
    private val body = Paint(Paint.ANTI_ALIAS_FLAG)
    private val sheen = Paint(Paint.ANTI_ALIAS_FLAG)
    private val glint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rim = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 2.2f * density
    }
    private val darkRim = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 1.1f * density
        color = Color.argb(70, 0, 0, 0)
    }

    private val r = RectF()
    private val r2 = RectF()
    private val src = RectF()
    private val srcMag = RectF()
    private val loc = IntArray(2)
    private val m1 = Matrix()
    private val m2 = Matrix()
    private val ringPath = Path()
    private var shader1: BitmapShader? = null
    private var shader2: BitmapShader? = null
    private var shaderFor: Bitmap? = null

    private var builtW = -1
    private var builtH = -1
    private var builtShift = 99f
    private var rad = radius

    init {
        val cm = ColorMatrix()
        cm.setSaturation(1.3f)
        backPaint.colorFilter = ColorMatrixColorFilter(cm)
        ringPaint.colorFilter = ColorMatrixColorFilter(cm)
        ringPath.fillType = Path.FillType.EVEN_ODD
    }

    private fun build(b: Rect, shift: Float) {
        val w = b.width().toFloat()
        val h = b.height().toFloat()
        val top = b.top.toFloat()
        val bottom = b.bottom.toFloat()
        rad = min(radius, min(w, h) / 2f)

        body.shader = LinearGradient(
            0f, top, 0f, bottom,
            intArrayOf(Color.argb(a * 55 / 100, 34, 38, 56), Color.argb(a * 80 / 100, 12, 14, 24)),
            null, Shader.TileMode.CLAMP
        )
        sheen.shader = LinearGradient(
            0f, top, 0f, top + h * 0.6f,
            intArrayOf(Color.argb(105, 255, 255, 255), Color.argb(0, 255, 255, 255)),
            null, Shader.TileMode.CLAMP
        )
        val gx = b.left + w * (0.5f + shift * 0.35f)
        glint.shader = RadialGradient(
            gx, top + h * 0.1f, w * 0.28f + 1f,
            intArrayOf(Color.argb(120, 255, 255, 255), Color.argb(0, 255, 255, 255)),
            null, Shader.TileMode.CLAMP
        )
        val dx = shift * w * 0.5f
        rim.shader = LinearGradient(
            b.left - dx, top, b.right - dx, bottom,
            intArrayOf(Color.argb(240, 255, 255, 255), Color.argb(45, 255, 255, 255), Color.argb(240, 255, 255, 255)),
            floatArrayOf(0f, 0.5f, 1f), Shader.TileMode.CLAMP
        )

        // ring around the edge for the lens look
        val ringW = min(5f * density, min(w, h) / 3f)
        ringPath.reset()
        r.set(b)
        ringPath.addRoundRect(r, rad, rad, Path.Direction.CW)
        r2.set(r)
        r2.inset(ringW, ringW)
        ringPath.addRoundRect(r2, max0(rad - ringW), max0(rad - ringW), Path.Direction.CW)

        builtW = b.width()
        builtH = b.height()
        builtShift = shift
    }

    private fun max0(v: Float) = if (v < 0f) 0f else v

    override fun draw(canvas: Canvas) {
        val b = bounds
        if (b.width() < 2 || b.height() < 2) return
        val shift = Glass.shift
        if (builtW != b.width() || builtH != b.height() || abs(shift - builtShift) > 0.012f) build(b, shift)
        r.set(b)

        // 1. what is behind the panel
        var haveBitmap = false
        val v = anchor
        val bd = Backdrop.bitmap
        if (v != null && v.isAttachedToWindow) {
            v.getLocationOnScreen(loc)
            val dm = v.resources.displayMetrics
            if (Backdrop.enabled && bd != null) {
                val sx = bd.width / dm.widthPixels.toFloat()
                val sy = bd.height / dm.heightPixels.toFloat()
                src.set(loc[0] * sx, loc[1] * sy, (loc[0] + b.width()) * sx, (loc[1] + b.height()) * sy)
                if (shaderFor !== bd) {
                    shader1 = BitmapShader(bd, Shader.TileMode.CLAMP, Shader.TileMode.CLAMP)
                    shader2 = BitmapShader(bd, Shader.TileMode.CLAMP, Shader.TileMode.CLAMP)
                    shaderFor = bd
                }
                m1.setRectToRect(src, r, Matrix.ScaleToFit.FILL)
                shader1?.setLocalMatrix(m1)
                backPaint.shader = shader1
                canvas.drawRoundRect(r, rad, rad, backPaint)
                haveBitmap = true
            } else {
                val t = (loc[1] + b.height() / 2f) / dm.heightPixels
                fog.color = ColorUtils.setAlphaComponent(Glass.colorAt(t), 150)
                canvas.drawRoundRect(r, rad, rad, fog)
            }
        }

        // 2. smoky tint (keeps text readable)
        body.alpha = if (haveBitmap) 205 else 255
        canvas.drawRoundRect(r, rad, rad, body)

        // 3. lens ring: the wallpaper looks magnified near the edge
        if (haveBitmap) {
            val cx = (src.left + src.right) / 2f
            val cy = (src.top + src.bottom) / 2f
            val hw = src.width() / 2f / 1.22f
            val hh = src.height() / 2f / 1.22f
            srcMag.set(cx - hw, cy - hh, cx + hw, cy + hh)
            m2.setRectToRect(srcMag, r, Matrix.ScaleToFit.FILL)
            shader2?.setLocalMatrix(m2)
            ringPaint.shader = shader2
            canvas.save()
            canvas.clipPath(ringPath)
            canvas.drawRoundRect(r, rad, rad, ringPaint)
            canvas.drawRoundRect(r, rad, rad, ringVeil)
            canvas.restore()
        }

        // 4. sheen and glint
        r2.set(r)
        r2.inset(density * 1.5f, density * 1.5f)
        canvas.drawRoundRect(r2, rad, rad, sheen)
        canvas.drawRoundRect(r2, rad, rad, glint)

        // 5. rims
        r2.set(r)
        r2.inset(density * 3.2f, density * 3.2f)
        canvas.drawRoundRect(r2, rad, rad, darkRim)
        r2.set(r)
        r2.inset(rim.strokeWidth / 2f, rim.strokeWidth / 2f)
        canvas.drawRoundRect(r2, rad, rad, rim)
    }

    override fun setAlpha(alpha: Int) {}
    override fun setColorFilter(colorFilter: ColorFilter?) {}

    @Deprecated("Deprecated in Java")
    override fun getOpacity(): Int = PixelFormat.TRANSLUCENT
}
