package com.example.colorlauncher

import android.content.Context
import android.content.res.Configuration
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ColorFilter
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.os.Build
import androidx.core.content.ContextCompat
import androidx.core.graphics.ColorUtils
import kotlin.math.min

/** Backgrounds for the dock, search bar, folders and panels in three styles. */
object UiStyle {

    fun isDark(ctx: Context): Boolean =
        (ctx.resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES

    /** Android 12+ wallpaper colours (Material You); a fallback colour on older phones. */
    fun sys(ctx: Context, resId: Int, fallback: Int): Int =
        if (Build.VERSION.SDK_INT >= 31) ContextCompat.getColor(ctx, resId) else fallback

    fun panel(ctx: Context, style: String, radiusDp: Float, strength: Int): Drawable {
        val density = ctx.resources.displayMetrics.density
        val r = radiusDp * density
        return when (style) {
            "glass" -> GlassDrawable(r, strength, density)
            "material" -> GradientDrawable().apply {
                cornerRadius = r
                val base = sys(ctx, android.R.color.system_neutral2_800, 0xFF2B2D33.toInt())
                setColor(ColorUtils.setAlphaComponent(base, 238))
            }
            else -> GradientDrawable().apply {
                cornerRadius = r
                setColor(Color.argb((strength * 255 / 100).coerceIn(0, 255), 255, 255, 255))
            }
        }
    }
}

/**
 * "Liquid glass": smoky translucent body, a soft sheen on top and a bright rim that is
 * strong at the top-left and bottom-right and faint in between.
 */
class GlassDrawable(
    private val radius: Float,
    strength: Int,
    private val density: Float
) : Drawable() {

    private val a = (strength * 255 / 100).coerceIn(20, 220)
    private val body = Paint(Paint.ANTI_ALIAS_FLAG)
    private val sheen = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rim = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 1.3f * density
    }
    private val rimInner = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 0.8f * density
        color = Color.argb(30, 255, 255, 255)
    }
    private val r = RectF()
    private val r2 = RectF()

    override fun onBoundsChange(bounds: Rect) {
        super.onBoundsChange(bounds)
        val top = bounds.top.toFloat()
        val bottom = bounds.bottom.toFloat()
        body.shader = LinearGradient(
            0f, top, 0f, bottom,
            intArrayOf(Color.argb(min(255, a + 30), 255, 255, 255), Color.argb(a * 7 / 10, 40, 44, 56)),
            null, Shader.TileMode.CLAMP
        )
        sheen.shader = LinearGradient(
            0f, top, 0f, top + bounds.height() * 0.55f,
            intArrayOf(Color.argb(95, 255, 255, 255), Color.argb(0, 255, 255, 255)),
            null, Shader.TileMode.CLAMP
        )
        rim.shader = LinearGradient(
            bounds.left.toFloat(), top, bounds.right.toFloat(), bottom,
            intArrayOf(Color.argb(220, 255, 255, 255), Color.argb(30, 255, 255, 255), Color.argb(140, 255, 255, 255)),
            floatArrayOf(0f, 0.55f, 1f), Shader.TileMode.CLAMP
        )
    }

    override fun draw(canvas: Canvas) {
        r.set(bounds)
        canvas.drawRoundRect(r, radius, radius, body)

        r2.set(r)
        r2.inset(density * 1.5f, density * 1.5f)
        canvas.drawRoundRect(r2, radius, radius, sheen)

        r2.set(r)
        r2.inset(density * 2.4f, density * 2.4f)
        canvas.drawRoundRect(r2, radius, radius, rimInner)

        r2.set(r)
        r2.inset(rim.strokeWidth / 2, rim.strokeWidth / 2)
        canvas.drawRoundRect(r2, radius, radius, rim)
    }

    override fun setAlpha(alpha: Int) {}
    override fun setColorFilter(colorFilter: ColorFilter?) {}

    @Deprecated("Deprecated in Java")
    override fun getOpacity(): Int = PixelFormat.TRANSLUCENT
}
