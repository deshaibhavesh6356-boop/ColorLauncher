package com.example.colorlauncher

import android.animation.ValueAnimator
import android.app.WallpaperManager
import android.content.Context
import android.content.res.Configuration
import android.graphics.Bitmap
import android.graphics.BitmapShader
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ColorFilter
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.LinearGradient
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.RadialGradient
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.view.View
import androidx.core.content.ContextCompat
import androidx.core.graphics.ColorUtils
import kotlin.math.abs
import kotlin.math.min

/** Shared state for the liquid glass look. */
object Glass {
    /** -1..1. Moves the bright rim light and glint (phone tilt and page scrolling change it). */
    @Volatile
    var shift = 0f

    /** Main colours of the wallpaper (no permission needed). Used to tint glass when we can't read the wallpaper itself. */
    var colors = intArrayOf(0xFF5B5FC7.toInt(), 0xFFB45BC0.toInt(), 0xFFE9806B.toInt())

    fun updateColors(ctx: Context) {
        try {
            val wc = WallpaperManager.getInstance(ctx).getWallpaperColors(WallpaperManager.FLAG_SYSTEM) ?: return
            val p = wc.primaryColor.toArgb()
            val s = wc.secondaryColor?.toArgb() ?: p
            val t = wc.tertiaryColor?.toArgb() ?: s
            colors = intArrayOf(p, s, t)
        } catch (e: Exception) {
            // keep the old colours
        }
    }

    fun colorAt(t: Float): Int {
        val c = colors
        val f = t.coerceIn(0f, 1f)
        return if (f < 0.5f) ColorUtils.blendARGB(c[0], c[1], f * 2f) else ColorUtils.blendARGB(c[1], c[2], (f - 0.5f) * 2f)
    }
}

/** Backgrounds for the dock, search bar, folders and panels in three styles. */
object UiStyle {

    fun isDark(ctx: Context): Boolean =
        (ctx.resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES

    /** Android 12+ wallpaper colours (Material You); a fallback colour on older phones. */
    fun sys(ctx: Context, resId: Int, fallback: Int): Int =
        if (Build.VERSION.SDK_INT >= 31) ContextCompat.getColor(ctx, resId) else fallback

    fun panel(ctx: Context, style: String, radiusDp: Float, strength: Int, anchor: View? = null): Drawable {
        val density = ctx.resources.displayMetrics.density
        val r = radiusDp * density
        return when (style) {
            "glass" -> GlassDrawable(r, strength, density, anchor)
            "light" -> GlassDrawable(r, strength, density, anchor, true)
            "material" -> GradientDrawable().apply {
                cornerRadius = r
                val base = sys(ctx, android.R.color.system_neutral2_800, 0xFF2B2D33.toInt())
                setColor(ColorUtils.setAlphaComponent(base, 238))
            }
            else -> GradientDrawable().apply {
                cornerRadius = r
                setColor(Color.argb((strength * 255 / 100).coerceIn(0, 255), 255, 255, 255))
            }
        }
    }
}

/**
 * Liquid glass, modelled on a real glass capsule:
 *  1. the blurred wallpaper behind the panel (or a faint wallpaper-coloured fog if we can't read the wallpaper),
 *  2. a dark smoky body so white text stays readable,
 *  3. a lens band along the edge where the wallpaper looks stretched (refraction),
 *  4. a thick metallic rim: bright at the top-left and bottom-right, soft grey in between,
 *     a hairline highlight on the outside and a dark line just inside it,
 *  5. a soft glow under your finger while you touch it.
 * The rim and glint slide when [Glass.shift] changes (tilt, page swipes).
 */
class GlassDrawable(
    private val radius: Float,
    strength: Int,
    private val density: Float,
    private val anchor: View?,
    private val light: Boolean = false
) : Drawable() {

    private val a = (strength * 255 / 100).coerceIn(60, 235)

    private val fog = Paint(Paint.ANTI_ALIAS_FLAG)
    private val backPaint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
    private val bandPaint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
    private val bandVeil = Paint(Paint.ANTI_ALIAS_FLAG)
    private val body = Paint(Paint.ANTI_ALIAS_FLAG)
    private val sheen = Paint(Paint.ANTI_ALIAS_FLAG)
    private val glint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val glow = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rim = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 3.4f * density
    }
    private val hairline = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 0.9f * density
    }
    private val darkRim = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 1.4f * density
    }

    private val r = RectF()
    private val r2 = RectF()
    private val src = RectF()
    private val srcMag = RectF()
    private val loc = IntArray(2)
    private val m1 = Matrix()
    private val m2 = Matrix()
    private val bandPath = Path()
    private val clipPath = Path()
    private var shader1: BitmapShader? = null
    private var shader2: BitmapShader? = null
    private var shaderFor: Bitmap? = null

    private var builtW = -1
    private var builtH = -1
    private var builtShift = 99f
    private var builtTint = 0
    private var rad = radius

    // touch glow
    private var touchAmt = 0f
    private var touchTarget = 0f
    private var tx = 0f
    private var ty = 0f
    private var touchAnim: ValueAnimator? = null

    init {
        if (light) rim.strokeWidth = 1.7f * density
        val cm = ColorMatrix()
        cm.setSaturation(1.15f)
        backPaint.colorFilter = ColorMatrixColorFilter(cm)
        bandPaint.colorFilter = ColorMatrixColorFilter(cm)
        bandPath.fillType = Path.FillType.EVEN_ODD
    }

    /** Called while a finger is on this panel: the glass lights up around the touch. */
    fun touch(x: Float, y: Float, down: Boolean) {
        tx = x
        ty = y
        val target = if (down) 1f else 0f
        if (target == touchTarget) {
            if (down) invalidateSelf()
            return
        }
        touchTarget = target
        touchAnim?.cancel()
        val an = ValueAnimator.ofFloat(touchAmt, target)
        an.duration = if (down) 120L else 420L
        an.addUpdateListener {
            touchAmt = it.animatedValue as Float
            invalidateSelf()
        }
        touchAnim = an
        an.start()
    }

    private fun max0(v: Float) = if (v < 0f) 0f else v

    private fun build(b: Rect, shift: Float, tint: Int) {
        val w = b.width().toFloat()
        val h = b.height().toFloat()
        val top = b.top.toFloat()
        val bottom = b.bottom.toFloat()
        rad = min(radius, min(w, h) / 2f)

        // dark smoky body: a little lighter on top, darker at the bottom
        body.shader = LinearGradient(
            0f, top, 0f, bottom,
            intArrayOf(Color.argb(a * 40 / 100, 40, 42, 52), Color.argb(a * 62 / 100, 10, 11, 17)),
            null, Shader.TileMode.CLAMP
        )
        if (light) {
            // ColorOS 17 style: airy white frosted surface
            body.shader = LinearGradient(
                0f, top, 0f, bottom,
                intArrayOf(Color.argb(170, 255, 255, 255), Color.argb(122, 238, 238, 248)),
                null, Shader.TileMode.CLAMP
            )
        }
        sheen.shader = LinearGradient(
            0f, top, 0f, top + h * 0.5f,
            intArrayOf(Color.argb(if (light) 80 else 46, 255, 255, 255), Color.argb(0, 255, 255, 255)),
            null, Shader.TileMode.CLAMP
        )
        val gx = b.left + w * (0.5f + shift * 0.35f)
        glint.shader = RadialGradient(
            gx, top + h * 0.12f, w * 0.26f + 1f,
            intArrayOf(Color.argb(70, 255, 255, 255), Color.argb(0, 255, 255, 255)),
            null, Shader.TileMode.CLAMP
        )

        // metallic rim: soft grey in the middle, bright towards the corners, picks up a hint of the scene colour
        val dx = shift * w * 0.5f
        val c1 = ColorUtils.blendARGB(Color.argb(235, 255, 255, 255), tint, 0.18f)
        val c2 = ColorUtils.blendARGB(Color.argb(105, 224, 218, 214), tint, 0.28f)
        val c3 = ColorUtils.blendARGB(Color.argb(70, 170, 164, 164), tint, 0.30f)
        val c4 = ColorUtils.blendARGB(Color.argb(190, 252, 248, 244), tint, 0.20f)
        rim.shader = LinearGradient(
            b.left - dx, top, b.right - dx, bottom,
            intArrayOf(c1, c2, c3, c4),
            floatArrayOf(0f, 0.38f, 0.68f, 1f), Shader.TileMode.CLAMP
        )
        hairline.shader = LinearGradient(
            b.left - dx, top, b.right - dx, bottom,
            intArrayOf(Color.argb(255, 255, 255, 255), Color.argb(0, 255, 255, 255), Color.argb(150, 255, 255, 255)),
            floatArrayOf(0f, 0.45f, 1f), Shader.TileMode.CLAMP
        )
        darkRim.shader = LinearGradient(
            b.left.toFloat(), top, b.right.toFloat(), bottom,
            intArrayOf(Color.argb(if (light) 10 else 30, 0, 0, 0), Color.argb(if (light) 34 else 95, 0, 0, 0)),
            null, Shader.TileMode.CLAMP
        )

        // lens band along the edge
        val bw = min(4.6f * density, min(w, h) / 3f)
        bandPath.reset()
        r.set(b)
        bandPath.addRoundRect(r, rad, rad, Path.Direction.CW)
        r2.set(r)
        r2.inset(bw, bw)
        bandPath.addRoundRect(r2, max0(rad - bw), max0(rad - bw), Path.Direction.CW)
        bandVeil.shader = LinearGradient(
            0f, top, 0f, bottom,
            intArrayOf(Color.argb(64, 255, 250, 246), Color.argb(14, 255, 250, 246)),
            null, Shader.TileMode.CLAMP
        )

        clipPath.reset()
        r.set(b)
        clipPath.addRoundRect(r, rad, rad, Path.Direction.CW)

        builtW = b.width()
        builtH = b.height()
        builtShift = shift
        builtTint = tint
    }

    override fun draw(canvas: Canvas) {
        val b = bounds
        if (b.width() < 2 || b.height() < 2) return
        val shift = Glass.shift

        var tint = Color.argb(255, 200, 190, 200)
        var haveBitmap = false
        val v = anchor
        val bd = Backdrop.bitmap
        var tNorm = 0.5f
        if (v != null && v.isAttachedToWindow) {
            v.getLocationOnScreen(loc)
            val dm = v.resources.displayMetrics
            tNorm = Math.round(((loc[1] + b.height() / 2f) / dm.heightPixels) * 20f) / 20f
            tint = Glass.colorAt(tNorm)
        }
        if (builtW != b.width() || builtH != b.height() || abs(shift - builtShift) > 0.012f || tint != builtTint) {
            build(b, shift, tint)
        }
        r.set(b)

        // 1. what is behind the panel
        if (v != null && v.isAttachedToWindow) {
            val dm = v.resources.displayMetrics
            if (Backdrop.enabled && bd != null) {
                val sx = bd.width / dm.widthPixels.toFloat()
                val sy = bd.height / dm.heightPixels.toFloat()
                src.set(loc[0] * sx, loc[1] * sy, (loc[0] + b.width()) * sx, (loc[1] + b.height()) * sy)
                if (shaderFor !== bd) {
                    shader1 = BitmapShader(bd, Shader.TileMode.CLAMP, Shader.TileMode.CLAMP)
                    shader2 = BitmapShader(bd, Shader.TileMode.CLAMP, Shader.TileMode.CLAMP)
                    shaderFor = bd
                }
                m1.setRectToRect(src, r, Matrix.ScaleToFit.FILL)
                shader1?.setLocalMatrix(m1)
                backPaint.shader = shader1
                canvas.drawRoundRect(r, rad, rad, backPaint)
                haveBitmap = true
            } else {
                // faint, desaturated wallpaper colour so the glass still matches the scene
                val grey = ColorUtils.blendARGB(tint, Color.rgb(60, 62, 72), 0.45f)
                fog.color = ColorUtils.setAlphaComponent(if (light) tint else grey, if (light) 54 else 118)
                canvas.drawRoundRect(r, rad, rad, fog)
            }
        }

        // 2. smoky body
        body.alpha = if (haveBitmap) 230 else 255
        canvas.drawRoundRect(r, rad, rad, body)

        // 3. lens band: the wallpaper looks stretched near the edge, plus a light veil
        canvas.save()
        canvas.clipPath(bandPath)
        if (haveBitmap) {
            val cx = (src.left + src.right) / 2f
            val cy = (src.top + src.bottom) / 2f
            val hw = src.width() / 2f / 1.45f
            val hh = src.height() / 2f / 1.45f
            srcMag.set(cx - hw, cy - hh, cx + hw, cy + hh)
            m2.setRectToRect(srcMag, r, Matrix.ScaleToFit.FILL)
            shader2?.setLocalMatrix(m2)
            bandPaint.shader = shader2
            canvas.drawRoundRect(r, rad, rad, bandPaint)
        }
        canvas.drawRoundRect(r, rad, rad, bandVeil)
        canvas.restore()

        // 4. sheen and glint
        r2.set(r)
        r2.inset(density * 1.5f, density * 1.5f)
        canvas.drawRoundRect(r2, rad, rad, sheen)
        canvas.drawRoundRect(r2, rad, rad, glint)

        // 5. touch glow
        if (touchAmt > 0.01f) {
            glow.shader = RadialGradient(
                tx + b.left, ty + b.top, 96f * density,
                intArrayOf(Color.argb((120 * touchAmt).toInt(), 255, 255, 255), Color.argb(0, 255, 255, 255)),
                null, Shader.TileMode.CLAMP
            )
            canvas.save()
            canvas.clipPath(clipPath)
            canvas.drawRect(r, glow)
            canvas.restore()
        }

        // 6. rims: dark line inside, thick metallic band, bright hairline outside
        r2.set(r)
        r2.inset(rim.strokeWidth + darkRim.strokeWidth / 2f, rim.strokeWidth + darkRim.strokeWidth / 2f)
        canvas.drawRoundRect(r2, max0(rad - rim.strokeWidth), max0(rad - rim.strokeWidth), darkRim)
        r2.set(r)
        r2.inset(rim.strokeWidth / 2f, rim.strokeWidth / 2f)
        canvas.drawRoundRect(r2, max0(rad - rim.strokeWidth / 2f), max0(rad - rim.strokeWidth / 2f), rim)
        r2.set(r)
        r2.inset(hairline.strokeWidth / 2f, hairline.strokeWidth / 2f)
        canvas.drawRoundRect(r2, max0(rad - hairline.strokeWidth / 2f), max0(rad - hairline.strokeWidth / 2f), hairline)
    }

    override fun setAlpha(alpha: Int) {}
    override fun setColorFilter(colorFilter: ColorFilter?) {}

    @Deprecated("Deprecated in Java")
    override fun getOpacity(): Int = PixelFormat.TRANSLUCENT
}
