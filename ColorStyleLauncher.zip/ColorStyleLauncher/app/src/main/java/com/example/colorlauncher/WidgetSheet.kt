package com.example.colorlauncher

import android.appwidget.AppWidgetProviderInfo
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.text.Editable
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.animation.AccelerateInterpolator
import android.view.animation.DecelerateInterpolator
import android.view.inputmethod.InputMethodManager
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.dynamicanimation.animation.DynamicAnimation
import androidx.dynamicanimation.animation.SpringAnimation
import androidx.dynamicanimation.animation.SpringForce
import kotlin.math.max
import kotlin.math.min

/**
 * The "Add widgets" screen: a frosted sheet that springs up from the bottom.
 * The launcher's own ColorOS 17 widgets come first (shown live), then every widget from your apps.
 */
class WidgetSheet(
    private val act: AppCompatActivity,
    private val root: FrameLayout,
    private val cfg: LauncherPrefs,
    private val factory: WidgetFactory,
    providers: List<AppWidgetProviderInfo>,
    private val spanOf: (AppWidgetProviderInfo) -> IntArray,
    private val onBuiltin: (BuiltinKind) -> Unit,
    private val onProvider: (AppWidgetProviderInfo) -> Unit
) {
    private class Entry(val info: AppWidgetProviderInfo, val label: String, val app: String)

    private val handler = Handler(Looper.getMainLooper())
    private val entries: List<Entry>
    private lateinit var scrim: FrameLayout
    private lateinit var sheet: LinearLayout
    private lateinit var builtinRow: LinearLayout
    private lateinit var builtinTitle: TextView
    private lateinit var appsBox: LinearLayout
    private lateinit var search: EditText
    private var closing = false
    private var shown = false
    private var token = 0

    val isShowing: Boolean get() = shown && !closing

    init {
        val pm = act.packageManager
        entries = providers.map { info ->
            val label = try {
                info.loadLabel(pm)
            } catch (e: Exception) {
                info.provider.packageName
            }
            val app = try {
                pm.getApplicationLabel(pm.getApplicationInfo(info.provider.packageName, 0)).toString()
            } catch (e: Exception) {
                info.provider.packageName
            }
            Entry(info, label, app)
        }.sortedWith(compareBy({ it.app.lowercase() }, { it.label.lowercase() }))
    }

    private fun dp(v: Int) = (v * act.resources.displayMetrics.density).toInt()

    private fun reveal(v: View, index: Int) {
        v.alpha = 0f
        v.translationY = dp(26).toFloat()
        v.scaleX = 0.96f
        v.scaleY = 0.96f
        v.animate().alpha(1f).translationY(0f).scaleX(1f).scaleY(1f)
            .setStartDelay(min(index, 9) * 35L).setDuration(340L)
            .setInterpolator(DecelerateInterpolator(1.6f)).start()
    }

    fun show() {
        shown = true
        val st = cfg.uiStyle
        scrim = FrameLayout(act)
        scrim.setBackgroundColor(0x80000000.toInt())
        scrim.isClickable = true
        scrim.alpha = 0f
        scrim.setOnClickListener { dismiss() }

        sheet = LinearLayout(act)
        sheet.orientation = LinearLayout.VERTICAL
        sheet.isClickable = true
        sheet.background = UiStyle.panel(act, st, 34f, max(cfg.glassStrength, 60), sheet)
        val lp = FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, (root.height * 0.88f).toInt(), Gravity.BOTTOM)
        lp.setMargins(dp(8), 0, dp(8), dp(8))
        scrim.addView(sheet, lp)

        // grab handle
        val handleBar = View(act)
        val hb = GradientDrawable()
        hb.cornerRadius = dp(3).toFloat()
        hb.setColor(Color.argb(120, 255, 255, 255))
        handleBar.background = hb
        val hp = LinearLayout.LayoutParams(dp(40), dp(5))
        hp.gravity = Gravity.CENTER_HORIZONTAL
        hp.topMargin = dp(10)
        sheet.addView(handleBar, hp)

        // header
        val header = LinearLayout(act)
        header.orientation = LinearLayout.HORIZONTAL
        header.gravity = Gravity.CENTER_VERTICAL
        header.setPadding(dp(22), dp(10), dp(14), dp(6))
        val title = TextView(act)
        title.text = "Widgets"
        title.textSize = 28f
        title.setTextColor(Color.WHITE)
        title.typeface = Typeface.create("sans-serif-light", Typeface.NORMAL)
        header.addView(title, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        val close = ImageView(act)
        close.setImageResource(R.drawable.ic_close)
        close.setPadding(dp(11), dp(11), dp(11), dp(11))
        close.background = UiStyle.panel(act, st, 22f, cfg.glassStrength, close)
        close.setOnClickListener { dismiss() }
        header.addView(close, LinearLayout.LayoutParams(dp(44), dp(44)))
        sheet.addView(header)

        // search
        search = EditText(act)
        search.hint = "Search widgets"
        search.setHintTextColor(0x99FFFFFF.toInt())
        search.setTextColor(Color.WHITE)
        search.textSize = 15f
        search.maxLines = 1
        search.inputType = android.text.InputType.TYPE_CLASS_TEXT
        search.setCompoundDrawablesRelativeWithIntrinsicBounds(R.drawable.ic_search, 0, 0, 0)
        search.compoundDrawablePadding = dp(10)
        search.setPadding(dp(18), 0, dp(18), 0)
        search.background = UiStyle.panel(act, st, 24f, cfg.glassStrength, search)
        val sp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(46))
        sp.setMargins(dp(18), dp(6), dp(18), dp(8))
        sheet.addView(search, sp)
        search.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) {
                val q = s?.toString().orEmpty().trim().lowercase()
                fillBuiltin(q)
                fillApps(q)
            }
        })

        // scrolling content
        val scroll = ScrollView(act)
        scroll.isVerticalScrollBarEnabled = false
        val content = LinearLayout(act)
        content.orientation = LinearLayout.VERTICAL
        content.setPadding(0, dp(4), 0, dp(28))
        scroll.addView(content, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        sheet.addView(scroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))

        builtinTitle = sectionTitle("ColorOS 17 widgets")
        content.addView(builtinTitle)
        val hs = HorizontalScrollView(act)
        hs.isHorizontalScrollBarEnabled = false
        builtinRow = LinearLayout(act)
        builtinRow.orientation = LinearLayout.HORIZONTAL
        builtinRow.setPadding(dp(18), dp(4), dp(18), dp(8))
        hs.addView(builtinRow)
        content.addView(hs)
        content.addView(sectionTitle("Widgets from your apps"))
        appsBox = LinearLayout(act)
        appsBox.orientation = LinearLayout.VERTICAL
        content.addView(appsBox)

        fillBuiltin("")
        fillApps("")

        root.addView(scrim, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        scrim.animate().alpha(1f).setDuration(220L).start()
        sheet.translationY = root.height.toFloat()
        val sa = SpringAnimation(sheet, DynamicAnimation.TRANSLATION_Y, 0f)
        sa.spring.setStiffness(SpringForce.STIFFNESS_LOW).setDampingRatio(0.86f)
        sa.start()
    }

    private fun sectionTitle(text: String): TextView {
        val t = TextView(act)
        t.text = text
        t.setTextColor(0xB3FFFFFF.toInt())
        t.textSize = 13f
        t.setPadding(dp(24), dp(16), dp(24), dp(4))
        return t
    }

    private fun pick(action: () -> Unit) {
        dismiss()
        handler.postDelayed({ action() }, 120L)
    }

    private fun fillBuiltin(q: String) {
        builtinRow.removeAllViews()
        var i = 0
        for (k in Builtin.kinds) {
            if (q.isNotEmpty() && !k.title.lowercase().contains(q) && !"colorOS 17".lowercase().contains(q)) continue
            val col = LinearLayout(act)
            col.orientation = LinearLayout.VERTICAL
            col.gravity = Gravity.CENTER_HORIZONTAL

            val box = FrameLayout(act)
            val w = dp(58) * k.spanX
            val h = dp(58) * k.spanY
            val preview = factory.create(k.id)
            if (preview != null) box.addView(preview, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
            // transparent cover so tapping the preview adds the widget instead of pressing its buttons
            val cover = View(act)
            cover.setOnClickListener { pick { onBuiltin(k) } }
            box.addView(cover, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
            col.addView(box, LinearLayout.LayoutParams(w, h))

            val label = TextView(act)
            label.text = k.title + "  " + k.spanX + "×" + k.spanY
            label.setTextColor(Color.WHITE)
            label.textSize = 12f
            label.setPadding(0, dp(6), 0, 0)
            col.addView(label)

            val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            lp.marginEnd = dp(14)
            builtinRow.addView(col, lp)
            reveal(col, i)
            i++
        }
        builtinTitle.visibility = if (builtinRow.childCount == 0) View.GONE else View.VISIBLE
    }

    private fun appCard(e: Entry, index: Int): View {
        val card = LinearLayout(act)
        card.orientation = LinearLayout.HORIZONTAL
        card.gravity = Gravity.CENTER_VERTICAL
        card.setPadding(dp(12), dp(10), dp(16), dp(10))
        card.background = UiStyle.panel(act, cfg.uiStyle, 22f, cfg.glassStrength, card)

        val img = ImageView(act)
        img.scaleType = ImageView.ScaleType.FIT_CENTER
        val prev: Drawable? = try {
            e.info.loadPreviewImage(act, 0)
        } catch (ex: Exception) {
            null
        }
        val fallback: Drawable? = try {
            e.info.loadIcon(act, 0)
        } catch (ex: Exception) {
            null
        }
        img.setImageDrawable(prev ?: fallback)
        card.addView(img, LinearLayout.LayoutParams(dp(116), dp(72)))

        val col = LinearLayout(act)
        col.orientation = LinearLayout.VERTICAL
        val name = TextView(act)
        name.text = e.label
        name.setTextColor(Color.WHITE)
        name.textSize = 15f
        name.maxLines = 1
        name.ellipsize = android.text.TextUtils.TruncateAt.END
        val span = spanOf(e.info)
        val sub = TextView(act)
        sub.text = e.app + "  ·  " + span[0] + "×" + span[1]
        sub.setTextColor(0xB3FFFFFF.toInt())
        sub.textSize = 12f
        sub.maxLines = 1
        sub.ellipsize = android.text.TextUtils.TruncateAt.END
        col.addView(name)
        col.addView(sub)
        val cp = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        cp.marginStart = dp(14)
        card.addView(col, cp)

        card.setOnClickListener { pick { onProvider(e.info) } }
        val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        lp.setMargins(dp(18), dp(5), dp(18), dp(5))
        card.layoutParams = lp
        reveal(card, index)
        return card
    }

    /** Adds the app widgets a few at a time so the sheet opens smoothly even with hundreds of them. */
    private fun fillApps(q: String) {
        appsBox.removeAllViews()
        val my = ++token
        val list = if (q.isEmpty()) entries else entries.filter {
            it.label.lowercase().contains(q) || it.app.lowercase().contains(q)
        }
        var index = 0
        fun step() {
            if (my != token || closing) return
            val end = min(index + 5, list.size)
            while (index < end) {
                appsBox.addView(appCard(list[index], index))
                index++
            }
            if (index < list.size) handler.postDelayed({ step() }, 24L)
        }
        step()
    }

    fun dismiss() {
        if (closing || !shown) return
        closing = true
        token++
        try {
            (act.getSystemService(android.content.Context.INPUT_METHOD_SERVICE) as InputMethodManager)
                .hideSoftInputFromWindow(search.windowToken, 0)
        } catch (e: Exception) {
            // ignore
        }
        scrim.animate().alpha(0f).setDuration(200L).start()
        sheet.animate().translationY(root.height.toFloat()).setDuration(260L)
            .setInterpolator(AccelerateInterpolator(1.4f))
            .withEndAction { root.removeView(scrim) }.start()
    }
}
