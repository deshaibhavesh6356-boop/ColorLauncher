package com.example.colorlauncher

import android.content.Context
import android.content.SharedPreferences

/** Counts how often and when each app is opened (for "frequent" and "recent"). */
object Usage {
    private fun sp(ctx: Context): SharedPreferences = ctx.getSharedPreferences("usage", Context.MODE_PRIVATE)

    fun record(ctx: Context, pkg: String) {
        val s = sp(ctx)
        s.edit()
            .putInt("c_$pkg", s.getInt("c_$pkg", 0) + 1)
            .putLong("t_$pkg", System.currentTimeMillis())
            .apply()
    }

    fun top(ctx: Context, n: Int): List<String> =
        sp(ctx).all.entries
            .filter { it.key.startsWith("c_") }
            .sortedByDescending { (it.value as? Int) ?: 0 }
            .take(n)
            .map { it.key.removePrefix("c_") }

    fun recent(ctx: Context, n: Int): List<String> =
        sp(ctx).all.entries
            .filter { it.key.startsWith("t_") }
            .sortedByDescending { (it.value as? Long) ?: 0L }
            .take(n)
            .map { it.key.removePrefix("t_") }
}

/** One-tap looks. */
object Presets {
    val names = arrayOf("ColorOS 16", "iOS 26 glass", "Material You", "Minimal dark")

    fun apply(p: SharedPreferences, index: Int) {
        val e = p.edit()
        when (index) {
            0 -> e.putString("ui_style", "glass").putInt("glass_strength", 30)
                .putString("icon_shape", "squircle").putInt("icon_size", 54)
                .putString("font_style", "medium").putString("clock_style", "thin")
                .putString("open_anim", "zoom").putString("close_anim", "shrink")
                .putString("page_effect", "slide").putBoolean("show_labels", true)
                .putInt("label_size", 12).putString("icon_theme", "original")
            1 -> e.putString("ui_style", "glass").putInt("glass_strength", 42)
                .putString("icon_shape", "rounded").putInt("icon_size", 56)
                .putString("font_style", "default").putString("clock_style", "bold")
                .putString("open_anim", "zoom").putString("close_anim", "shrink")
                .putString("page_effect", "fade").putBoolean("show_labels", true)
                .putInt("label_size", 11).putString("icon_theme", "original")
            2 -> e.putString("ui_style", "material").putInt("glass_strength", 30)
                .putString("icon_shape", "circle").putInt("icon_size", 52)
                .putString("font_style", "default").putString("clock_style", "stacked")
                .putString("open_anim", "fade").putString("close_anim", "zoom")
                .putString("page_effect", "slide").putBoolean("show_labels", true)
                .putInt("label_size", 12).putString("icon_theme", "themed")
            else -> e.putString("ui_style", "classic").putInt("glass_strength", 12)
                .putString("icon_shape", "square").putInt("icon_size", 48)
                .putString("font_style", "light").putString("clock_style", "thin")
                .putString("open_anim", "fade").putString("close_anim", "none")
                .putString("page_effect", "slide").putBoolean("show_labels", false)
                .putInt("label_size", 11).putString("icon_theme", "original")
        }
        e.apply()
    }
}
