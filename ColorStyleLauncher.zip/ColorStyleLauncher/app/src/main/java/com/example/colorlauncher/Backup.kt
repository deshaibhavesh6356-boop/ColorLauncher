package com.example.colorlauncher

import android.content.Context
import android.content.SharedPreferences
import androidx.preference.PreferenceManager
import org.json.JSONArray
import org.json.JSONObject

/** Saves all settings and the home screen layout to one text file, and reads it back. */
object Backup {

    fun dump(ctx: Context): String {
        val root = JSONObject()
        root.put("prefs", dumpPrefs(PreferenceManager.getDefaultSharedPreferences(ctx)))
        root.put("layout", dumpPrefs(ctx.getSharedPreferences("layout", Context.MODE_PRIVATE)))
        return root.toString()
    }

    private fun dumpPrefs(sp: SharedPreferences): JSONObject {
        val o = JSONObject()
        for ((k, v) in sp.all) {
            val e = JSONObject()
            when (v) {
                is Boolean -> {
                    e.put("t", "b")
                    e.put("v", v)
                }
                is Int -> {
                    e.put("t", "i")
                    e.put("v", v)
                }
                is Long -> {
                    e.put("t", "l")
                    e.put("v", v)
                }
                is Float -> {
                    e.put("t", "f")
                    e.put("v", v.toDouble())
                }
                is String -> {
                    e.put("t", "s")
                    e.put("v", v)
                }
                is Set<*> -> {
                    e.put("t", "set")
                    val a = JSONArray()
                    for (x in v) a.put(x.toString())
                    e.put("v", a)
                }
                else -> continue
            }
            o.put(k, e)
        }
        return o
    }

    private fun applyPrefs(sp: SharedPreferences, o: JSONObject) {
        val ed = sp.edit()
        ed.clear()
        val keys = o.keys()
        while (keys.hasNext()) {
            val k = keys.next()
            val e = o.getJSONObject(k)
            when (e.getString("t")) {
                "b" -> ed.putBoolean(k, e.getBoolean("v"))
                "i" -> ed.putInt(k, e.getInt("v"))
                "l" -> ed.putLong(k, e.getLong("v"))
                "f" -> ed.putFloat(k, e.getDouble("v").toFloat())
                "s" -> ed.putString(k, e.getString("v"))
                "set" -> {
                    val a = e.getJSONArray("v")
                    val s = HashSet<String>()
                    for (i in 0 until a.length()) s.add(a.getString(i))
                    ed.putStringSet(k, s)
                }
            }
        }
        ed.commit()
    }

    fun restore(ctx: Context, json: String): Boolean {
        return try {
            val root = JSONObject(json)
            val prefs = PreferenceManager.getDefaultSharedPreferences(ctx)
            applyPrefs(prefs, root.getJSONObject("prefs"))
            applyPrefs(ctx.getSharedPreferences("layout", Context.MODE_PRIVATE), root.getJSONObject("layout"))
            prefs.edit().putBoolean("restore_flag", true).commit()
            true
        } catch (e: Exception) {
            false
        }
    }
}
