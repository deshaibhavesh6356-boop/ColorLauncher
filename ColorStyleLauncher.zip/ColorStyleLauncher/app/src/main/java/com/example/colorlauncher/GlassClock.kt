package com.example.colorlauncher

import android.content.Context
import android.graphics.Canvas
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Shader
import android.util.AttributeSet
import android.widget.TextClock

/**
 * The big "living clock" of ColorOS 17: huge digits that look like frosted glass
 * (a bright outline with a soft translucent fill).
 */
class GlassClock @JvmOverloads constructor(
    ctx: Context,
    attrs: AttributeSet? = null
) : TextClock(ctx, attrs) {

    var glass = false
        set(value) {
            field = value
            invalidate()
        }

    override fun onDraw(canvas: Canvas) {
        if (!glass) {
            super.onDraw(canvas)
            return
        }
        val p = paint
        val d = resources.displayMetrics.density
        // 1. bright outline
        p.style = Paint.Style.STROKE
        p.strokeWidth = 1.8f * d
        p.shader = null
        super.onDraw(canvas)
        // 2. frosted fill, lighter at the top
        p.style = Paint.Style.FILL
        p.shader = LinearGradient(
            0f, 0f, 0f, height.toFloat(),
            intArrayOf(0x88FFFFFF.toInt(), 0x2EFFFFFF), null, Shader.TileMode.CLAMP
        )
        super.onDraw(canvas)
        p.shader = null
    }
}
