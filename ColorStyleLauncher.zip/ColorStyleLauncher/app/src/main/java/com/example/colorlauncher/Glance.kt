package com.example.colorlauncher

import android.Manifest
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.database.Cursor
import android.media.MediaMetadata
import android.media.session.MediaController
import android.media.session.MediaSessionManager
import android.media.session.PlaybackState
import android.graphics.Bitmap
import android.os.BatteryManager
import android.os.Handler
import android.os.Looper
import android.provider.CalendarContract
import android.content.ContentUris
import android.view.View
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.text.DateFormat
import java.util.Date
import kotlin.concurrent.thread

/** The little glass cards under the clock: weather, battery, next event, and now-playing music. */
class Glance(
    private val act: AppCompatActivity,
    private val cfg: LauncherPrefs,
    private val row: View,
    private val weather: TextView,
    private val battery: TextView,
    private val calendar: TextView,
    private val music: View,
    private val art: ImageView,
    private val title: TextView,
    private val artist: TextView,
    prev: View,
    private val play: ImageView,
    next: View,
    private val requestCalendar: () -> Unit
) {
    private val handler = Handler(Looper.getMainLooper())

    var weatherText = ""
    var weatherIcon = R.drawable.ic_cloud
    var batteryText = ""
    var calendarText = ""

    // data for the built-in widgets
    var batteryPct = -1
    var charging = false
    var tempText = "--"
    var cityText = ""
    var calendarTime = ""
    var calendarTitle = ""
    var hasMusic = false
    var musicTitle = ""
    var musicArtist = ""
    var musicArt: Bitmap? = null
    var musicPlaying = false
    val listeners = ArrayList<() -> Unit>()

    private fun notifyListeners() {
        for (l in listeners) {
            try {
                l()
            } catch (e: Exception) {
                // ignore
            }
        }
    }

    fun togglePlay() {
        val c = controller ?: return
        if (c.playbackState?.state == PlaybackState.STATE_PLAYING) c.transportControls.pause() else c.transportControls.play()
    }

    fun skipNext() {
        controller?.transportControls?.skipToNext()
    }

    fun skipPrev() {
        controller?.transportControls?.skipToPrevious()
    }

    fun openPlayer() {
        try {
            controller?.sessionActivity?.send()
        } catch (e: Exception) {
            // ignore
        }
    }

    fun askCalendar() {
        if (!hasCalendar()) requestCalendar()
    }

    private var controller: MediaController? = null
    private var lastWeatherAt = 0L
    private var lastCalendarAt = 0L
    private var lastCity = ""

    private val ticker = object : Runnable {
        override fun run() {
            update()
            handler.postDelayed(this, 3000)
        }
    }

    init {
        prev.setOnClickListener { controller?.transportControls?.skipToPrevious() }
        next.setOnClickListener { controller?.transportControls?.skipToNext() }
        play.setOnClickListener {
            val c = controller
            if (c != null) {
                if (c.playbackState?.state == PlaybackState.STATE_PLAYING) {
                    c.transportControls.pause()
                } else {
                    c.transportControls.play()
                }
            }
        }
        music.setOnClickListener {
            try {
                controller?.sessionActivity?.send()
            } catch (e: Exception) {
                // ignore
            }
        }
        calendar.setOnClickListener {
            if (!hasCalendar()) requestCalendar()
        }
    }

    fun start() {
        handler.removeCallbacks(ticker)
        handler.post(ticker)
    }

    fun stop() {
        handler.removeCallbacks(ticker)
    }

    fun refreshNow() {
        lastCalendarAt = 0L
        lastWeatherAt = 0L
        update()
    }

    private fun update() {
        updateBattery()
        updateMusic()
        val now = System.currentTimeMillis()
        if (now - lastCalendarAt > 60_000L) {
            lastCalendarAt = now
            updateCalendar()
        }
        val city = cfg.weatherCity.trim()
        if (now - lastWeatherAt > 30 * 60_000L || city != lastCity) {
            lastWeatherAt = now
            lastCity = city
            updateWeather(city)
        }
        notifyListeners()
    }

    // ---------- battery ----------
    private fun updateBattery() {
        val i = act.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val level = i?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
        val scale = i?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100
        val status = i?.getIntExtra(BatteryManager.EXTRA_STATUS, -1) ?: -1
        val charging = status == BatteryManager.BATTERY_STATUS_CHARGING ||
            status == BatteryManager.BATTERY_STATUS_FULL
        batteryPct = if (level >= 0 && scale > 0) level * 100 / scale else -1
        this.charging = charging
        batteryText = if (level >= 0 && scale > 0) {
            "${level * 100 / scale}%\n" + (if (charging) "Charging" else "Battery")
        } else {
            "Battery"
        }
        battery.text = batteryText
    }

    // ---------- calendar ----------
    private fun hasCalendar(): Boolean =
        ContextCompat.checkSelfPermission(act, Manifest.permission.READ_CALENDAR) == PackageManager.PERMISSION_GRANTED

    private fun updateCalendar() {
        if (!hasCalendar()) {
            calendarText = "Calendar\nTap to allow"
            calendarTime = "Calendar"
            calendarTitle = "Tap to allow access"
            calendar.text = calendarText
            notifyListeners()
            return
        }
        thread {
            var text = "No events\nToday is free"
            var cur: Cursor? = null
            try {
                val begin = System.currentTimeMillis()
                val end = begin + 24L * 3600L * 1000L
                val b = CalendarContract.Instances.CONTENT_URI.buildUpon()
                ContentUris.appendId(b, begin)
                ContentUris.appendId(b, end)
                cur = act.contentResolver.query(
                    b.build(),
                    arrayOf(CalendarContract.Instances.TITLE, CalendarContract.Instances.BEGIN),
                    null, null, CalendarContract.Instances.BEGIN + " ASC"
                )
                if (cur != null && cur.moveToFirst()) {
                    val t = cur.getString(0) ?: "Event"
                    val whenMs = cur.getLong(1)
                    val time = DateFormat.getTimeInstance(DateFormat.SHORT).format(Date(whenMs))
                    text = "$time\n$t"
                }
            } catch (e: Exception) {
                // ignore
            } finally {
                cur?.close()
            }
            act.runOnUiThread {
                calendarText = text
                calendar.text = text
                val parts = text.split("\n")
                calendarTime = parts[0]
                calendarTitle = if (parts.size > 1) parts[1] else ""
                notifyListeners()
            }
        }
    }

    // ---------- music ----------
    private fun updateMusic() {
        var ctl: MediaController? = null
        try {
            val msm = act.getSystemService(Context.MEDIA_SESSION_SERVICE) as MediaSessionManager
            val list = msm.getActiveSessions(ComponentName(act, BadgeService::class.java))
            ctl = list.firstOrNull { it.playbackState?.state == PlaybackState.STATE_PLAYING } ?: list.firstOrNull()
        } catch (e: Exception) {
            ctl = null // notification access not given yet
        }
        controller = ctl
        val md = ctl?.metadata
        val t = md?.getString(MediaMetadata.METADATA_KEY_TITLE)
        if (ctl == null || md == null || t.isNullOrEmpty()) {
            music.visibility = View.GONE
            row.visibility = View.VISIBLE
            hasMusic = false
            musicTitle = ""
            musicArt = null
            return
        }
        title.text = t
        artist.text = md.getString(MediaMetadata.METADATA_KEY_ARTIST) ?: ""
        val bmp = md.getBitmap(MediaMetadata.METADATA_KEY_ALBUM_ART) ?: md.getBitmap(MediaMetadata.METADATA_KEY_ART)
        if (bmp != null) art.setImageBitmap(bmp) else art.setImageDrawable(null)
        play.setImageResource(
            if (ctl.playbackState?.state == PlaybackState.STATE_PLAYING) R.drawable.ic_pause else R.drawable.ic_play
        )
        music.visibility = View.VISIBLE
        row.visibility = View.GONE
        hasMusic = true
        musicTitle = t
        musicArtist = md.getString(MediaMetadata.METADATA_KEY_ARTIST) ?: ""
        musicArt = bmp
        musicPlaying = ctl.playbackState?.state == PlaybackState.STATE_PLAYING
    }

    // ---------- weather ----------
    private fun updateWeather(city: String) {
        if (city.isEmpty()) {
            weatherText = "Weather\nSet city in Settings"
            weatherIcon = R.drawable.ic_cloud
            tempText = "--"
            cityText = "Set city in Settings"
            weather.text = weatherText
            weather.setCompoundDrawablesRelativeWithIntrinsicBounds(weatherIcon, 0, 0, 0)
            return
        }
        thread {
            var text: String? = null
            var ic = R.drawable.ic_cloud
            try {
                val sp = cfg.p
                var lat = sp.getString("w_lat", "") ?: ""
                var lon = sp.getString("w_lon", "") ?: ""
                var shown = sp.getString("w_name", "") ?: ""
                if ((sp.getString("w_city", "") ?: "") != city || lat.isEmpty()) {
                    val g = JSONObject(
                        httpGet("https://geocoding-api.open-meteo.com/v1/search?count=1&name=" + URLEncoder.encode(city, "UTF-8"))
                    )
                    val r = g.getJSONArray("results").getJSONObject(0)
                    lat = r.getDouble("latitude").toString()
                    lon = r.getDouble("longitude").toString()
                    shown = r.optString("name", city)
                    sp.edit().putString("w_city", city).putString("w_lat", lat)
                        .putString("w_lon", lon).putString("w_name", shown).apply()
                }
                val unit = if (cfg.weatherF) "&temperature_unit=fahrenheit" else ""
                val w = JSONObject(
                    httpGet(
                        "https://api.open-meteo.com/v1/forecast?latitude=$lat&longitude=$lon" +
                            "&current=temperature_2m,weather_code$unit"
                    )
                )
                val cur = w.getJSONObject("current")
                val temp = Math.round(cur.getDouble("temperature_2m"))
                ic = icon(cur.getInt("weather_code"))
                text = temp.toString() + "°\n" + shown
            } catch (e: Exception) {
                text = "Weather\nNo connection"
            }
            act.runOnUiThread {
                weatherText = text ?: ""
                weatherIcon = ic
                val wp = weatherText.split("\n")
                tempText = wp[0]
                cityText = if (wp.size > 1) wp[1] else ""
                weather.text = weatherText
                notifyListeners()
                weather.setCompoundDrawablesRelativeWithIntrinsicBounds(ic, 0, 0, 0)
            }
        }
    }

    private fun icon(code: Int): Int = when (code) {
        0 -> R.drawable.ic_sun
        1, 2, 3, 45, 48 -> R.drawable.ic_cloud
        in 51..67, in 80..82 -> R.drawable.ic_rain
        in 71..77, 85, 86 -> R.drawable.ic_snow
        in 95..99 -> R.drawable.ic_storm
        else -> R.drawable.ic_cloud
    }

    private fun httpGet(url: String): String {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 8000
        c.readTimeout = 8000
        try {
            return c.inputStream.bufferedReader().use { it.readText() }
        } finally {
            c.disconnect()
        }
    }
}
