package com.example.colorlauncher

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import kotlin.math.abs

const val APP = 0
const val FOLDER = 1
const val WIDGET = 2

const val HOME = 0
const val DOCK = 1

/** One thing placed on the home screen or dock: an app, a folder or a widget. */
class Item(
    val id: Long,
    var type: Int,
    var container: Int,
    var page: Int,
    var x: Int,
    var y: Int,
    var spanX: Int = 1,
    var spanY: Int = 1,
    var pkg: String = "",
    var title: String = "",
    var widgetId: Int = -1,
    var children: MutableList<String> = mutableListOf()
)

/** Saves and edits the home screen layout. */
class LayoutStore(ctx: Context) {
    private val sp = ctx.getSharedPreferences("layout", Context.MODE_PRIVATE)
    val items = mutableListOf<Item>()
    var pageCount = 1
    var initialized = false
    var edited = false
    var dockEmptyOk = false
    var knownPkgs: MutableSet<String> = mutableSetOf()
    private var nextId = 1L

    init {
        load()
    }

    fun newId(): Long = nextId++

    private fun load() {
        items.clear()
        initialized = sp.getBoolean("initialized", false)
        edited = sp.getBoolean("edited", false)
        dockEmptyOk = sp.getBoolean("dock_empty_ok", false)
        pageCount = sp.getInt("pages", 1)
        nextId = sp.getLong("next_id", 1L)
        knownPkgs = (sp.getStringSet("known", emptySet()) ?: emptySet()).toMutableSet()
        val raw = sp.getString("items", "[]") ?: "[]"
        try {
            val arr = JSONArray(raw)
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                val ch = mutableListOf<String>()
                val ca = o.optJSONArray("children")
                if (ca != null) {
                    for (j in 0 until ca.length()) ch.add(ca.getString(j))
                }
                items.add(
                    Item(
                        o.getLong("id"), o.getInt("type"), o.getInt("container"), o.getInt("page"),
                        o.getInt("x"), o.getInt("y"), o.optInt("sx", 1), o.optInt("sy", 1),
                        o.optString("pkg"), o.optString("title"), o.optInt("wid", -1), ch
                    )
                )
            }
        } catch (e: Exception) {
            items.clear()
        }
    }

    fun save() {
        val arr = JSONArray()
        for (it in items) {
            val o = JSONObject()
            o.put("id", it.id)
            o.put("type", it.type)
            o.put("container", it.container)
            o.put("page", it.page)
            o.put("x", it.x)
            o.put("y", it.y)
            o.put("sx", it.spanX)
            o.put("sy", it.spanY)
            o.put("pkg", it.pkg)
            o.put("title", it.title)
            o.put("wid", it.widgetId)
            val ca = JSONArray()
            for (c in it.children) ca.put(c)
            o.put("children", ca)
            arr.put(o)
        }
        sp.edit()
            .putString("items", arr.toString())
            .putInt("pages", pageCount)
            .putLong("next_id", nextId)
            .putBoolean("initialized", initialized)
            .putBoolean("edited", edited)
            .putBoolean("dock_empty_ok", dockEmptyOk)
            .putStringSet("known", HashSet(knownPkgs))
            .apply()
    }

    fun reset() {
        items.clear()
        pageCount = 1
        initialized = false
        edited = false
        dockEmptyOk = false
        knownPkgs = mutableSetOf()
        save()
    }

    // ---------- queries ----------
    fun itemAt(container: Int, page: Int, cx: Int, cy: Int, ignoreId: Long): Item? =
        items.firstOrNull {
            it.container == container && (container == DOCK || it.page == page) && it.id != ignoreId &&
                cx >= it.x && cx < it.x + it.spanX && cy >= it.y && cy < it.y + it.spanY
        }

    fun isFree(
        container: Int, page: Int, x: Int, y: Int, sx: Int, sy: Int,
        cols: Int, rows: Int, ignoreId: Long
    ): Boolean {
        if (x < 0 || y < 0 || x + sx > cols || y + sy > rows) return false
        return items.none {
            it.container == container && (container == DOCK || it.page == page) && it.id != ignoreId &&
                x < it.x + it.spanX && x + sx > it.x && y < it.y + it.spanY && y + sy > it.y
        }
    }

    /** First free spot on the home screen, starting at [startPage]. Returns [page, x, y] or null. */
    fun findFree(startPage: Int, sx: Int, sy: Int, cols: Int, rows: Int, ignoreId: Long): IntArray? {
        for (p in startPage until pageCount) {
            for (y in 0..(rows - sy)) {
                for (x in 0..(cols - sx)) {
                    if (isFree(HOME, p, x, y, sx, sy, cols, rows, ignoreId)) return intArrayOf(p, x, y)
                }
            }
        }
        return null
    }

    /** Free spot closest to (cx, cy) on one page. Returns [x, y] or null. */
    fun findNear(
        container: Int, page: Int, cx: Int, cy: Int, sx: Int, sy: Int,
        cols: Int, rows: Int, ignoreId: Long
    ): IntArray? {
        var best: IntArray? = null
        var bestDist = Int.MAX_VALUE
        for (y in 0..(rows - sy)) {
            for (x in 0..(cols - sx)) {
                if (isFree(container, page, x, y, sx, sy, cols, rows, ignoreId)) {
                    val d = abs(x - cx) + abs(y - cy)
                    if (d < bestDist) {
                        bestDist = d
                        best = intArrayOf(x, y)
                    }
                }
            }
        }
        return best
    }

    fun findApp(pkg: String): Item? = items.firstOrNull { it.type == APP && it.pkg == pkg }

    // ---------- clean up ----------
    fun cleanFolders() {
        val gone = mutableListOf<Item>()
        for (f in items) {
            if (f.type != FOLDER) continue
            when (f.children.size) {
                0 -> gone.add(f)
                1 -> {
                    f.type = APP
                    f.pkg = f.children[0]
                    f.children = mutableListOf()
                    f.title = ""
                }
            }
        }
        items.removeAll(gone)
    }

    fun removeMissing(installed: Set<String>) {
        items.removeAll { it.type == APP && it.pkg !in installed }
        for (f in items) {
            if (f.type == FOLDER) f.children.removeAll { c -> c !in installed }
        }
        cleanFolders()
    }

    fun removeFromFolders(pkg: String) {
        for (f in items) {
            if (f.type == FOLDER) f.children.remove(pkg)
        }
    }

    fun trimTrailingPages() {
        while (pageCount > 1 && items.none { it.container == HOME && it.page == pageCount - 1 }) pageCount--
    }
}
