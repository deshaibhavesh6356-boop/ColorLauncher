package com.example.colorlauncher

import android.appwidget.AppWidgetHost
import android.appwidget.AppWidgetHostView
import android.appwidget.AppWidgetProviderInfo
import android.content.Context
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.widget.RemoteViews
import android.widget.TextView

/** Widget view that tells the launcher when its app could not draw it, so we can try again. */
class LauncherWidgetHostView(ctx: Context) : AppWidgetHostView(ctx) {
    var failed = false
    var onFailed: (() -> Unit)? = null

    override fun updateAppWidget(remoteViews: RemoteViews?) {
        failed = false
        super.updateAppWidget(remoteViews)
    }

    override fun getErrorView(): View {
        failed = true
        onFailed?.invoke()
        val t = TextView(context)
        t.text = "This widget could not load\nTap to try again"
        t.setTextColor(Color.WHITE)
        t.textSize = 13f
        t.gravity = Gravity.CENTER
        val bg = GradientDrawable()
        bg.cornerRadius = 40f
        bg.setColor(Color.argb(110, 20, 20, 28))
        t.background = bg
        return t
    }
}

class LauncherWidgetHost(ctx: Context, id: Int) : AppWidgetHost(ctx, id) {
    override fun onCreateView(context: Context, appWidgetId: Int, appWidget: AppWidgetProviderInfo?): AppWidgetHostView =
        LauncherWidgetHostView(context)
}
