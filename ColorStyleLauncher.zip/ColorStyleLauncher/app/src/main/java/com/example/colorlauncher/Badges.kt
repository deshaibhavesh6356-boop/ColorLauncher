package com.example.colorlauncher

import android.os.Handler
import android.os.Looper
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

object Badges {
    val counts = HashMap<String, Int>()
    var listener: (() -> Unit)? = null
    fun count(pkg: String): Int = counts[pkg] ?: 0
}

/** Counts active notifications per app, for the red dots. Needs notification access. */
class BadgeService : NotificationListenerService() {
    override fun onListenerConnected() {
        refresh()
    }

    override fun onNotificationPosted(sbn: StatusBarNotification?) {
        refresh()
    }

    override fun onNotificationRemoved(sbn: StatusBarNotification?) {
        refresh()
    }

    private fun refresh() {
        val map = HashMap<String, Int>()
        try {
            val list = activeNotifications
            if (list != null) {
                for (n in list) {
                    if (n.isClearable) map[n.packageName] = (map[n.packageName] ?: 0) + 1
                }
            }
        } catch (e: Exception) {
            // ignore
        }
        Handler(Looper.getMainLooper()).post {
            Badges.counts.clear()
            Badges.counts.putAll(map)
            Badges.listener?.invoke()
        }
    }
}
