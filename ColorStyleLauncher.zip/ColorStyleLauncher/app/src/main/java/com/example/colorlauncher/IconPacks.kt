package com.example.colorlauncher

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.Resources
import android.graphics.drawable.Drawable
import androidx.core.content.res.ResourcesCompat
import org.xmlpull.v1.XmlPullParser
import org.xmlpull.v1.XmlPullParserFactory

/** Supports the common Nova / ADW style icon packs from the Play Store. */
object IconPacks {
    private val actions = listOf(
        "org.adw.launcher.THEMES",
        "com.novalauncher.THEME",
        "com.fede.launcher.THEME_ICONPACK",
        "com.anddoes.launcher.THEME",
        "com.gau.go.launcherex.theme"
    )

    class Pack(val res: Resources, val pkg: String, val map: HashMap<String, String>)

    /** Installed icon packs as (package, label). */
    fun list(pm: PackageManager): List<Pair<String, String>> {
        val seen = LinkedHashMap<String, String>()
        for (a in actions) {
            try {
                for (ri in pm.queryIntentActivities(Intent(a), 0)) {
                    seen[ri.activityInfo.packageName] = ri.loadLabel(pm).toString()
                }
            } catch (e: Exception) {
                // ignore
            }
        }
        return seen.entries.map { Pair(it.key, it.value) }.sortedBy { it.second.lowercase() }
    }

    private fun openParser(res: Resources, pkg: String): XmlPullParser? {
        try {
            val id = res.getIdentifier("appfilter", "xml", pkg)
            if (id != 0) return res.getXml(id)
        } catch (e: Exception) {
            // try assets
        }
        return try {
            val p = XmlPullParserFactory.newInstance().newPullParser()
            p.setInput(res.assets.open("appfilter.xml"), "utf-8")
            p
        } catch (e: Exception) {
            null
        }
    }

    fun load(ctx: Context, pkg: String): Pack? {
        return try {
            val res = ctx.packageManager.getResourcesForApplication(pkg)
            val parser = openParser(res, pkg) ?: return null
            val map = HashMap<String, String>()
            var ev = parser.eventType
            while (ev != XmlPullParser.END_DOCUMENT) {
                if (ev == XmlPullParser.START_TAG && parser.name == "item") {
                    val comp = parser.getAttributeValue(null, "component")
                    val dr = parser.getAttributeValue(null, "drawable")
                    if (comp != null && dr != null) map[comp] = dr
                }
                ev = parser.next()
            }
            Pack(res, pkg, map)
        } catch (e: Exception) {
            null
        }
    }

    fun icon(pack: Pack, component: ComponentName): Drawable? {
        val name = pack.map[component.toString()] ?: return null
        val id = pack.res.getIdentifier(name, "drawable", pack.pkg)
        if (id == 0) return null
        return try {
            ResourcesCompat.getDrawable(pack.res, id, null)
        } catch (e: Exception) {
            null
        }
    }
}
