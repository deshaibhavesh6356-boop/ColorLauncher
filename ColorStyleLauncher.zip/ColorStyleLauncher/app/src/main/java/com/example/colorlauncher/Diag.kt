package com.example.colorlauncher

import android.app.Application
import android.appwidget.AppWidgetManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.Settings
import androidx.appcompat.app.AlertDialog
import android.os.Build
import androidx.core.app.NotificationManagerCompat
import java.io.PrintWriter
import java.io.StringWriter
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class LauncherApp : Application() {
    override fun onCreate() {
        super.onCreate()
        CrashLog.install(this)
    }
}

/** A short rolling log of what the launcher did (widgets, drawer ...), shown in the diagnostics report. */
object DiagLog {
    private val lines = ArrayList<String>()

    @Synchronized
    fun add(msg: String) {
        val t = SimpleDateFormat("HH:mm:ss", Locale.US).format(Date())
        lines.add("$t $msg")
        if (lines.size > 100) lines.removeAt(0)
    }

    @Synchronized
    fun text(): String = lines.joinToString("\n")
}

/** Remembers the last crash so it can be shown (and copied) the next time the launcher starts. */
object CrashLog {
    fun install(ctx: Context) {
        val app = ctx.applicationContext
        val prev = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { t, e ->
            try {
                val sw = StringWriter()
                e.printStackTrace(PrintWriter(sw))
                val txt = "Thread: " + t.name + "\n" + sw.toString().take(5000) +
                    "\n--- recent log ---\n" + DiagLog.text().takeLast(1500)
                app.getSharedPreferences("crash", Context.MODE_PRIVATE).edit()
                    .putString("last", txt).putLong("at", System.currentTimeMillis()).commit()
            } catch (x: Throwable) {
                // nothing more we can do
            }
            prev?.uncaughtException(t, e)
        }
    }

    fun last(ctx: Context): String? =
        ctx.getSharedPreferences("crash", Context.MODE_PRIVATE).getString("last", null)

    fun clear(ctx: Context) {
        ctx.getSharedPreferences("crash", Context.MODE_PRIVATE).edit().clear().apply()
    }
}

object Help {
    private const val WIDGET_TEXT =
        "Widgets are drawn by the app that owns them. Some phones (Xiaomi / HyperOS) stop those apps in the background, " +
            "so the widget stays empty.\n\n" +
            "1. Open the widget's app once (for example Google).\n" +
            "2. Phone Settings > Apps > Manage apps > that app > Battery saver > No restrictions, and switch Autostart on.\n" +
            "3. Do the same for Color Launcher.\n" +
            "4. Long-press the widget > Reload widget.\n" +
            "5. Launcher settings > Widgets > Widget compatibility: try another option, then reload again.\n\n" +
            "The built-in ColorOS 17 widgets (clock, weather, battery, music, search bar ...) always work."

    fun widgetHelp(ctx: Context) {
        AlertDialog.Builder(ctx)
            .setTitle("Widget not loading?")
            .setMessage(WIDGET_TEXT)
            .setPositiveButton("Autostart settings") { _, _ -> openAutostart(ctx) }
            .setNegativeButton("Close", null)
            .show()
    }

    fun openAutostart(ctx: Context) {
        try {
            val i = Intent()
            i.component = ComponentName("com.miui.securitycenter", "com.miui.permcenter.autostart.AutoStartManagementActivity")
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            ctx.startActivity(i)
        } catch (e: Exception) {
            try {
                val i = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + ctx.packageName))
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                ctx.startActivity(i)
            } catch (e2: Exception) {
                // ignore
            }
        }
    }
}

object Diagnostics {
    fun report(ctx: Context): String {
        val sb = StringBuilder()
        sb.append("Color Launcher report\n")
        sb.append("Phone: ").append(Build.MANUFACTURER).append(' ').append(Build.MODEL)
            .append(", Android ").append(Build.VERSION.RELEASE).append(" (API ").append(Build.VERSION.SDK_INT).append(")\n")
        try {
            val pi = ctx.packageManager.getPackageInfo(ctx.packageName, 0)
            sb.append("App version: ").append(pi.versionName).append('\n')
        } catch (e: Exception) {
            // ignore
        }
        val home = try {
            val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME)
            ctx.packageManager.resolveActivity(i, android.content.pm.PackageManager.MATCH_DEFAULT_ONLY)?.activityInfo?.packageName
        } catch (e: Exception) {
            null
        }
        sb.append("Default home app: ").append(home).append('\n')
        sb.append("Notification access: ")
            .append(NotificationManagerCompat.getEnabledListenerPackages(ctx).contains(ctx.packageName)).append('\n')
        val awm = AppWidgetManager.getInstance(ctx)
        val providers = try {
            awm.installedProviders.size
        } catch (e: Exception) {
            -1
        }
        sb.append("Widget providers visible: ").append(providers).append('\n')
        val store = LayoutStore(ctx)
        for (item in store.items) {
            if (item.type != WIDGET) continue
            if (item.widgetId >= 0) {
                val info = try {
                    awm.getAppWidgetInfo(item.widgetId)
                } catch (e: Exception) {
                    null
                }
                sb.append("Widget id=").append(item.widgetId).append(' ')
                    .append(info?.provider?.flattenToShortString() ?: "NOT BOUND")
                    .append(' ').append(item.spanX).append('x').append(item.spanY).append('\n')
            } else {
                sb.append("Built-in widget ").append(item.pkg).append('\n')
            }
        }
        sb.append("--- recent log ---\n").append(DiagLog.text()).append('\n')
        val crash = CrashLog.last(ctx)
        if (crash != null) sb.append("--- last crash ---\n").append(crash).append('\n')
        return sb.toString()
    }
}
