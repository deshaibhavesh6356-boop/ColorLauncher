package com.example.colorlauncher

import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Canvas
import android.graphics.Paint
import android.os.BatteryManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.util.AttributeSet
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextClock
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.graphics.ColorUtils
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.preference.PreferenceManager
import java.util.Calendar
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin
import kotlin.random.Random

/** Simple analog clock face, redrawn once a minute. */
class AnalogClockView @JvmOverloads constructor(
    ctx: Context, attrs: AttributeSet? = null
) : View(ctx, attrs) {

    var color: Int = 0xFFFFFFFF.toInt()
        set(value) {
            field = value
            invalidate()
        }

    private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
    }

    override fun onDraw(canvas: Canvas) {
        val cx = width / 2f
        val cy = height / 2f
        val r = min(cx, cy) * 0.95f
        paint.color = color
        paint.strokeWidth = r * 0.025f
        canvas.drawCircle(cx, cy, r, paint)
        for (i in 0 until 12) {
            val a = Math.toRadians(i * 30.0)
            val s = sin(a).toFloat()
            val c = cos(a).toFloat()
            canvas.drawLine(cx + s * r * 0.86f, cy - c * r * 0.86f, cx + s * r * 0.95f, cy - c * r * 0.95f, paint)
        }
        val cal = Calendar.getInstance()
        val h = cal.get(Calendar.HOUR)
        val m = cal.get(Calendar.MINUTE)
        val ha = Math.toRadians((h + m / 60.0) * 30.0)
        val ma = Math.toRadians(m * 6.0)
        paint.strokeWidth = r * 0.05f
        canvas.drawLine(cx, cy, cx + sin(ha).toFloat() * r * 0.5f, cy - cos(ha).toFloat() * r * 0.5f, paint)
        paint.strokeWidth = r * 0.035f
        canvas.drawLine(cx, cy, cx + sin(ma).toFloat() * r * 0.78f, cy - cos(ma).toFloat() * r * 0.78f, paint)
        paint.style = Paint.Style.FILL
        canvas.drawCircle(cx, cy, r * 0.045f, paint)
        paint.style = Paint.Style.STROKE
    }
}

/** Black clock screen at low brightness. Fully configurable from "Always-on clock settings". */
class AlwaysOnActivity : AppCompatActivity() {

    private val handler = Handler(Looper.getMainLooper())
    private lateinit var box: LinearLayout
    private lateinit var battery: TextView
    private lateinit var analog: AnalogClockView
    private var moveEnabled = true
    private var showBattery = true

    private val tick = object : Runnable {
        override fun run() {
            analog.invalidate()
            if (showBattery) {
                val i = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
                val level = i?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
                val scale = i?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100
                val status = i?.getIntExtra(BatteryManager.EXTRA_STATUS, -1) ?: -1
                val charging = status == BatteryManager.BATTERY_STATUS_CHARGING ||
                    status == BatteryManager.BATTERY_STATUS_FULL
                if (level >= 0 && scale > 0) {
                    val pct = level * 100 / scale
                    battery.text = if (charging) "$pct%  charging" else "$pct%"
                }
            }
            if (moveEnabled) {
                val d = resources.displayMetrics.density
                box.translationX = Random.nextInt(-30, 31) * d
                box.translationY = Random.nextInt(-40, 41) * d
            }
            val wait = 60_000L - (System.currentTimeMillis() % 60_000L) + 200L
            handler.postDelayed(this, wait)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val p = PreferenceManager.getDefaultSharedPreferences(this)

        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        val lp = window.attributes
        lp.screenBrightness = p.getInt("aod_brightness", 3).coerceIn(1, 100) / 100f
        window.attributes = lp

        setContentView(R.layout.activity_aod)
        box = findViewById(R.id.aodBox)
        battery = findViewById(R.id.aodBattery)
        analog = findViewById(R.id.aodAnalog)
        val clock = findViewById<TextClock>(R.id.aodClock)
        val date = findViewById<TextClock>(R.id.aodDate)
        val msg = findViewById<TextView>(R.id.aodMsg)
        findViewById<View>(R.id.aodRoot).setOnClickListener { finish() }

        // look
        val base = LauncherPrefs.color(p.getString("aod_color", "white") ?: "white")
        val alpha = p.getInt("aod_opacity", 75).coerceIn(10, 100) * 255 / 100
        val main = ColorUtils.setAlphaComponent(base, alpha)
        val soft = ColorUtils.setAlphaComponent(base, alpha * 6 / 10)
        val tf = LauncherPrefs.typeface(p.getString("aod_font", "thin") ?: "thin")
        val size = p.getInt("aod_size", 96)
        val style = p.getString("aod_style", "digital") ?: "digital"
        val hour = p.getString("aod_hour", "system") ?: "system"

        val f12 = if (style == "stacked") "hh\nmm" else "hh:mm"
        val f24 = if (style == "stacked") "HH\nmm" else "HH:mm"
        when (hour) {
            "12" -> { clock.format12Hour = f12; clock.format24Hour = f12 }
            "24" -> { clock.format12Hour = f24; clock.format24Hour = f24 }
            else -> { clock.format12Hour = f12; clock.format24Hour = f24 }
        }
        clock.typeface = tf
        clock.setTextColor(main)
        clock.textSize = if (style == "small") size * 0.45f else size.toFloat()
        if (style == "stacked") clock.setLineSpacing(0f, 0.85f)

        if (style == "analog") {
            clock.visibility = View.GONE
            analog.visibility = View.VISIBLE
            analog.color = main
            val px = (size * 2 * resources.displayMetrics.density).toInt()
            analog.layoutParams = LinearLayout.LayoutParams(px, px)
        }

        date.typeface = tf
        date.setTextColor(soft)
        date.visibility = if (p.getBoolean("aod_date", true)) View.VISIBLE else View.GONE

        val text = p.getString("aod_text", "") ?: ""
        if (text.isNotBlank()) {
            msg.text = text
            msg.typeface = tf
            msg.setTextColor(soft)
            msg.visibility = View.VISIBLE
        }

        showBattery = p.getBoolean("aod_battery", true)
        battery.setTextColor(soft)
        battery.visibility = if (showBattery) View.VISIBLE else View.GONE
        moveEnabled = p.getBoolean("aod_move", true)

        // position
        val gravity = when (p.getString("aod_position", "center")) {
            "top" -> Gravity.TOP or Gravity.CENTER_HORIZONTAL
            "bottom" -> Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
            else -> Gravity.CENTER
        }
        val blp = box.layoutParams as FrameLayout.LayoutParams
        blp.gravity = gravity
        if (gravity != Gravity.CENTER) {
            val pad = (96 * resources.displayMetrics.density).toInt()
            blp.topMargin = if (gravity and Gravity.TOP == Gravity.TOP) pad else 0
            blp.bottomMargin = if (gravity and Gravity.BOTTOM == Gravity.BOTTOM) pad else 0
        }
        box.layoutParams = blp

        // auto off
        val minutes = (p.getString("aod_timeout", "30") ?: "30").toInt()
        if (minutes > 0) handler.postDelayed({ finish() }, minutes * 60_000L)

        WindowCompat.setDecorFitsSystemWindows(window, false)
        WindowInsetsControllerCompat(window, window.decorView).apply {
            hide(WindowInsetsCompat.Type.systemBars())
            systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        }
    }

    override fun onResume() {
        super.onResume()
        handler.post(tick)
    }

    override fun onPause() {
        handler.removeCallbacks(tick)
        super.onPause()
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        super.onDestroy()
    }
}
