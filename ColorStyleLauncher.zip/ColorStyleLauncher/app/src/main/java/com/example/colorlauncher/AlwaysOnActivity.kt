package com.example.colorlauncher

import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.View
import android.view.WindowManager
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import kotlin.random.Random

/** Black clock screen at minimum brightness. Moves slightly every minute to avoid screen burn-in. */
class AlwaysOnActivity : AppCompatActivity() {

    private val handler = Handler(Looper.getMainLooper())
    private lateinit var box: View
    private lateinit var battery: TextView

    private val tick = object : Runnable {
        override fun run() {
            val i = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
            val level = i?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
            val scale = i?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100
            val status = i?.getIntExtra(BatteryManager.EXTRA_STATUS, -1) ?: -1
            val charging = status == BatteryManager.BATTERY_STATUS_CHARGING ||
                status == BatteryManager.BATTERY_STATUS_FULL
            if (level >= 0 && scale > 0) {
                val pct = level * 100 / scale
                battery.text = if (charging) "$pct%  charging" else "$pct%"
            }
            val d = resources.displayMetrics.density
            box.translationX = Random.nextInt(-40, 41) * d
            box.translationY = Random.nextInt(-60, 61) * d
            handler.postDelayed(this, 60_000)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        val lp = window.attributes
        lp.screenBrightness = 0.02f
        window.attributes = lp

        setContentView(R.layout.activity_aod)
        box = findViewById(R.id.aodBox)
        battery = findViewById(R.id.aodBattery)
        findViewById<View>(R.id.aodRoot).setOnClickListener { finish() }

        WindowCompat.setDecorFitsSystemWindows(window, false)
        WindowInsetsControllerCompat(window, window.decorView).apply {
            hide(WindowInsetsCompat.Type.systemBars())
            systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        }
    }

    override fun onResume() {
        super.onResume()
        handler.post(tick)
    }

    override fun onPause() {
        handler.removeCallbacks(tick)
        super.onPause()
    }
}
