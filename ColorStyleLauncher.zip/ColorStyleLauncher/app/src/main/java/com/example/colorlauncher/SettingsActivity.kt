package com.example.colorlauncher

import android.content.Intent
import android.content.pm.ResolveInfo
import android.os.Bundle
import android.provider.Settings
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.NotificationManagerCompat
import androidx.preference.MultiSelectListPreference
import androidx.preference.Preference
import androidx.preference.PreferenceFragmentCompat
import androidx.preference.SwitchPreferenceCompat

class SettingsActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        title = "Launcher settings"
        if (savedInstanceState == null) {
            supportFragmentManager.beginTransaction()
                .replace(android.R.id.content, SettingsFragment())
                .commit()
        }
    }

    class SettingsFragment : PreferenceFragmentCompat() {
        override fun onCreatePreferences(savedInstanceState: Bundle?, rootKey: String?) {
            setPreferencesFromResource(R.xml.preferences, rootKey)

            // Fill the "Hidden apps" list with every installed app
            val ctx = requireContext()
            val pm = ctx.packageManager
            val query = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
            val apps: List<ResolveInfo> = pm.queryIntentActivities(query, 0)
                .filter { it.activityInfo.packageName != ctx.packageName }
                .distinctBy { it.activityInfo.packageName }
                .sortedBy { it.loadLabel(pm).toString().lowercase() }
            findPreference<MultiSelectListPreference>("hidden_apps")?.apply {
                entries = apps.map { it.loadLabel(pm) as CharSequence }.toTypedArray()
                entryValues = apps.map { it.activityInfo.packageName as CharSequence }.toTypedArray()
            }

            findPreference<SwitchPreferenceCompat>("badges")?.setOnPreferenceChangeListener { _, newValue ->
                val on = newValue == true
                val granted = NotificationManagerCompat.getEnabledListenerPackages(ctx).contains(ctx.packageName)
                if (on && !granted) {
                    Toast.makeText(ctx, "Allow notification access for Color Launcher", Toast.LENGTH_LONG).show()
                    startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
                }
                true
            }

            findPreference<Preference>("wallpaper")?.setOnPreferenceClickListener {
                startActivity(Intent.createChooser(Intent(Intent.ACTION_SET_WALLPAPER), "Wallpaper"))
                true
            }

            findPreference<Preference>("reset_layout")?.setOnPreferenceClickListener {
                AlertDialog.Builder(ctx)
                    .setTitle("Reset home screen layout?")
                    .setMessage("All apps are placed again from scratch. Folders and widgets are removed.")
                    .setPositiveButton("Reset") { _, _ ->
                        preferenceManager.sharedPreferences?.edit()?.putBoolean("reset_layout_flag", true)?.apply()
                        Toast.makeText(ctx, "Layout will reset when you go back to the home screen", Toast.LENGTH_LONG).show()
                    }
                    .setNegativeButton("Cancel", null)
                    .show()
                true
            }

            findPreference<Preference>("reset")?.setOnPreferenceClickListener {
                AlertDialog.Builder(ctx)
                    .setTitle("Reset all settings?")
                    .setPositiveButton("Reset") { _, _ ->
                        preferenceManager.sharedPreferences?.edit()?.clear()?.apply()
                        requireActivity().recreate()
                    }
                    .setNegativeButton("Cancel", null)
                    .show()
                true
            }
        }
    }
}

class AodSettingsActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        title = "Always-on clock"
        if (savedInstanceState == null) {
            supportFragmentManager.beginTransaction()
                .replace(android.R.id.content, AodFragment())
                .commit()
        }
    }

    class AodFragment : PreferenceFragmentCompat() {
        override fun onCreatePreferences(savedInstanceState: Bundle?, rootKey: String?) {
            setPreferencesFromResource(R.xml.aod_prefs, rootKey)
            findPreference<Preference>("aod_preview")?.setOnPreferenceClickListener {
                startActivity(Intent(requireContext(), AlwaysOnActivity::class.java))
                true
            }
        }
    }
}
