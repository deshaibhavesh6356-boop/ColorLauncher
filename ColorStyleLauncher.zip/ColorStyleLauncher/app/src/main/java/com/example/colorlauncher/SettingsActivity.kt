package com.example.colorlauncher

import android.content.Intent
import android.content.pm.ResolveInfo
import android.os.Bundle
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.preference.MultiSelectListPreference
import androidx.preference.Preference
import androidx.preference.PreferenceFragmentCompat

class SettingsActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        title = "Launcher settings"
        if (savedInstanceState == null) {
            supportFragmentManager.beginTransaction()
                .replace(android.R.id.content, SettingsFragment())
                .commit()
        }
    }

    class SettingsFragment : PreferenceFragmentCompat() {
        override fun onCreatePreferences(savedInstanceState: Bundle?, rootKey: String?) {
            setPreferencesFromResource(R.xml.preferences, rootKey)

            // Fill the "Hidden apps" list with every installed app
            val ctx = requireContext()
            val pm = ctx.packageManager
            val query = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
            val apps: List<ResolveInfo> = pm.queryIntentActivities(query, 0)
                .filter { it.activityInfo.packageName != ctx.packageName }
                .distinctBy { it.activityInfo.packageName }
                .sortedBy { it.loadLabel(pm).toString().lowercase() }
            findPreference<MultiSelectListPreference>("hidden_apps")?.apply {
                entries = apps.map { it.loadLabel(pm) as CharSequence }.toTypedArray()
                entryValues = apps.map { it.activityInfo.packageName as CharSequence }.toTypedArray()
            }

            findPreference<Preference>("wallpaper")?.setOnPreferenceClickListener {
                startActivity(Intent.createChooser(Intent(Intent.ACTION_SET_WALLPAPER), "Wallpaper"))
                true
            }

            findPreference<Preference>("reset")?.setOnPreferenceClickListener {
                AlertDialog.Builder(ctx)
                    .setTitle("Reset all settings?")
                    .setPositiveButton("Reset") { _, _ ->
                        preferenceManager.sharedPreferences?.edit()?.clear()?.apply()
                        requireActivity().recreate()
                    }
                    .setNegativeButton("Cancel", null)
                    .show()
                true
            }
        }
    }
}
