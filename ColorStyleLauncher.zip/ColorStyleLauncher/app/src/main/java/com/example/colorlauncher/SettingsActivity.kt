package com.example.colorlauncher

import android.content.Intent
import android.content.pm.ResolveInfo
import android.os.Bundle
import android.provider.Settings
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.NotificationManagerCompat
import androidx.preference.ListPreference
import androidx.preference.MultiSelectListPreference
import androidx.preference.Preference
import androidx.preference.PreferenceCategory
import androidx.preference.PreferenceFragmentCompat
import androidx.preference.PreferenceGroup
import androidx.preference.SeekBarPreference
import androidx.preference.SwitchPreferenceCompat
import kotlin.concurrent.thread

class SettingsActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        title = "Launcher settings"
        if (savedInstanceState == null) {
            supportFragmentManager.beginTransaction()
                .replace(android.R.id.content, SettingsFragment())
                .commit()
        }
    }

    class SettingsFragment : PreferenceFragmentCompat() {

        private val pickWallpaper = registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
            if (uri != null) {
                val app = requireContext().applicationContext
                thread {
                    val ok = WallpaperHelper.setFromUri(app, uri)
                    activity?.runOnUiThread {
                        Toast.makeText(app, if (ok) "Wallpaper set" else "Could not set wallpaper", Toast.LENGTH_SHORT).show()
                    }
                }
            }
        }

        private val createBackup = registerForActivityResult(ActivityResultContracts.CreateDocument()) { uri ->
            if (uri != null) {
                val ctx = requireContext()
                try {
                    ctx.contentResolver.openOutputStream(uri)?.use { it.write(Backup.dump(ctx).toByteArray()) }
                    Toast.makeText(ctx, "Backup saved", Toast.LENGTH_SHORT).show()
                } catch (e: Exception) {
                    Toast.makeText(ctx, "Could not save backup", Toast.LENGTH_SHORT).show()
                }
            }
        }

        private val openBackup = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
            if (uri != null) {
                val ctx = requireContext()
                val ok = try {
                    val text = ctx.contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() } ?: ""
                    Backup.restore(ctx, text)
                } catch (e: Exception) {
                    false
                }
                if (ok) {
                    Toast.makeText(ctx, "Restored. Go back to the home screen.", Toast.LENGTH_LONG).show()
                    requireActivity().recreate()
                } else {
                    Toast.makeText(ctx, "That file could not be restored", Toast.LENGTH_SHORT).show()
                }
            }
        }

        override fun onCreatePreferences(savedInstanceState: Bundle?, rootKey: String?) {
            setPreferencesFromResource(R.xml.preferences, rootKey)
            val ctx = requireContext()
            val pm = ctx.packageManager

            // app lists for "hidden" and "locked"
            val query = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
            val apps: List<ResolveInfo> = pm.queryIntentActivities(query, 0)
                .filter { it.activityInfo.packageName != ctx.packageName }
                .distinctBy { it.activityInfo.packageName }
                .sortedBy { it.loadLabel(pm).toString().lowercase() }
            for (key in listOf("hidden_apps", "locked_apps")) {
                findPreference<MultiSelectListPreference>(key)?.apply {
                    entries = apps.map { it.loadLabel(pm) as CharSequence }.toTypedArray()
                    entryValues = apps.map { it.activityInfo.packageName as CharSequence }.toTypedArray()
                }
            }

            // icon packs
            val packs = IconPacks.list(pm)
            findPreference<ListPreference>("icon_pack")?.apply {
                val first = if (packs.isEmpty()) "None (install an icon pack from the Play Store)" else "None"
                entries = (listOf(first) + packs.map { it.second }).map { it as CharSequence }.toTypedArray()
                entryValues = (listOf("none") + packs.map { it.first }).map { it as CharSequence }.toTypedArray()
            }

            findPreference<Preference>("presets")?.setOnPreferenceClickListener {
                AlertDialog.Builder(ctx)
                    .setTitle("Theme presets")
                    .setItems(Presets.names) { _, i ->
                        preferenceManager.sharedPreferences?.let { Presets.apply(it, i) }
                        requireActivity().recreate()
                    }
                    .show()
                true
            }

            findPreference<SwitchPreferenceCompat>("badges")?.setOnPreferenceChangeListener { _, newValue ->
                val granted = NotificationManagerCompat.getEnabledListenerPackages(ctx).contains(ctx.packageName)
                if (newValue == true && !granted) {
                    Toast.makeText(ctx, "Allow notification access for Color Launcher", Toast.LENGTH_LONG).show()
                    startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
                }
                true
            }

            findPreference<SwitchPreferenceCompat>("double_tap_lock")?.setOnPreferenceChangeListener { _, newValue ->
                if (newValue == true && LockService.instance == null) {
                    AlertDialog.Builder(ctx)
                        .setTitle("One more step")
                        .setMessage("Open Accessibility settings and switch on \"Color Launcher double-tap lock\". It only locks the screen and does not read anything.")
                        .setPositiveButton("Open settings") { _, _ ->
                            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
                        }
                        .setNegativeButton("Later", null)
                        .show()
                }
                true
            }

            findPreference<Preference>("wallpaper_gallery")?.setOnPreferenceClickListener {
                pickWallpaper.launch("image/*")
                true
            }
            findPreference<Preference>("wallpaper")?.setOnPreferenceClickListener {
                startActivity(Intent.createChooser(Intent(Intent.ACTION_SET_WALLPAPER), "Wallpaper"))
                true
            }
            findPreference<Preference>("backup")?.setOnPreferenceClickListener {
                createBackup.launch("color-launcher-backup.json")
                true
            }
            findPreference<Preference>("restore")?.setOnPreferenceClickListener {
                openBackup.launch(arrayOf("application/json", "text/plain", "*/*"))
                true
            }

            findPreference<Preference>("reset_layout")?.setOnPreferenceClickListener {
                AlertDialog.Builder(ctx)
                    .setTitle("Reset home screen layout?")
                    .setMessage("All apps are placed again from scratch. Folders and widgets are removed.")
                    .setPositiveButton("Reset") { _, _ ->
                        preferenceManager.sharedPreferences?.edit()?.putBoolean("reset_layout_flag", true)?.apply()
                        Toast.makeText(ctx, "Layout will reset when you go back to the home screen", Toast.LENGTH_LONG).show()
                    }
                    .setNegativeButton("Cancel", null)
                    .show()
                true
            }

            findPreference<Preference>("reset")?.setOnPreferenceClickListener {
                AlertDialog.Builder(ctx)
                    .setTitle("Reset all settings?")
                    .setPositiveButton("Reset") { _, _ ->
                        preferenceManager.sharedPreferences?.edit()?.clear()?.apply()
                        requireActivity().recreate()
                    }
                    .setNegativeButton("Cancel", null)
                    .show()
                true
            }

            styleAll(preferenceScreen)
        }

        /** Glass-card look for every row. */
        private fun styleAll(group: PreferenceGroup) {
            for (i in 0 until group.preferenceCount) {
                val p = group.getPreference(i)
                if (p is PreferenceGroup) {
                    if (p is PreferenceCategory) p.layoutResource = R.layout.pref_category
                    styleAll(p)
                } else if (p !is SeekBarPreference) {
                    p.layoutResource = R.layout.pref_card
                }
            }
        }
    }
}
