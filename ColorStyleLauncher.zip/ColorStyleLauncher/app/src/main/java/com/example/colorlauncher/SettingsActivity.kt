package com.example.colorlauncher

import android.content.Intent
import android.content.pm.ResolveInfo
import android.os.Bundle
import android.provider.Settings
import android.content.ClipData
import android.content.ClipboardManager
import android.graphics.Typeface
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.NotificationManagerCompat
import androidx.preference.ListPreference
import androidx.preference.MultiSelectListPreference
import androidx.preference.Preference
import androidx.preference.PreferenceCategory
import androidx.preference.PreferenceFragmentCompat
import androidx.preference.PreferenceGroup
import androidx.preference.SeekBarPreference
import androidx.preference.SwitchPreferenceCompat
import kotlin.concurrent.thread

class SettingsActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        title = "Launcher settings"
        if (savedInstanceState == null) {
            supportFragmentManager.beginTransaction()
                .replace(android.R.id.content, SettingsFragment())
                .commit()
        }
    }

    class SettingsFragment : PreferenceFragmentCompat() {

        private val pickWallpaper = registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
            if (uri != null) {
                val app = requireContext().applicationContext
                thread {
                    val ok = WallpaperHelper.setFromUri(app, uri)
                    activity?.runOnUiThread {
                        Toast.makeText(app, if (ok) "Wallpaper set" else "Could not set wallpaper", Toast.LENGTH_SHORT).show()
                    }
                }
            }
        }

        private val createBackup = registerForActivityResult(ActivityResultContracts.CreateDocument()) { uri ->
            if (uri != null) {
                val ctx = requireContext()
                try {
                    ctx.contentResolver.openOutputStream(uri)?.use { it.write(Backup.dump(ctx).toByteArray()) }
                    Toast.makeText(ctx, "Backup saved", Toast.LENGTH_SHORT).show()
                } catch (e: Exception) {
                    Toast.makeText(ctx, "Could not save backup", Toast.LENGTH_SHORT).show()
                }
            }
        }

        private val openBackup = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
            if (uri != null) {
                val ctx = requireContext()
                val ok = try {
                    val text = ctx.contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() } ?: ""
                    Backup.restore(ctx, text)
                } catch (e: Exception) {
                    false
                }
                if (ok) {
                    Toast.makeText(ctx, "Restored. Go back to the home screen.", Toast.LENGTH_LONG).show()
                    requireActivity().recreate()
                } else {
                    Toast.makeText(ctx, "That file could not be restored", Toast.LENGTH_SHORT).show()
                }
            }
        }

        override fun onCreatePreferences(savedInstanceState: Bundle?, rootKey: String?) {
            setPreferencesFromResource(R.xml.preferences, rootKey)
            val ctx = requireContext()
            val pm = ctx.packageManager

            // app lists for "hidden" and "locked"
            val query = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
            val apps: List<ResolveInfo> = pm.queryIntentActivities(query, 0)
                .filter { it.activityInfo.packageName != ctx.packageName }
                .distinctBy { it.activityInfo.packageName }
                .sortedBy { it.loadLabel(pm).toString().lowercase() }
            for (key in listOf("hidden_apps", "locked_apps")) {
                findPreference<MultiSelectListPreference>(key)?.apply {
                    entries = apps.map { it.loadLabel(pm) as CharSequence }.toTypedArray()
                    entryValues = apps.map { it.activityInfo.packageName as CharSequence }.toTypedArray()
                }
            }

            // icon packs
            val packs = IconPacks.list(pm)
            findPreference<ListPreference>("icon_pack")?.apply {
                val first = if (packs.isEmpty()) "None (install an icon pack from the Play Store)" else "None"
                entries = (listOf(first) + packs.map { it.second }).map { it as CharSequence }.toTypedArray()
                entryValues = (listOf("none") + packs.map { it.first }).map { it as CharSequence }.toTypedArray()
            }

            findPreference<Preference>("presets")?.setOnPreferenceClickListener {
                AlertDialog.Builder(ctx)
                    .setTitle("Theme presets")
                    .setItems(Presets.names) { _, i ->
                        preferenceManager.sharedPreferences?.let { Presets.apply(it, i) }
                        requireActivity().recreate()
                    }
                    .show()
                true
            }

            findPreference<SwitchPreferenceCompat>("badges")?.setOnPreferenceChangeListener { _, newValue ->
                val granted = NotificationManagerCompat.getEnabledListenerPackages(ctx).contains(ctx.packageName)
                if (newValue == true && !granted) {
                    Toast.makeText(ctx, "Allow notification access for Color Launcher", Toast.LENGTH_LONG).show()
                    startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
                }
                true
            }

            findPreference<SwitchPreferenceCompat>("double_tap_lock")?.setOnPreferenceChangeListener { _, newValue ->
                if (newValue == true && LockService.instance == null) {
                    AlertDialog.Builder(ctx)
                        .setTitle("One more step")
                        .setMessage("Open Accessibility settings and switch on \"Color Launcher double-tap lock\". It only locks the screen and does not read anything.")
                        .setPositiveButton("Open settings") { _, _ ->
                            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
                        }
                        .setNegativeButton("Later", null)
                        .show()
                }
                true
            }

            findPreference<Preference>("diag")?.setOnPreferenceClickListener {
                val report = Diagnostics.report(ctx)
                AlertDialog.Builder(ctx)
                    .setTitle("Diagnostics")
                    .setMessage(if (report.length > 3500) report.substring(0, 3500) + "\n..." else report)
                    .setPositiveButton("Copy all") { _, _ ->
                        val cm = ctx.getSystemService(android.content.Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
                        cm.setPrimaryClip(android.content.ClipData.newPlainText("report", report))
                        Toast.makeText(ctx, "Copied. Paste it in the chat.", Toast.LENGTH_SHORT).show()
                    }
                    .setNegativeButton("Close", null)
                    .show()
                true
            }

            findPreference<Preference>("widget_help")?.setOnPreferenceClickListener {
                AlertDialog.Builder(ctx)
                    .setTitle("Widget not loading?")
                    .setMessage(
                        "1. Long-press the widget on the home screen and choose Reload.\n\n" +
                            "2. Open the widget's own app once (for example Google), then come back.\n\n" +
                            "3. On Xiaomi / Redmi phones: Settings > Apps > Manage apps > the widget's app > " +
                            "turn on Autostart and set Battery saver to No restrictions. Do the same for Color Launcher.\n\n" +
                            "4. Change Widget compatibility (above), then Reload the widget.\n\n" +
                            "The widgets built into this launcher (clock, weather, music, search bar ...) never need any of this."
                    )
                    .setPositiveButton("Open app settings") { _, _ ->
                        startActivity(
                            Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, android.net.Uri.parse("package:" + ctx.packageName))
                        )
                    }
                    .setNegativeButton("Close", null)
                    .show()
                true
            }

            findPreference<Preference>("wallpaper_gallery")?.setOnPreferenceClickListener {
                pickWallpaper.launch("image/*")
                true
            }
            findPreference<Preference>("diag")?.setOnPreferenceClickListener {
                showDiag()
                true
            }
            findPreference<Preference>("widget_help")?.setOnPreferenceClickListener {
                Help.widgetHelp(requireActivity())
                true
            }

            findPreference<Preference>("wallpaper")?.setOnPreferenceClickListener {
                startActivity(Intent.createChooser(Intent(Intent.ACTION_SET_WALLPAPER), "Wallpaper"))
                true
            }
            findPreference<Preference>("backup")?.setOnPreferenceClickListener {
                createBackup.launch("color-launcher-backup.json")
                true
            }
            findPreference<Preference>("restore")?.setOnPreferenceClickListener {
                openBackup.launch(arrayOf("application/json", "text/plain", "*/*"))
                true
            }

            findPreference<Preference>("reset_layout")?.setOnPreferenceClickListener {
                AlertDialog.Builder(ctx)
                    .setTitle("Reset home screen layout?")
                    .setMessage("All apps are placed again from scratch. Folders and widgets are removed.")
                    .setPositiveButton("Reset") { _, _ ->
                        preferenceManager.sharedPreferences?.edit()?.putBoolean("reset_layout_flag", true)?.apply()
                        Toast.makeText(ctx, "Layout will reset when you go back to the home screen", Toast.LENGTH_LONG).show()
                    }
                    .setNegativeButton("Cancel", null)
                    .show()
                true
            }

            findPreference<Preference>("reset")?.setOnPreferenceClickListener {
                AlertDialog.Builder(ctx)
                    .setTitle("Reset all settings?")
                    .setPositiveButton("Reset") { _, _ ->
                        preferenceManager.sharedPreferences?.edit()?.clear()?.apply()
                        requireActivity().recreate()
                    }
                    .setNegativeButton("Cancel", null)
                    .show()
                true
            }

            styleAll(preferenceScreen)
        }

        private fun showDiag() {
            val ctx = requireContext()
            val text = Diagnostics.report(ctx)
            val tv = TextView(ctx)
            tv.text = text
            tv.textSize = 11f
            tv.typeface = Typeface.MONOSPACE
            tv.setTextIsSelectable(true)
            tv.setPadding(40, 24, 40, 24)
            val sv = ScrollView(ctx)
            sv.addView(tv)
            AlertDialog.Builder(ctx)
                .setTitle("Diagnostics")
                .setView(sv)
                .setPositiveButton("Copy") { _, _ ->
                    (ctx.getSystemService(android.content.Context.CLIPBOARD_SERVICE) as ClipboardManager)
                        .setPrimaryClip(ClipData.newPlainText("report", text))
                    Toast.makeText(ctx, "Copied", Toast.LENGTH_SHORT).show()
                }
                .setNeutralButton("Share") { _, _ ->
                    val i = Intent(Intent.ACTION_SEND)
                    i.type = "text/plain"
                    i.putExtra(Intent.EXTRA_TEXT, text)
                    startActivity(Intent.createChooser(i, "Send report"))
                }
                .setNegativeButton("Close", null)
                .show()
        }

        /** Glass-card look for every row. */
        private fun styleAll(group: PreferenceGroup) {
            for (i in 0 until group.preferenceCount) {
                val p = group.getPreference(i)
                if (p is PreferenceGroup) {
                    if (p is PreferenceCategory) p.layoutResource = R.layout.pref_category
                    styleAll(p)
                } else if (p !is SeekBarPreference) {
                    p.layoutResource = R.layout.pref_card
                }
            }
        }
    }
}
