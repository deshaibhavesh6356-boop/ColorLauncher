package com.example.colorlauncher

import android.annotation.SuppressLint
import android.graphics.drawable.Drawable
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView

data class AppInfo(val label: String, val pkg: String, val icon: Drawable, val installTime: Long)

/** Press feedback: icon shrinks slightly while touched. */
@SuppressLint("ClickableViewAccessibility")
fun View.pressFeedback(enabled: Boolean) {
    if (!enabled) {
        setOnTouchListener(null)
        return
    }
    setOnTouchListener { v, e ->
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN ->
                v.animate().scaleX(0.88f).scaleY(0.88f).setDuration(90).start()
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL ->
                v.animate().scaleX(1f).scaleY(1f).setDuration(140).start()
        }
        false
    }
}

class AppAdapter(
    private val cfg: LauncherPrefs,
    private val onClick: (AppInfo, View) -> Unit,
    private val onLongClick: (AppInfo) -> Unit
) : RecyclerView.Adapter<AppAdapter.VH>() {

    private var items = listOf<AppInfo>()

    fun submit(list: List<AppInfo>) {
        items = list
        notifyDataSetChanged()
    }

    fun first(): AppInfo? = items.firstOrNull()

    class VH(v: View) : RecyclerView.ViewHolder(v) {
        val icon: ImageView = v.findViewById(R.id.icon)
        val label: TextView = v.findViewById(R.id.label)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) =
        VH(LayoutInflater.from(parent.context).inflate(R.layout.item_app, parent, false))

    override fun getItemCount() = items.size

    override fun onBindViewHolder(holder: VH, position: Int) {
        val app = items[position]
        val px = (cfg.iconSize * holder.itemView.resources.displayMetrics.density).toInt()
        val lp = holder.icon.layoutParams
        if (lp.width != px || lp.height != px) {
            lp.width = px
            lp.height = px
            holder.icon.layoutParams = lp
        }
        holder.icon.setImageDrawable(app.icon)
        holder.label.text = app.label
        holder.label.visibility = if (cfg.showLabels) View.VISIBLE else View.GONE
        holder.label.textSize = cfg.labelSize.toFloat()
        holder.itemView.pressFeedback(cfg.pressEffect)
        holder.itemView.setOnClickListener { onClick(app, holder.icon) }
        holder.itemView.setOnLongClickListener { onLongClick(app); true }
    }
}

/** One home-screen page = one non-scrolling grid of apps. */
class PagesAdapter(
    private val cfg: LauncherPrefs,
    private val onClick: (AppInfo, View) -> Unit,
    private val onLongClick: (AppInfo) -> Unit,
    private val onEmptyLongClick: () -> Unit
) : RecyclerView.Adapter<PagesAdapter.VH>() {

    private var pages = listOf<List<AppInfo>>()

    fun submit(p: List<List<AppInfo>>) {
        pages = p
        notifyDataSetChanged()
    }

    class VH(val rv: RecyclerView) : RecyclerView.ViewHolder(rv)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val rv = RecyclerView(parent.context)
        rv.layoutParams = ViewGroup.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT
        )
        rv.layoutManager = object : GridLayoutManager(parent.context, cfg.columns) {
            override fun canScrollVertically() = false
        }
        rv.overScrollMode = View.OVER_SCROLL_NEVER
        rv.setHasFixedSize(true)
        rv.setItemViewCacheSize(40)
        rv.adapter = AppAdapter(cfg, onClick, onLongClick)
        // long-press on empty space of the home screen = quick menu
        rv.setOnLongClickListener { onEmptyLongClick(); true }
        return VH(rv)
    }

    override fun getItemCount() = pages.size

    override fun onBindViewHolder(holder: VH, position: Int) {
        (holder.rv.layoutManager as GridLayoutManager).spanCount = cfg.columns
        (holder.rv.adapter as AppAdapter).submit(pages[position])
    }
}
