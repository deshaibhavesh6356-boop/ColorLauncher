package com.example.colorlauncher

import android.annotation.SuppressLint
import android.graphics.drawable.Drawable
import android.util.SparseArray
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.dynamicanimation.animation.DynamicAnimation
import androidx.dynamicanimation.animation.SpringAnimation
import androidx.dynamicanimation.animation.SpringForce
import androidx.recyclerview.widget.RecyclerView

data class AppInfo(val label: String, val pkg: String, val icon: Drawable, val installTime: Long, val category: Int = -1)

/** Bouncy press feedback: the icon squeezes and springs back like a liquid blob. */
@SuppressLint("ClickableViewAccessibility")
fun View.pressFeedback(enabled: Boolean) {
    if (!enabled) {
        setOnTouchListener(null)
        return
    }
    setOnTouchListener { v, e ->
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> springScale(v, 0.86f)
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> springScale(v, 1f)
        }
        false
    }
}

private fun springScale(v: View, target: Float) {
    for (prop in arrayOf(DynamicAnimation.SCALE_X, DynamicAnimation.SCALE_Y)) {
        val anim = SpringAnimation(v, prop)
        anim.setSpring(
            SpringForce(target)
                .setStiffness(SpringForce.STIFFNESS_MEDIUM)
                .setDampingRatio(0.45f)
        )
        anim.start()
    }
}

/** Grid of apps used by the drawer and the folder popup (always white text on a dark panel). */
class AppAdapter(
    private val cfg: LauncherPrefs,
    private val onClick: (AppInfo, View) -> Unit,
    private val onLongClick: (AppInfo, View) -> Unit
) : RecyclerView.Adapter<AppAdapter.VH>() {

    private var items = listOf<AppInfo>()

    fun submit(list: List<AppInfo>) {
        items = list
        notifyDataSetChanged()
    }

    fun first(): AppInfo? = items.firstOrNull()

    fun indexOfLetter(ch: Char): Int = items.indexOfFirst {
        val f = it.label.firstOrNull()?.uppercaseChar() ?: '#'
        if (ch == '#') !f.isLetter() else f == ch
    }

    class VH(v: View) : RecyclerView.ViewHolder(v) {
        val icon: ImageView = v.findViewById(R.id.icon)
        val label: TextView = v.findViewById(R.id.label)
        val badge: View = v.findViewById(R.id.badge)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) =
        VH(LayoutInflater.from(parent.context).inflate(R.layout.item_app, parent, false))

    override fun getItemCount() = items.size

    override fun onBindViewHolder(holder: VH, position: Int) {
        val app = items[position]
        val px = (cfg.iconSize * holder.itemView.resources.displayMetrics.density).toInt()
        val lp = holder.icon.layoutParams
        if (lp.width != px || lp.height != px) {
            lp.width = px
            lp.height = px
            holder.icon.layoutParams = lp
        }
        holder.itemView.visibility = View.VISIBLE
        holder.itemView.scaleX = 1f
        holder.itemView.scaleY = 1f
        holder.icon.setImageDrawable(app.icon)
        holder.label.text = app.label
        holder.label.visibility = if (cfg.showLabels) View.VISIBLE else View.GONE
        holder.label.textSize = cfg.labelSize.toFloat()
        holder.label.typeface = LauncherPrefs.typeface(cfg.fontStyle)
        holder.badge.visibility =
            if (cfg.badges && Badges.count(app.pkg) > 0) View.VISIBLE else View.GONE
        holder.itemView.pressFeedback(cfg.pressEffect)
        holder.itemView.setOnClickListener { onClick(app, holder.icon) }
        holder.itemView.setOnLongClickListener { onLongClick(app, holder.itemView); true }
    }
}

/** One home-screen page = one CellLayout. The activity fills it in through [onBind]. */
class WorkspaceAdapter(
    private val onBind: (Int, CellLayout) -> Unit
) : RecyclerView.Adapter<WorkspaceAdapter.VH>() {

    var count = 1
    val cells = SparseArray<CellLayout>()

    class VH(val cell: CellLayout) : RecyclerView.ViewHolder(cell)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val cell = CellLayout(parent.context)
        cell.layoutParams = ViewGroup.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT
        )
        return VH(cell)
    }

    override fun getItemCount() = count

    override fun onBindViewHolder(holder: VH, position: Int) {
        cells.put(position, holder.cell)
        holder.cell.tag = position
        onBind(position, holder.cell)
    }

    override fun onViewRecycled(holder: VH) {
        val pos = holder.cell.tag as? Int
        if (pos != null && cells.get(pos) === holder.cell) cells.remove(pos)
        super.onViewRecycled(holder)
    }
}
