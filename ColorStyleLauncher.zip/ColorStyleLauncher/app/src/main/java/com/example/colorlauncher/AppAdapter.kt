package com.example.colorlauncher

import android.annotation.SuppressLint
import android.graphics.drawable.Drawable
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView

data class AppInfo(val label: String, val pkg: String, val icon: Drawable)

/** ColorOS-style press feedback: icon shrinks slightly while touched. */
@SuppressLint("ClickableViewAccessibility")
fun View.pressFeedback() {
    setOnTouchListener { v, e ->
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN ->
                v.animate().scaleX(0.88f).scaleY(0.88f).setDuration(90).start()
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL ->
                v.animate().scaleX(1f).scaleY(1f).setDuration(140).start()
        }
        false
    }
}

class AppAdapter(
    private val onClick: (AppInfo, View) -> Unit,
    private val onLongClick: (AppInfo) -> Unit
) : RecyclerView.Adapter<AppAdapter.VH>() {

    private var items = listOf<AppInfo>()

    fun submit(list: List<AppInfo>) {
        items = list
        notifyDataSetChanged()
    }

    fun first(): AppInfo? = items.firstOrNull()

    class VH(v: View) : RecyclerView.ViewHolder(v) {
        val icon: ImageView = v.findViewById(R.id.icon)
        val label: TextView = v.findViewById(R.id.label)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) =
        VH(LayoutInflater.from(parent.context).inflate(R.layout.item_app, parent, false))

    override fun getItemCount() = items.size

    override fun onBindViewHolder(holder: VH, position: Int) {
        val app = items[position]
        holder.icon.setImageDrawable(app.icon)
        holder.label.text = app.label
        holder.itemView.pressFeedback()
        holder.itemView.setOnClickListener { onClick(app, holder.icon) }
        holder.itemView.setOnLongClickListener { onLongClick(app); true }
    }
}

/** One home-screen page = one non-scrolling 4-column grid of apps. */
class PagesAdapter(
    private val onClick: (AppInfo, View) -> Unit,
    private val onLongClick: (AppInfo) -> Unit
) : RecyclerView.Adapter<PagesAdapter.VH>() {

    private var pages = listOf<List<AppInfo>>()

    fun submit(p: List<List<AppInfo>>) {
        pages = p
        notifyDataSetChanged()
    }

    class VH(val rv: RecyclerView) : RecyclerView.ViewHolder(rv)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val rv = RecyclerView(parent.context)
        rv.layoutParams = ViewGroup.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT
        )
        rv.layoutManager = object : GridLayoutManager(parent.context, 4) {
            override fun canScrollVertically() = false
        }
        rv.overScrollMode = View.OVER_SCROLL_NEVER
        rv.adapter = AppAdapter(onClick, onLongClick)
        return VH(rv)
    }

    override fun getItemCount() = pages.size

    override fun onBindViewHolder(holder: VH, position: Int) {
        (holder.rv.adapter as AppAdapter).submit(pages[position])
    }
}
