package com.example.colorlauncher

import android.annotation.SuppressLint
import android.graphics.drawable.Drawable
import android.util.SparseArray
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

data class AppInfo(val label: String, val pkg: String, val icon: Drawable, val installTime: Long)

/** Press feedback: icon shrinks slightly while touched. */
@SuppressLint("ClickableViewAccessibility")
fun View.pressFeedback(enabled: Boolean) {
    if (!enabled) {
        setOnTouchListener(null)
        return
    }
    setOnTouchListener { v, e ->
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN ->
                v.animate().scaleX(0.88f).scaleY(0.88f).setDuration(90).start()
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL ->
                v.animate().scaleX(1f).scaleY(1f).setDuration(140).start()
        }
        false
    }
}

/** Grid of apps used by the drawer and the folder popup (always white text on a dark panel). */
class AppAdapter(
    private val cfg: LauncherPrefs,
    private val onClick: (AppInfo, View) -> Unit,
    private val onLongClick: (AppInfo, View) -> Unit
) : RecyclerView.Adapter<AppAdapter.VH>() {

    private var items = listOf<AppInfo>()

    fun submit(list: List<AppInfo>) {
        items = list
        notifyDataSetChanged()
    }

    fun first(): AppInfo? = items.firstOrNull()

    class VH(v: View) : RecyclerView.ViewHolder(v) {
        val icon: ImageView = v.findViewById(R.id.icon)
        val label: TextView = v.findViewById(R.id.label)
        val badge: View = v.findViewById(R.id.badge)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) =
        VH(LayoutInflater.from(parent.context).inflate(R.layout.item_app, parent, false))

    override fun getItemCount() = items.size

    override fun onBindViewHolder(holder: VH, position: Int) {
        val app = items[position]
        val px = (cfg.iconSize * holder.itemView.resources.displayMetrics.density).toInt()
        val lp = holder.icon.layoutParams
        if (lp.width != px || lp.height != px) {
            lp.width = px
            lp.height = px
            holder.icon.layoutParams = lp
        }
        holder.itemView.visibility = View.VISIBLE
        holder.itemView.scaleX = 1f
        holder.itemView.scaleY = 1f
        holder.icon.setImageDrawable(app.icon)
        holder.label.text = app.label
        holder.label.visibility = if (cfg.showLabels) View.VISIBLE else View.GONE
        holder.label.textSize = cfg.labelSize.toFloat()
        holder.label.typeface = LauncherPrefs.typeface(cfg.fontStyle)
        holder.badge.visibility =
            if (cfg.badges && Badges.count(app.pkg) > 0) View.VISIBLE else View.GONE
        holder.itemView.pressFeedback(cfg.pressEffect)
        holder.itemView.setOnClickListener { onClick(app, holder.icon) }
        holder.itemView.setOnLongClickListener { onLongClick(app, holder.itemView); true }
    }
}

/** One home-screen page = one CellLayout. The activity fills it in through [onBind]. */
class WorkspaceAdapter(
    private val onBind: (Int, CellLayout) -> Unit
) : RecyclerView.Adapter<WorkspaceAdapter.VH>() {

    var count = 1
    val cells = SparseArray<CellLayout>()

    class VH(val cell: CellLayout) : RecyclerView.ViewHolder(cell)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val cell = CellLayout(parent.context)
        cell.layoutParams = ViewGroup.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT
        )
        return VH(cell)
    }

    override fun getItemCount() = count

    override fun onBindViewHolder(holder: VH, position: Int) {
        cells.put(position, holder.cell)
        holder.cell.tag = position
        onBind(position, holder.cell)
    }

    override fun onViewRecycled(holder: VH) {
        val pos = holder.cell.tag as? Int
        if (pos != null && cells.get(pos) === holder.cell) cells.remove(pos)
        super.onViewRecycled(holder)
    }
}
