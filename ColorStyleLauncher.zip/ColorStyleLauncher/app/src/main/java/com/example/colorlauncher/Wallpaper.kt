package com.example.colorlauncher

import android.app.WallpaperManager
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.drawable.Drawable
import android.net.Uri
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import kotlin.math.max

/** A small, heavily blurred copy of the wallpaper that the glass panels draw behind themselves. */
object Backdrop {
    @Volatile
    var bitmap: Bitmap? = null

    @Volatile
    var enabled = true

    fun savedFile(ctx: Context): File = File(ctx.filesDir, "wallpaper_copy.jpg")

    fun rebuild(ctx: Context, screenW: Int, screenH: Int) {
        var src: Bitmap? = null
        try {
            val f = savedFile(ctx)
            if (f.exists()) {
                val o = BitmapFactory.Options()
                o.inSampleSize = 4
                src = BitmapFactory.decodeFile(f.path, o)
            }
        } catch (e: Exception) {
            src = null
        }
        if (src == null) {
            try {
                val d = WallpaperManager.getInstance(ctx).drawable
                if (d != null) src = drawableToBitmap(d, 400)
            } catch (e: Exception) {
                src = null // the phone does not let us read the wallpaper
            }
        }
        val s = src
        bitmap = if (s == null || screenW <= 0 || screenH <= 0) null else blurCropped(s, screenW, screenH)
    }

    private fun drawableToBitmap(d: Drawable, maxSide: Int): Bitmap {
        val w = max(1, d.intrinsicWidth)
        val h = max(1, d.intrinsicHeight)
        val s = maxSide.toFloat() / max(w, h)
        val bw = max(1, (w * s).toInt())
        val bh = max(1, (h * s).toInt())
        val b = Bitmap.createBitmap(bw, bh, Bitmap.Config.ARGB_8888)
        d.setBounds(0, 0, bw, bh)
        d.draw(Canvas(b))
        return b
    }

    private fun blurCropped(src: Bitmap, sw: Int, sh: Int): Bitmap {
        val outW = 90
        val outH = max(1, outW * sh / sw)
        val scale = max(outW.toFloat() / src.width, outH.toFloat() / src.height)
        val dw = src.width * scale
        val dh = src.height * scale
        val out = Bitmap.createBitmap(outW, outH, Bitmap.Config.ARGB_8888)
        Canvas(out).drawBitmap(
            src, null,
            RectF((outW - dw) / 2, (outH - dh) / 2, (outW + dw) / 2, (outH + dh) / 2),
            Paint(Paint.FILTER_BITMAP_FLAG)
        )
        boxBlur(out, 3, 2)
        return out
    }

    private fun boxBlur(bmp: Bitmap, r: Int, passes: Int) {
        val w = bmp.width
        val h = bmp.height
        val px = IntArray(w * h)
        bmp.getPixels(px, 0, w, 0, 0, w, h)
        val tmp = IntArray(w * h)
        repeat(passes) {
            blurPass(px, tmp, w, h, r, true)
            blurPass(tmp, px, w, h, r, false)
        }
        bmp.setPixels(px, 0, w, 0, 0, w, h)
    }

    private fun blurPass(src: IntArray, dst: IntArray, w: Int, h: Int, r: Int, horizontal: Boolean) {
        val lines = if (horizontal) h else w
        val len = if (horizontal) w else h
        for (l in 0 until lines) {
            for (i in 0 until len) {
                var a = 0
                var rr = 0
                var g = 0
                var b = 0
                var n = 0
                for (k in -r..r) {
                    val j = (i + k).coerceIn(0, len - 1)
                    val p = if (horizontal) src[l * w + j] else src[j * w + l]
                    a += p ushr 24
                    rr += (p shr 16) and 255
                    g += (p shr 8) and 255
                    b += p and 255
                    n++
                }
                val out = ((a / n) shl 24) or ((rr / n) shl 16) or ((g / n) shl 8) or (b / n)
                if (horizontal) dst[l * w + i] = out else dst[i * w + l] = out
            }
        }
    }
}

object WallpaperHelper {
    /** Sets the phone wallpaper from a picked image and keeps a copy for the frosted glass. */
    fun setFromUri(ctx: Context, uri: Uri): Boolean {
        return try {
            val file = Backdrop.savedFile(ctx)
            ctx.contentResolver.openInputStream(uri)?.use { ins ->
                FileOutputStream(file).use { out -> ins.copyTo(out) }
            } ?: return false
            val wm = WallpaperManager.getInstance(ctx)
            FileInputStream(file).use { ins ->
                wm.setStream(ins, null, true, WallpaperManager.FLAG_SYSTEM or WallpaperManager.FLAG_LOCK)
            }
            val id = wm.getWallpaperId(WallpaperManager.FLAG_SYSTEM)
            ctx.getSharedPreferences("backdrop", Context.MODE_PRIVATE).edit().putInt("bd_id", id).apply()
            true
        } catch (e: Exception) {
            false
        }
    }
}
