package com.example.colorlauncher

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Path
import android.graphics.RectF
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.util.AttributeSet
import android.widget.LinearLayout
import androidx.dynamicanimation.animation.FloatPropertyCompat
import kotlin.math.max

/**
 * The app drawer. At progress 0 it is exactly the shape of the dock; as progress grows the glass
 * stretches (rounded corners and all) until it fills the screen, and the apps fade in inside it.
 * Progress can follow your finger and is then settled by a spring, so it feels like liquid.
 */
class MorphLayout @JvmOverloads constructor(
    ctx: Context,
    attrs: AttributeSet? = null
) : LinearLayout(ctx, attrs) {

    companion object {
        val PROGRESS = object : FloatPropertyCompat<MorphLayout>("progress") {
            override fun getValue(o: MorphLayout): Float = o.progress
            override fun setValue(o: MorphLayout, value: Float) {
                o.progress = value
            }
        }
    }

    var onProgress: ((Float) -> Unit)? = null
    var panel: Drawable? = null
    var scrimAlpha = 0.5f
    val startRect = RectF()
    var startRadius = 0f
    var endRadius = 0f
    var endBleed = 0f

    var progress = 0f
        set(value) {
            field = value
            invalidate()
            onProgress?.invoke(value)
        }

    private val rect = RectF()
    private val path = Path()

    private fun lerp(a: Float, b: Float, t: Float) = a + (b - a) * t

    override fun dispatchDraw(canvas: Canvas) {
        val p = progress
        if (width == 0 || height == 0) return
        // a little overshoot at both ends gives the spring its wobble
        val t = p.coerceIn(-0.06f, 1.08f)
        rect.set(
            lerp(startRect.left, -endBleed, t),
            lerp(startRect.top, -endBleed, t),
            lerp(startRect.right, width + endBleed, t),
            lerp(startRect.bottom, height + endBleed, t)
        )
        val radius = max(0f, lerp(startRadius, endRadius, t.coerceIn(0f, 1f)))

        val sa = (scrimAlpha * 255f * p.coerceIn(0f, 1f)).toInt()
        if (sa > 0) canvas.drawColor(Color.argb(sa, 16, 18, 22))

        val d = panel
        if (d != null && p > 0.002f) {
            if (d is GlassDrawable) {
                d.setRadiusPx(radius)
            } else if (d is GradientDrawable) {
                d.cornerRadius = radius
            }
            d.setBounds(rect.left.toInt(), rect.top.toInt(), rect.right.toInt(), rect.bottom.toInt())
            d.draw(canvas)
        }

        // the apps appear late, so the first thing you see is the dock turning into glass
        val contentAlpha = ((p - 0.4f) / 0.45f).coerceIn(0f, 1f)
        if (contentAlpha > 0.01f) {
            canvas.save()
            path.reset()
            path.addRoundRect(rect, radius, radius, Path.Direction.CW)
            canvas.clipPath(path)
            canvas.saveLayerAlpha(0f, 0f, width.toFloat(), height.toFloat(), (contentAlpha * 255f).toInt())
            super.dispatchDraw(canvas)
            canvas.restore()
            canvas.restore()
        }
    }
}
