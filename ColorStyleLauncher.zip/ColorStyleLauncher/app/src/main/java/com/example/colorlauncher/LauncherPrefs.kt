package com.example.colorlauncher

import android.content.Context
import android.content.SharedPreferences
import android.graphics.Typeface
import androidx.preference.PreferenceManager

/** Typed access to every launcher setting. */
class LauncherPrefs(ctx: Context) {
    val p: SharedPreferences = PreferenceManager.getDefaultSharedPreferences(ctx)

    val columns: Int get() = (p.getString("columns", "4") ?: "4").toInt()
    val rows: String get() = p.getString("rows", "auto") ?: "auto"
    val homeMode: String get() = p.getString("home_mode", "standard") ?: "standard"
    val showClock: Boolean get() = p.getBoolean("show_clock", true)
    val clockStyle: String get() = p.getString("clock_style", "thin") ?: "thin"
    val showSearch: Boolean get() = p.getBoolean("show_search", true)
    val showDots: Boolean get() = p.getBoolean("show_dots", true)
    val pageEffect: String get() = p.getString("page_effect", "slide") ?: "slide"
    val lockLayout: Boolean get() = p.getBoolean("lock_layout", false)
    val autoAdd: Boolean get() = p.getBoolean("auto_add", true)
    val badges: Boolean get() = p.getBoolean("badges", true)

    val iconSize: Int get() = p.getInt("icon_size", 52)
    val iconShape: String get() = p.getString("icon_shape", "squircle") ?: "squircle"
    val showLabels: Boolean get() = p.getBoolean("show_labels", true)
    val labelSize: Int get() = p.getInt("label_size", 12)
    val fontStyle: String get() = p.getString("font_style", "default") ?: "default"
    val textColor: String get() = p.getString("text_color", "white") ?: "white"
    val sortOrder: String get() = p.getString("sort_order", "name") ?: "name"
    val hiddenApps: Set<String> get() = p.getStringSet("hidden_apps", emptySet()) ?: emptySet()

    val uiStyle: String get() = p.getString("ui_style", "glass") ?: "glass"
    val glassStrength: Int get() = p.getInt("glass_strength", 52)
    val blur: Boolean get() = p.getBoolean("blur_effects", true)
    val iconTheme: String get() = p.getString("icon_theme", "original") ?: "original"

    val frosted: Boolean get() = p.getBoolean("frosted_glass", true)
    val glassMotion: Boolean get() = p.getBoolean("glass_motion", false)
    val iconPack: String get() = p.getString("icon_pack", "none") ?: "none"
    val showGlance: Boolean get() = p.getBoolean("show_glance", true)
    val weatherCity: String get() = p.getString("weather_city", "") ?: ""
    val weatherF: Boolean get() = p.getBoolean("weather_f", false)
    val parallax: Boolean get() = p.getBoolean("parallax", true)
    val tilt: Boolean get() = p.getBoolean("tilt_depth", false)
    val shelf: Boolean get() = p.getBoolean("shelf", true)
    val doubleTapLock: Boolean get() = p.getBoolean("double_tap_lock", false)
    val showSuggested: Boolean get() = p.getBoolean("show_suggested", true)
    val lockedApps: Set<String> get() = p.getStringSet("locked_apps", emptySet()) ?: emptySet()
    val searchContacts: Boolean get() = p.getBoolean("search_contacts", false)

    val drawerStyle: String get() = p.getString("drawer_style", "morph") ?: "morph"
    val drawerShape: String get() = p.getString("drawer_shape", "full") ?: "full"
    val drawerBounce: String get() = p.getString("drawer_bounce", "normal") ?: "normal"
    val drawerSpeed: String get() = p.getString("drawer_speed", "normal") ?: "normal"
    val drawerGesture: String get() = p.getString("drawer_gesture", "dock") ?: "dock"
    val drawerPull: String get() = p.getString("drawer_pull", "normal") ?: "normal"
    val drawerReveal: String get() = p.getString("drawer_reveal", "fade") ?: "fade"
    val drawerBlur: Int get() = p.getInt("drawer_blur", 60)
    val drawerHaptic: Boolean get() = p.getBoolean("drawer_haptic", true)
    val widgetCtx: String get() = p.getString("widget_ctx", "activity") ?: "activity"

    /** Spring damping for the drawer: lower = more wobble. */
    val drawerDamping: Float
        get() = when (drawerBounce) {
            "tight" -> 0.95f
            "bouncy" -> 0.62f
            "jelly" -> 0.48f
            else -> 0.8f
        }

    val drawerStiffness: Float
        get() = when (drawerSpeed) {
            "slow" -> 110f
            "fast" -> 520f
            else -> 220f
        }

    /** How far you drag to open, as a fraction of the screen height. */
    val drawerPullFraction: Float
        get() = when (drawerPull) {
            "short" -> 0.30f
            "long" -> 0.65f
            else -> 0.45f
        }

    val showDock: Boolean get() = p.getBoolean("show_dock", true)
    val dockCount: Int get() = (p.getString("dock_count", "5") ?: "5").toInt()
    val dockOpacity: Int get() = p.getInt("dock_opacity", 20)

    val swipeUp: Boolean get() = p.getBoolean("swipe_up", true)
    val swipeDown: String get() = p.getString("swipe_down", "notifications") ?: "notifications"
    val drawerOpacity: Int get() = p.getInt("drawer_opacity", 95)

    val openAnim: String get() = p.getString("open_anim", "zoom") ?: "zoom"
    val closeAnim: String get() = p.getString("close_anim", "shrink") ?: "shrink"
    val pressEffect: Boolean get() = p.getBoolean("press_effect", true)
    val animScale: Float
        get() = when (p.getString("anim_speed", "normal")) {
            "fast" -> 0.7f
            "slow" -> 1.6f
            else -> 1f
        }

    fun dur(ms: Long): Long = (ms * animScale).toLong()

    /** Changes whenever any setting changes. */
    fun signature(): String =
        p.all.entries.sortedBy { it.key }.joinToString("|") { "${it.key}=${it.value}" }

    companion object {
        fun typeface(key: String): Typeface = when (key) {
            "thin" -> Typeface.create("sans-serif-thin", Typeface.NORMAL)
            "light" -> Typeface.create("sans-serif-light", Typeface.NORMAL)
            "medium" -> Typeface.create("sans-serif-medium", Typeface.NORMAL)
            "condensed" -> Typeface.create("sans-serif-condensed", Typeface.NORMAL)
            "black" -> Typeface.create("sans-serif-black", Typeface.NORMAL)
            "serif" -> Typeface.create("serif", Typeface.NORMAL)
            "mono" -> Typeface.create("monospace", Typeface.NORMAL)
            "casual" -> Typeface.create("casual", Typeface.NORMAL)
            "cursive" -> Typeface.create("cursive", Typeface.NORMAL)
            else -> Typeface.DEFAULT
        }

        fun color(key: String): Int = when (key) {
            "orange" -> 0xFFFF9A3D.toInt()
            "blue" -> 0xFF4DA3FF.toInt()
            "green" -> 0xFF5CE08A.toInt()
            "pink" -> 0xFFFF6FB5.toInt()
            "yellow" -> 0xFFFFE066.toInt()
            "red" -> 0xFFFF5A5A.toInt()
            "cyan" -> 0xFF4DE8E8.toInt()
            "purple" -> 0xFFB388FF.toInt()
            else -> 0xFFFFFFFF.toInt()
        }
    }
}
