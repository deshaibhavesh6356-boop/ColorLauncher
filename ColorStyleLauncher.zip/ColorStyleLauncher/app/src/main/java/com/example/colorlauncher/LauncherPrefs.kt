package com.example.colorlauncher

import android.content.Context
import android.content.SharedPreferences
import androidx.preference.PreferenceManager

/** Typed access to every launcher setting. */
class LauncherPrefs(ctx: Context) {
    val p: SharedPreferences = PreferenceManager.getDefaultSharedPreferences(ctx)

    val columns: Int get() = (p.getString("columns", "4") ?: "4").toInt()
    val rows: String get() = p.getString("rows", "auto") ?: "auto"
    val homeMode: String get() = p.getString("home_mode", "standard") ?: "standard"
    val showClock: Boolean get() = p.getBoolean("show_clock", true)
    val showSearch: Boolean get() = p.getBoolean("show_search", true)
    val showDots: Boolean get() = p.getBoolean("show_dots", true)
    val pageEffect: String get() = p.getString("page_effect", "slide") ?: "slide"
    val lockLayout: Boolean get() = p.getBoolean("lock_layout", false)

    val iconSize: Int get() = p.getInt("icon_size", 52)
    val iconShape: String get() = p.getString("icon_shape", "squircle") ?: "squircle"
    val showLabels: Boolean get() = p.getBoolean("show_labels", true)
    val labelSize: Int get() = p.getInt("label_size", 12)
    val sortOrder: String get() = p.getString("sort_order", "name") ?: "name"
    val hiddenApps: Set<String> get() = p.getStringSet("hidden_apps", emptySet()) ?: emptySet()

    val showDock: Boolean get() = p.getBoolean("show_dock", true)
    val dockCount: Int get() = (p.getString("dock_count", "5") ?: "5").toInt()
    val dockOpacity: Int get() = p.getInt("dock_opacity", 20)

    val swipeUp: Boolean get() = p.getBoolean("swipe_up", true)
    val drawerOpacity: Int get() = p.getInt("drawer_opacity", 95)

    val openAnim: String get() = p.getString("open_anim", "zoom") ?: "zoom"
    val closeAnim: String get() = p.getString("close_anim", "shrink") ?: "shrink"
    val pressEffect: Boolean get() = p.getBoolean("press_effect", true)
    val animScale: Float
        get() = when (p.getString("anim_speed", "normal")) {
            "fast" -> 0.7f
            "slow" -> 1.6f
            else -> 1f
        }

    fun dur(ms: Long): Long = (ms * animScale).toLong()

    /** Changes whenever any setting changes. */
    fun signature(): String =
        p.all.entries.sortedBy { it.key }.joinToString("|") { "${it.key}=${it.value}" }
}
