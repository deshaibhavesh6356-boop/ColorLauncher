package com.example.colorlauncher

import java.math.BigDecimal
import java.math.MathContext
import kotlin.math.pow

/** Calculator and unit conversion for the drawer search box. */
object QuickSearch {

    private class Parser(val s: String) {
        var i = 0
        fun peek(): Char = if (i < s.length) s[i] else '\u0000'
        fun ws() {
            while (peek() == ' ') i++
        }

        fun expr(): Double {
            var v = term()
            while (true) {
                ws()
                val c = peek()
                if (c == '+') {
                    i++
                    v += term()
                } else if (c == '-') {
                    i++
                    v -= term()
                } else {
                    return v
                }
            }
        }

        fun term(): Double {
            var v = power()
            while (true) {
                ws()
                val c = peek()
                if (c == '*') {
                    i++
                    v *= power()
                } else if (c == '/') {
                    i++
                    v /= power()
                } else {
                    return v
                }
            }
        }

        fun power(): Double {
            val b = unary()
            ws()
            if (peek() == '^') {
                i++
                return b.pow(power())
            }
            return b
        }

        fun unary(): Double {
            ws()
            if (peek() == '-') {
                i++
                return -unary()
            }
            if (peek() == '+') {
                i++
                return unary()
            }
            return atom()
        }

        fun atom(): Double {
            ws()
            if (peek() == '(') {
                i++
                val v = expr()
                ws()
                if (peek() == ')') i++
                return v
            }
            val st = i
            while (peek().isDigit() || peek() == '.') i++
            if (st == i) throw IllegalArgumentException("number expected")
            var v = s.substring(st, i).toDouble()
            ws()
            if (peek() == '%') {
                i++
                v /= 100
            }
            return v
        }
    }

    private fun format(v: Double): String =
        BigDecimal(v).round(MathContext(10)).stripTrailingZeros().toPlainString()

    /** "12*(3+4)" -> "84". Null if the text is not a calculation. */
    fun calculate(q: String): String? {
        val t = q.trim().replace('x', '*').replace('×', '*').replace('÷', '/')
        if (!t.any { it.isDigit() }) return null
        if (!t.matches(Regex("[0-9+\\-*/^().% ]+"))) return null
        if (!t.any { it in "+-*/^%" }) return null
        return try {
            val p = Parser(t)
            val v = p.expr()
            p.ws()
            if (p.i != t.length || v.isNaN() || v.isInfinite()) null else format(v)
        } catch (e: Exception) {
            null
        }
    }

    private val factors: Map<String, Pair<String, Double>> = mapOf(
        "mm" to ("len" to 0.001), "cm" to ("len" to 0.01), "m" to ("len" to 1.0),
        "km" to ("len" to 1000.0), "in" to ("len" to 0.0254), "ft" to ("len" to 0.3048),
        "yd" to ("len" to 0.9144), "mi" to ("len" to 1609.344),
        "mg" to ("mass" to 0.000001), "g" to ("mass" to 0.001), "kg" to ("mass" to 1.0),
        "lb" to ("mass" to 0.45359237), "oz" to ("mass" to 0.028349523),
        "ml" to ("vol" to 0.001), "l" to ("vol" to 1.0), "gal" to ("vol" to 3.785411784),
        "cup" to ("vol" to 0.2365882365),
        "kmh" to ("spd" to 0.277777778), "mph" to ("spd" to 0.44704), "ms" to ("spd" to 1.0)
    )

    private val alias: Map<String, String> = mapOf(
        "kilometer" to "km", "kilometers" to "km", "kilometre" to "km", "kilometres" to "km",
        "meter" to "m", "meters" to "m", "metre" to "m", "metres" to "m",
        "centimeter" to "cm", "centimeters" to "cm", "millimeter" to "mm", "millimeters" to "mm",
        "mile" to "mi", "miles" to "mi", "inch" to "in", "inches" to "in",
        "foot" to "ft", "feet" to "ft", "yard" to "yd", "yards" to "yd",
        "kph" to "kmh", "km/h" to "kmh", "m/s" to "ms",
        "pound" to "lb", "pounds" to "lb", "lbs" to "lb", "ounce" to "oz", "ounces" to "oz",
        "kilogram" to "kg", "kilograms" to "kg", "gram" to "g", "grams" to "g",
        "liter" to "l", "litre" to "l", "liters" to "l", "litres" to "l",
        "gallon" to "gal", "gallons" to "gal", "cups" to "cup",
        "celsius" to "c", "fahrenheit" to "f", "kelvin" to "k", "°c" to "c", "°f" to "f"
    )

    private fun canon(u: String): String = alias[u] ?: u

    /** "5 km to miles" -> "3.106856 mi". */
    fun convert(q: String): String? {
        val m = Regex("^\\s*(-?[0-9]*\\.?[0-9]+)\\s*([a-z°/]+)\\s+(?:to|in|into)\\s+([a-z°/]+)\\s*$")
            .find(q.lowercase()) ?: return null
        val value = m.groupValues[1].toDoubleOrNull() ?: return null
        val from = canon(m.groupValues[2])
        val to = canon(m.groupValues[3])
        val temps = setOf("c", "f", "k")
        if (from in temps && to in temps) {
            val c = when (from) {
                "c" -> value
                "f" -> (value - 32) * 5 / 9
                else -> value - 273.15
            }
            val r = when (to) {
                "c" -> c
                "f" -> c * 9 / 5 + 32
                else -> c + 273.15
            }
            val label = when (to) {
                "c" -> "°C"
                "f" -> "°F"
                else -> "K"
            }
            return format(r) + " " + label
        }
        val a = factors[from] ?: return null
        val b = factors[to] ?: return null
        if (a.first != b.first) return null
        return format(value * a.second / b.second) + " " + to
    }
}
