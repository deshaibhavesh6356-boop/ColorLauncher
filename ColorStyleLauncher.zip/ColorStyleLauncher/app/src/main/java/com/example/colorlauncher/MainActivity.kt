package com.example.colorlauncher

import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.ValueAnimator
import android.app.ActivityOptions
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapShader
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.drawable.AdaptiveIconDrawable
import android.graphics.drawable.BitmapDrawable
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.provider.Settings
import android.text.Editable
import android.text.TextWatcher
import android.view.GestureDetector
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.animation.DecelerateInterpolator
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.preference.PreferenceManager
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import androidx.viewpager2.widget.ViewPager2
import kotlin.concurrent.thread
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.pow
import kotlin.math.sign
import kotlin.math.sin

class MainActivity : AppCompatActivity() {

    private lateinit var cfg: LauncherPrefs
    private lateinit var root: FrameLayout
    private lateinit var home: View
    private lateinit var clockBox: View
    private lateinit var searchPill: View
    private lateinit var drawer: View
    private lateinit var search: EditText
    private lateinit var dock: LinearLayout
    private lateinit var dots: LinearLayout
    private lateinit var pager: ViewPager2
    private lateinit var overlay: View
    private lateinit var drawerList: RecyclerView
    private lateinit var pagesAdapter: PagesAdapter
    private lateinit var drawerAdapter: AppAdapter
    private lateinit var gestures: GestureDetector

    private var allApps = listOf<AppInfo>()
    private var visibleApps = listOf<AppInfo>()
    private var drawerOpen = false
    private var launched = false
    private var lastRect: Rect? = null
    private var lastColor = Color.WHITE
    private var appliedSignature = ""
    private var appliedShape = ""

    private val data by lazy { getSharedPreferences("launcher", MODE_PRIVATE) }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private val pkgReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            loadApps()
        }
    }

    // If a launch silently failed, bring the home screen back
    private val restoreRunnable = Runnable {
        if (launched && hasWindowFocus()) {
            launched = false
            resetHome()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        PreferenceManager.setDefaultValues(this, R.xml.preferences, false)
        cfg = LauncherPrefs(this)
        setContentView(R.layout.activity_main)

        root = findViewById(R.id.root)
        home = findViewById(R.id.home)
        clockBox = findViewById(R.id.clockBox)
        searchPill = findViewById(R.id.searchPill)
        drawer = findViewById(R.id.drawer)
        search = findViewById(R.id.search)
        dock = findViewById(R.id.dock)
        dots = findViewById(R.id.dots)
        pager = findViewById(R.id.pager)
        overlay = findViewById(R.id.overlay)
        drawerList = findViewById(R.id.recycler)

        // Home pages
        pagesAdapter = PagesAdapter(cfg, ::launch, ::showMenu, ::showQuickMenu)
        pager.adapter = pagesAdapter
        pager.offscreenPageLimit = 1
        pager.addOnLayoutChangeListener { _, _, t, _, b, _, ot, _, ob ->
            if (b - t != ob - ot) rebuildPages()
        }
        pager.registerOnPageChangeCallback(object : ViewPager2.OnPageChangeCallback() {
            override fun onPageSelected(position: Int) = updateDots(position)
        })

        // Drawer / search
        drawerAdapter = AppAdapter(cfg, ::launch, ::showMenu)
        drawerList.layoutManager = GridLayoutManager(this, cfg.columns)
        drawerList.adapter = drawerAdapter
        drawerList.setHasFixedSize(true)
        searchPill.setOnClickListener { openDrawer() }
        findViewById<View>(R.id.gear).setOnClickListener { openSettings() }
        search.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) {
                val q = s?.toString().orEmpty().trim().lowercase()
                drawerAdapter.submit(
                    if (q.isEmpty()) visibleApps else visibleApps.filter { it.label.lowercase().contains(q) }
                )
            }
        })
        search.setOnEditorActionListener { _, id, _ ->
            if (id == EditorInfo.IME_ACTION_GO) drawerAdapter.first()?.let { launch(it, search) }
            true
        }

        // Quick menu: long-press clock, search button or dock
        val quick = View.OnLongClickListener { showQuickMenu(); true }
        clockBox.setOnLongClickListener(quick)
        searchPill.setOnLongClickListener(quick)
        dock.setOnLongClickListener(quick)

        // Swipe up anywhere on home = open drawer
        gestures = GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onDown(e: MotionEvent) = true
            override fun onFling(e1: MotionEvent?, e2: MotionEvent, vx: Float, vy: Float): Boolean {
                if (e1 != null && e1.y - e2.y > 160 && abs(e1.y - e2.y) > abs(e1.x - e2.x) * 1.5f && vy < -400) {
                    openDrawer()
                    return true
                }
                return false
            }
        })

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (drawerOpen) closeDrawer() // on the home screen, back does nothing
            }
        })

        val filter = IntentFilter().apply {
            addAction(Intent.ACTION_PACKAGE_ADDED)
            addAction(Intent.ACTION_PACKAGE_REMOVED)
            addAction(Intent.ACTION_PACKAGE_REPLACED)
            addDataScheme("package")
        }
        ContextCompat.registerReceiver(this, pkgReceiver, filter, ContextCompat.RECEIVER_EXPORTED)

        applyConfigIfChanged()
    }

    override fun dispatchTouchEvent(ev: MotionEvent): Boolean {
        if (!drawerOpen && cfg.swipeUp) gestures.onTouchEvent(ev)
        return super.dispatchTouchEvent(ev)
    }

    override fun onDestroy() {
        unregisterReceiver(pkgReceiver)
        super.onDestroy()
    }

    // Home button pressed while already on the launcher
    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        if (drawerOpen) closeDrawer() else pager.setCurrentItem(0, true)
    }

    override fun onResume() {
        super.onResume()
        applyConfigIfChanged()
        home.removeCallbacks(restoreRunnable)
        if (!launched) {
            resetHome()
            return
        }
        launched = false
        if (cfg.closeAnim == "none") {
            resetHome()
            return
        }
        // Closing animation: home zooms back in, and a colour tile shrinks into the icon
        home.animate().cancel()
        home.scaleX = 1.08f
        home.scaleY = 1.08f
        home.alpha = 0f
        home.animate().scaleX(1f).scaleY(1f).alpha(1f)
            .setDuration(cfg.dur(320)).setInterpolator(DecelerateInterpolator()).withLayer().start()
        if (cfg.closeAnim == "shrink") playShrink()
    }

    private fun resetHome() {
        home.animate().cancel()
        home.scaleX = 1f
        home.scaleY = 1f
        home.alpha = 1f
    }

    private fun lerp(a: Float, b: Float, t: Float) = a + (b - a) * t

    private fun playShrink() {
        val r = lastRect ?: return
        val w = max(1, r.width()).toFloat()
        val h = max(1, r.height()).toFloat()
        val fullW = root.width.toFloat()
        val fullH = root.height.toFloat()
        if (fullW == 0f || fullH == 0f) return

        val bg = GradientDrawable().apply { setColor(lastColor) }
        overlay.animate().cancel()
        overlay.layoutParams = FrameLayout.LayoutParams(w.toInt(), h.toInt())
        overlay.background = bg
        overlay.pivotX = 0f
        overlay.pivotY = 0f
        overlay.alpha = 1f
        overlay.visibility = View.VISIBLE
        val endRadius = w * 0.30f

        ValueAnimator.ofFloat(0f, 1f).apply {
            duration = cfg.dur(320)
            interpolator = DecelerateInterpolator(1.4f)
            addUpdateListener { a ->
                val t = a.animatedValue as Float
                overlay.scaleX = lerp(fullW / w, 1f, t)
                overlay.scaleY = lerp(fullH / h, 1f, t)
                overlay.translationX = lerp(0f, r.left.toFloat(), t)
                overlay.translationY = lerp(0f, r.top.toFloat(), t)
                bg.cornerRadius = lerp(0f, endRadius, t)
                overlay.alpha = if (t < 0.6f) 1f else 1f - (t - 0.6f) / 0.4f
            }
            addListener(object : AnimatorListenerAdapter() {
                override fun onAnimationEnd(animation: Animator) {
                    overlay.visibility = View.GONE
                }
            })
            start()
        }
    }

    // ---------- Settings ----------
    private fun applyConfigIfChanged() {
        val sig = cfg.signature()
        if (sig == appliedSignature) return
        appliedSignature = sig
        applyConfig()
        if (cfg.iconShape != appliedShape) {
            appliedShape = cfg.iconShape
            loadApps()
        } else {
            refreshLists()
        }
    }

    private fun applyConfig() {
        clockBox.visibility = if (cfg.showClock) View.VISIBLE else View.GONE
        searchPill.visibility = if (cfg.showSearch) View.VISIBLE else View.GONE
        dots.visibility = if (cfg.showDots) View.VISIBLE else View.GONE
        dock.visibility = if (cfg.showDock) View.VISIBLE else View.GONE
        dock.background = GradientDrawable().apply {
            setColor(Color.argb(cfg.dockOpacity * 255 / 100, 255, 255, 255))
            cornerRadius = dp(30).toFloat()
        }
        drawer.setBackgroundColor(Color.argb(cfg.drawerOpacity * 255 / 100, 16, 18, 22))
        (drawerList.layoutManager as GridLayoutManager).spanCount = cfg.columns
        pager.setPageTransformer(transformer(cfg.pageEffect))
    }

    private fun transformer(effect: String): ViewPager2.PageTransformer? = when (effect) {
        "zoom" -> ViewPager2.PageTransformer { page, pos ->
            val d = abs(pos).coerceAtMost(1f)
            page.scaleX = 1f - 0.15f * d
            page.scaleY = 1f - 0.15f * d
            page.alpha = 1f - 0.5f * d
        }
        "fade" -> ViewPager2.PageTransformer { page, pos ->
            page.translationX = -page.width * pos
            page.alpha = 1f - abs(pos).coerceAtMost(1f)
        }
        "cube" -> ViewPager2.PageTransformer { page, pos ->
            page.cameraDistance = 12000f
            page.pivotX = if (pos < 0f) page.width.toFloat() else 0f
            page.pivotY = page.height * 0.5f
            page.rotationY = -60f * pos.coerceIn(-1f, 1f)
        }
        else -> null
    }

    private fun openSettings() {
        startActivity(Intent(this, SettingsActivity::class.java))
        if (drawerOpen) closeDrawer()
    }

    private fun showQuickMenu() {
        val labels = arrayOf("Launcher settings", "Wallpaper", "Always-on clock")
        AlertDialog.Builder(this).setItems(labels) { _, which ->
            when (which) {
                0 -> openSettings()
                1 -> startActivity(Intent.createChooser(Intent(Intent.ACTION_SET_WALLPAPER), "Wallpaper"))
                2 -> startActivity(Intent(this, AlwaysOnActivity::class.java))
            }
        }.show()
    }

    // ---------- Apps ----------
    private fun loadApps() {
        val shape = cfg.iconShape
        thread {
            val pm = packageManager
            val query = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
            val list = pm.queryIntentActivities(query, 0)
                .filter { it.activityInfo.packageName != packageName }
                .distinctBy { it.activityInfo.packageName }
                .map { ri ->
                    val pkg = ri.activityInfo.packageName
                    val installed = try {
                        pm.getPackageInfo(pkg, 0).firstInstallTime
                    } catch (e: Exception) {
                        0L
                    }
                    AppInfo(ri.loadLabel(pm).toString(), pkg, styleIcon(ri.loadIcon(pm), shape), installed)
                }
                .sortedBy { it.label.lowercase() }
            runOnUiThread {
                allApps = list
                refreshLists()
            }
        }
    }

    private fun refreshLists() {
        val hidden = cfg.hiddenApps
        val shown = allApps.filter { it.pkg !in hidden }
        visibleApps = when (cfg.sortOrder) {
            "newest" -> shown.sortedByDescending { it.installTime }
            "oldest" -> shown.sortedBy { it.installTime }
            else -> shown.sortedBy { it.label.lowercase() }
        }
        drawerAdapter.submit(visibleApps)
        rebuildPages()
        renderDock()
    }

    private fun shapePath(shape: String, s: Float): Path {
        val p = Path()
        when (shape) {
            "circle" -> p.addCircle(s / 2, s / 2, s / 2, Path.Direction.CW)
            "square" -> p.addRoundRect(RectF(0f, 0f, s, s), s * 0.12f, s * 0.12f, Path.Direction.CW)
            "rounded" -> p.addRoundRect(RectF(0f, 0f, s, s), s * 0.30f, s * 0.30f, Path.Direction.CW)
            else -> { // squircle (superellipse)
                val steps = 80
                for (i in 0..steps) {
                    val t = 2 * PI * i / steps
                    val c = cos(t)
                    val sn = sin(t)
                    val x = s / 2 + s / 2 * sign(c) * abs(c).pow(0.5)
                    val y = s / 2 + s / 2 * sign(sn) * abs(sn).pow(0.5)
                    if (i == 0) p.moveTo(x.toFloat(), y.toFloat()) else p.lineTo(x.toFloat(), y.toFloat())
                }
                p.close()
            }
        }
        return p
    }

    /** Same shape for every app icon. */
    private fun styleIcon(src: Drawable, shape: String): Drawable {
        val size = 192
        val s = size.toFloat()
        val content = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val c = Canvas(content)
        if (shape == "original") {
            src.setBounds(0, 0, size, size)
            src.draw(c)
            return BitmapDrawable(resources, content)
        }
        if (src is AdaptiveIconDrawable) {
            val off = (s * 0.25f).toInt() // layers are 108dp, visible area 72dp
            val r = Rect(-off, -off, size + off, size + off)
            src.background?.apply { setBounds(r); draw(c) }
            src.foreground?.apply { setBounds(r); draw(c) }
        } else {
            c.drawColor(0xFFF2F2F2.toInt())
            val inset = (s * 0.14f).toInt()
            src.setBounds(inset, inset, size - inset, size - inset)
            src.draw(c)
        }
        // smooth (anti-aliased) edges
        val out = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        paint.shader = BitmapShader(content, Shader.TileMode.CLAMP, Shader.TileMode.CLAMP)
        Canvas(out).drawPath(shapePath(shape, s), paint)
        content.recycle()
        return BitmapDrawable(resources, out)
    }

    private fun averageColor(d: Drawable): Int {
        val b = (d as? BitmapDrawable)?.bitmap ?: return Color.WHITE
        val px = Bitmap.createScaledBitmap(b, 1, 1, true).getPixel(0, 0)
        return Color.rgb(Color.red(px), Color.green(px), Color.blue(px))
    }

    // ---------- Home pages ----------
    private fun homeList(): List<AppInfo> =
        if (cfg.homeMode == "drawer") {
            val set = homeApps()
            visibleApps.filter { it.pkg in set }
        } else {
            visibleApps
        }

    private fun rebuildPages() {
        val h = pager.height
        if (h == 0) return
        val rowDp = cfg.iconSize + 22 + (if (cfg.showLabels) 4 + (cfg.labelSize * 1.4f).toInt() else 0)
        val rows = if (cfg.rows == "auto") max(3, h / dp(rowDp)) else cfg.rows.toInt()
        val pages = homeList().chunked(max(1, rows * cfg.columns))
        pagesAdapter.submit(pages)

        dots.removeAllViews()
        if (pages.size > 1) {
            pages.indices.forEach { _ ->
                dots.addView(ImageView(this).apply {
                    layoutParams = LinearLayout.LayoutParams(dp(14), dp(14))
                    scaleType = ImageView.ScaleType.CENTER
                })
            }
            updateDots(pager.currentItem)
        }
    }

    private fun updateDots(selected: Int) {
        for (i in 0 until dots.childCount) {
            (dots.getChildAt(i) as ImageView)
                .setImageResource(if (i == selected) R.drawable.dot_on else R.drawable.dot_off)
        }
    }

    private fun homeApps(): Set<String> =
        (data.getString("home_apps", "") ?: "").split(",").filter { it.isNotEmpty() }.toSet()

    private fun saveHome(s: Set<String>) {
        data.edit().putString("home_apps", s.joinToString(",")).apply()
        rebuildPages()
    }

    // ---------- Open an app ----------
    private fun launch(app: AppInfo, from: View) {
        val intent = packageManager.getLaunchIntentForPackage(app.pkg) ?: return

        // remember where the icon is, for the closing animation
        val loc = IntArray(2)
        val rl = IntArray(2)
        from.getLocationOnScreen(loc)
        root.getLocationOnScreen(rl)
        val left = loc[0] - rl[0]
        val top = loc[1] - rl[1]
        lastRect = Rect(left, top, left + from.width, top + from.height)
        lastColor = averageColor(app.icon)

        val opts = when (cfg.openAnim) {
            "zoom" -> ActivityOptions.makeScaleUpAnimation(from, 0, 0, from.width, from.height)
            "fade" -> ActivityOptions.makeCustomAnimation(this, android.R.anim.fade_in, android.R.anim.fade_out)
            else -> ActivityOptions.makeCustomAnimation(this, 0, 0)
        }
        launched = true
        startActivity(intent, opts.toBundle())
        if (cfg.openAnim != "none") {
            home.animate().scaleX(0.9f).scaleY(0.9f).alpha(0f)
                .setDuration(cfg.dur(240)).withLayer().start()
        }
        home.removeCallbacks(restoreRunnable)
        home.postDelayed(restoreRunnable, 1500)
        if (drawerOpen) closeDrawer()
    }

    // ---------- Drawer / search ----------
    private fun openDrawer() {
        if (drawerOpen) return
        drawerOpen = true
        drawer.visibility = View.VISIBLE
        drawer.translationY = drawer.height.toFloat()
        drawer.animate().translationY(0f).setDuration(cfg.dur(240))
            .setInterpolator(DecelerateInterpolator()).withLayer().start()
    }

    private fun closeDrawer() {
        if (!drawerOpen) return
        drawerOpen = false
        search.setText("")
        search.clearFocus()
        (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager)
            .hideSoftInputFromWindow(search.windowToken, 0)
        drawer.animate().translationY(drawer.height.toFloat()).setDuration(cfg.dur(200))
            .withLayer().withEndAction { drawer.visibility = View.INVISIBLE }.start()
    }

    // ---------- Dock ----------
    private fun dockPackages(): List<String> {
        val saved = data.getString("dock", null)
        if (saved == "-") return emptyList()
        if (!saved.isNullOrEmpty()) return saved.split(",")
        val intents = listOf(
            Intent(Intent.ACTION_DIAL),
            Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:")),
            Intent(Intent.ACTION_VIEW, Uri.parse("https://")),
            Intent(MediaStore.ACTION_IMAGE_CAPTURE)
        )
        return intents.mapNotNull {
            packageManager.resolveActivity(it, PackageManager.MATCH_DEFAULT_ONLY)?.activityInfo?.packageName
        }.filter { it != "android" }.distinct()
    }

    private fun saveDock(list: List<String>) {
        data.edit().putString("dock", if (list.isEmpty()) "-" else list.joinToString(",")).apply()
        renderDock()
    }

    private fun renderDock() {
        dock.removeAllViews()
        val px = dp(cfg.iconSize)
        dockPackages().mapNotNull { p -> allApps.find { it.pkg == p } }.take(cfg.dockCount).forEach { app ->
            val v = layoutInflater.inflate(R.layout.item_app, dock, false)
            v.layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            val icon = v.findViewById<ImageView>(R.id.icon)
            icon.layoutParams = icon.layoutParams.apply { width = px; height = px }
            icon.setImageDrawable(app.icon)
            v.findViewById<TextView>(R.id.label).visibility = View.GONE
            v.pressFeedback(cfg.pressEffect)
            v.setOnClickListener { launch(app, icon) }
            v.setOnLongClickListener { showMenu(app); true }
            dock.addView(v)
        }
    }

    // ---------- Long-press app menu ----------
    private fun showMenu(app: AppInfo) {
        val entries = mutableListOf<Pair<String, () -> Unit>>()
        if (!cfg.lockLayout) {
            if (app.pkg in dockPackages()) {
                entries.add("Remove from dock" to { saveDock(dockPackages() - app.pkg) })
            } else {
                entries.add("Add to dock" to {
                    saveDock((dockPackages() + app.pkg).distinct().takeLast(cfg.dockCount))
                })
            }
            if (cfg.homeMode == "drawer") {
                if (app.pkg in homeApps()) {
                    entries.add("Remove from home screen" to { saveHome(homeApps() - app.pkg) })
                } else {
                    entries.add("Add to home screen" to { saveHome(homeApps() + app.pkg) })
                }
            }
        }
        entries.add("Hide app" to {
            cfg.p.edit().putStringSet("hidden_apps", cfg.hiddenApps + app.pkg).apply()
            applyConfigIfChanged()
        })
        entries.add("App info" to {
            startActivity(
                Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${app.pkg}"))
            )
        })
        entries.add("Uninstall" to {
            startActivity(Intent(Intent.ACTION_DELETE, Uri.parse("package:${app.pkg}")))
        })

        AlertDialog.Builder(this)
            .setTitle(app.label)
            .setItems(entries.map { it.first }.toTypedArray()) { _, i -> entries[i].second() }
            .show()
    }
}
