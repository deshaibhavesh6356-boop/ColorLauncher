package com.example.colorlauncher

import android.Manifest
import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.ObjectAnimator
import android.animation.ValueAnimator
import android.app.ActivityOptions
import android.app.SearchManager
import android.app.WallpaperManager
import android.appwidget.AppWidgetHost
import android.appwidget.AppWidgetHostView
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProviderInfo
import android.content.BroadcastReceiver
import android.content.ClipData
import android.content.ClipboardManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.LauncherApps
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapShader
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PorterDuff
import android.graphics.PorterDuffColorFilter
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.RenderEffect
import android.graphics.Shader
import android.graphics.Typeface
import android.graphics.drawable.AdaptiveIconDrawable
import android.graphics.drawable.BitmapDrawable
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.Process
import android.provider.AlarmClock
import android.provider.ContactsContract
import android.provider.MediaStore
import android.provider.Settings
import android.text.Editable
import android.text.TextWatcher
import android.view.DragEvent
import android.view.GestureDetector
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.animation.DecelerateInterpolator
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.PopupWindow
import android.widget.ScrollView
import android.widget.TextClock
import android.widget.TextView
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.core.content.ContextCompat
import androidx.core.graphics.ColorUtils
import androidx.dynamicanimation.animation.DynamicAnimation
import androidx.dynamicanimation.animation.SpringAnimation
import androidx.dynamicanimation.animation.SpringForce
import androidx.preference.PreferenceManager
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import androidx.viewpager2.widget.ViewPager2
import kotlin.concurrent.thread
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.ceil
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.sign
import kotlin.math.sin
import kotlin.random.Random

class MainActivity : AppCompatActivity() {

    private class Drag(val item: Item?, val pkg: String, val fromFolder: Long)
    private class Target(val cell: CellLayout, val container: Int, val page: Int, val cx: Int, val cy: Int)

    companion object {
        private const val REQ_BIND = 41
        private const val REQ_CONFIG = 42
    }

    private lateinit var cfg: LauncherPrefs
    private lateinit var store: LayoutStore

    private lateinit var root: FrameLayout
    private lateinit var home: View
    private lateinit var clockBox: View
    private lateinit var clockTime: TextClock
    private lateinit var clockDate: TextClock
    private lateinit var glanceBox: View
    private lateinit var searchPill: TextView
    private lateinit var drawer: View
    private lateinit var search: EditText
    private lateinit var searchExtras: LinearLayout
    private lateinit var suggestRow: LinearLayout
    private lateinit var alphaIndex: LinearLayout
    private lateinit var shelf: View
    private lateinit var shelfContent: LinearLayout
    private lateinit var dockHolder: FrameLayout
    private lateinit var dockCell: CellLayout
    private lateinit var dots: LinearLayout
    private lateinit var pager: ViewPager2
    private lateinit var overlay: View
    private lateinit var drawerList: RecyclerView
    private lateinit var dragBar: View
    private lateinit var barZones: Array<TextView>
    private lateinit var editPanel: View
    private lateinit var folderOverlay: View
    private lateinit var folderBox: View
    private lateinit var folderName: EditText
    private lateinit var folderList: RecyclerView

    private lateinit var workspace: WorkspaceAdapter
    private lateinit var drawerAdapter: AppAdapter
    private lateinit var folderAdapter: AppAdapter
    private lateinit var gestures: GestureDetector
    private lateinit var awm: AppWidgetManager
    private lateinit var widgetHost: AppWidgetHost
    private lateinit var glance: Glance
    private val widgetViews = HashMap<Int, AppWidgetHostView>()
    private val glassViews = ArrayList<View>()

    private var allApps = listOf<AppInfo>()
    private var appMap = HashMap<String, AppInfo>()
    private var visibleApps = listOf<AppInfo>()
    private var homeRows = 6

    private var drawerOpen = false
    private var shelfOpen = false
    private var editMode = false
    private var folderOpen = false
    private var drawerPrivate = false
    private var openFolderId = -1L
    private var unlockedOnce: String? = null

    private var launched = false
    private var lastRect: Rect? = null
    private var lastColor = Color.WHITE

    private var appliedSignature = ""
    private var appliedIconKey = ""
    private var syncTries = 0
    private var blurAnim: ValueAnimator? = null
    private var blurLevel = 0f
    private var drawerSpring: SpringAnimation? = null
    private var shelfSpring: SpringAnimation? = null
    private var torchOn = false
    private var lastWpId = -999
    private var lastBackdropAt = 0L

    private var drag: Drag? = null
    private var edgeDir = 0
    private var pageAddedByDrag = false

    private var pendingWidget: AppWidgetProviderInfo? = null
    private var pendingWidgetId = -1

    private var sensorManager: SensorManager? = null
    private var tiltX = 0f
    private var tiltY = 0f

    private val handler = Handler(Looper.getMainLooper())

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    // ---------- permission / picker launchers ----------
    private val pickWallpaper = registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) {
            val app = applicationContext
            thread {
                val ok = WallpaperHelper.setFromUri(app, uri)
                runOnUiThread {
                    toast(if (ok) "Wallpaper set" else "Could not set wallpaper")
                    refreshBackdrop(true)
                }
            }
        }
    }
    private val reqCalendar = registerForActivityResult(ActivityResultContracts.RequestPermission()) {
        if (::glance.isInitialized) glance.refreshNow()
    }
    private val reqContacts = registerForActivityResult(ActivityResultContracts.RequestPermission()) {
        if (::search.isInitialized) updateExtras(search.text.toString().trim())
    }

    private val pkgReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            loadApps()
        }
    }

    // If a launch silently failed, bring the home screen back
    private val restoreRunnable = Runnable {
        if (launched && hasWindowFocus()) {
            launched = false
            resetHome()
        }
    }

    private val badgeRunnable = Runnable {
        renderDock()
        workspace.notifyDataSetChanged()
        drawerAdapter.notifyDataSetChanged()
    }

    private val edgeRunnable = Runnable { edgeSwitch() }

    private val tiltListener = object : SensorEventListener {
        override fun onSensorChanged(e: SensorEvent) {
            val x = (-e.values[0] / 9.8f).coerceIn(-1f, 1f)
            val y = (e.values[1] / 9.8f).coerceIn(-1f, 1f)
            tiltX += (x - tiltX) * 0.1f
            tiltY += (y - tiltY) * 0.1f
            clockBox.translationX = tiltX * dp(7)
            clockBox.translationY = -tiltY * dp(5)
            glanceBox.translationX = tiltX * dp(4)
            dockHolder.translationX = -tiltX * dp(5)
        }

        override fun onAccuracyChanged(s: Sensor?, accuracy: Int) {}
    }

    // =====================================================================
    // Lifecycle
    // =====================================================================
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        PreferenceManager.setDefaultValues(this, R.xml.preferences, false)
        cfg = LauncherPrefs(this)
        store = LayoutStore(this)
        setContentView(R.layout.activity_main)

        root = findViewById(R.id.root)
        home = findViewById(R.id.home)
        clockBox = findViewById(R.id.clockBox)
        clockTime = findViewById(R.id.clockTime)
        clockDate = findViewById(R.id.clockDate)
        glanceBox = findViewById(R.id.glanceBox)
        searchPill = findViewById(R.id.searchPill)
        drawer = findViewById(R.id.drawer)
        search = findViewById(R.id.search)
        searchExtras = findViewById(R.id.searchExtras)
        suggestRow = findViewById(R.id.suggestRow)
        alphaIndex = findViewById(R.id.alphaIndex)
        shelf = findViewById(R.id.shelf)
        shelfContent = findViewById(R.id.shelfContent)
        dockHolder = findViewById(R.id.dockHolder)
        dots = findViewById(R.id.dots)
        pager = findViewById(R.id.pager)
        overlay = findViewById(R.id.overlay)
        drawerList = findViewById(R.id.recycler)
        dragBar = findViewById(R.id.dragBar)
        editPanel = findViewById(R.id.editPanel)
        folderOverlay = findViewById(R.id.folderOverlay)
        folderBox = findViewById(R.id.folderBox)
        folderName = findViewById(R.id.folderName)
        folderList = findViewById(R.id.folderList)
        barZones = arrayOf(
            findViewById<TextView>(R.id.tInfo),
            findViewById<TextView>(R.id.tRemove),
            findViewById<TextView>(R.id.tUninstall)
        )

        awm = AppWidgetManager.getInstance(this)
        widgetHost = AppWidgetHost(this, 1024)

        glance = Glance(
            this, cfg,
            findViewById(R.id.glanceRow), findViewById(R.id.cardWeather),
            findViewById(R.id.cardBattery), findViewById(R.id.cardCalendar),
            findViewById(R.id.cardMusic), findViewById(R.id.musicArt),
            findViewById(R.id.musicTitle), findViewById(R.id.musicArtist),
            findViewById(R.id.musicPrev), findViewById(R.id.musicPlay), findViewById(R.id.musicNext)
        ) { reqCalendar.launch(Manifest.permission.READ_CALENDAR) }

        // dock
        dockCell = CellLayout(this)
        dockCell.setPadding(dp(4), dp(4), dp(4), dp(4))
        dockHolder.addView(dockCell, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(88)))
        dockCell.setOnLongClickListener { enterEditMode(); true }

        // home pages
        workspace = WorkspaceAdapter { page, cell -> populate(cell, page) }
        pager.adapter = workspace
        pager.offscreenPageLimit = 2
        pager.addOnLayoutChangeListener { _, _, t, _, b, _, ot, _, ob ->
            if (b - t != ob - ot) onPagerResized()
        }
        pager.registerOnPageChangeCallback(object : ViewPager2.OnPageChangeCallback() {
            override fun onPageSelected(position: Int) {
                updateDots(position)
                pager.performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK)
            }

            override fun onPageScrolled(position: Int, positionOffset: Float, positionOffsetPixels: Int) {
                if (cfg.parallax && store.pageCount > 1) {
                    try {
                        WallpaperManager.getInstance(this@MainActivity).setWallpaperOffsets(
                            pager.windowToken, (position + positionOffset) / (store.pageCount - 1), 0.5f
                        )
                    } catch (e: Exception) {
                        // ignore
                    }
                }
            }
        })

        // drawer
        drawerAdapter = AppAdapter(cfg, ::launch) { app, v -> startAppDrag(app, v, -1L) }
        drawerList.layoutManager = GridLayoutManager(this, cfg.columns)
        drawerList.adapter = drawerAdapter
        searchPill.setOnClickListener { openDrawer() }
        findViewById<View>(R.id.gear).setOnClickListener { openSettings() }
        findViewById<View>(R.id.lockBtn).setOnClickListener {
            if (drawerPrivate) {
                drawerPrivate = false
                refreshLists()
            } else {
                authenticate("Private apps") {
                    drawerPrivate = true
                    refreshLists()
                    toast("Showing your hidden apps")
                }
            }
        }
        search.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) {
                refreshDrawerResults()
            }
        })
        search.setOnEditorActionListener { _, id, _ ->
            if (id == EditorInfo.IME_ACTION_GO) drawerAdapter.first()?.let { launch(it, search) }
            true
        }

        // A-Z fast scroll
        val letters = "ABCDEFGHIJKLMNOPQRSTUVWXYZ#"
        for (ch in letters) {
            val tv = TextView(this)
            tv.text = ch.toString()
            tv.textSize = 9f
            tv.setTextColor(0xB3FFFFFF.toInt())
            tv.gravity = Gravity.CENTER
            tv.layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(15))
            alphaIndex.addView(tv)
        }
        alphaIndex.setOnTouchListener { v, e ->
            val frac = (e.y / v.height).coerceIn(0f, 0.999f)
            val ch = letters[(frac * letters.length).toInt()]
            val pos = drawerAdapter.indexOfLetter(ch)
            if (pos >= 0) (drawerList.layoutManager as GridLayoutManager).scrollToPositionWithOffset(pos, 0)
            true
        }

        // folder popup
        folderAdapter = AppAdapter(cfg, ::launch) { app, v -> startAppDrag(app, v, openFolderId) }
        folderList.layoutManager = GridLayoutManager(this, 4)
        folderList.adapter = folderAdapter
        folderOverlay.setOnClickListener { closeFolder() }
        folderName.setOnEditorActionListener { _, id, _ ->
            if (id == EditorInfo.IME_ACTION_DONE) {
                saveFolderName()
                hideKeyboard(folderName)
            }
            true
        }

        // edit panel (long-press on empty home screen)
        findViewById<View>(R.id.eWallpaper).setOnClickListener { showWallpaperDialog() }
        findViewById<View>(R.id.eWidgets).setOnClickListener { showWidgetPicker() }
        findViewById<View>(R.id.eEffects).setOnClickListener { showThemesDialog() }
        findViewById<View>(R.id.ePages).setOnClickListener { showPagesDialog() }
        findViewById<View>(R.id.eTidy).setOnClickListener { showTidyDialog() }
        findViewById<View>(R.id.eSettings).setOnClickListener {
            exitEditMode()
            openSettings()
        }

        val quick = View.OnLongClickListener { enterEditMode(); true }
        clockBox.setOnLongClickListener(quick)
        searchPill.setOnLongClickListener(quick)
        dots.setOnLongClickListener(quick)

        // drag and drop
        root.setOnDragListener { _, e -> handleDrag(e) }

        // swipe gestures
        gestures = GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onDown(e: MotionEvent) = true

            override fun onDoubleTap(e: MotionEvent): Boolean {
                handleDoubleTap(e.rawX, e.rawY)
                return false
            }

            override fun onFling(e1: MotionEvent?, e2: MotionEvent, vx: Float, vy: Float): Boolean {
                if (e1 == null) return false
                val dy = e2.y - e1.y
                val dx = e2.x - e1.x
                if (shelfOpen) {
                    if (dx < -dp(80) && abs(dx) > abs(dy)) {
                        closeShelf()
                        return true
                    }
                    return false
                }
                if (cfg.shelf && dx > dp(90) && abs(dx) > abs(dy) * 1.5f && abs(vx) > 400 && pager.currentItem == 0) {
                    openShelf()
                    return true
                }
                if (abs(dy) < dp(60) || abs(dy) < abs(dx) * 1.5f || abs(vy) < 400) return false
                if (dy < 0) {
                    if (cfg.swipeUp) {
                        openDrawer()
                        return true
                    }
                } else {
                    when (cfg.swipeDown) {
                        "notifications" -> expandNotifications()
                        "search" -> openDrawer()
                    }
                    return true
                }
                return false
            }
        })

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                when {
                    editMode -> exitEditMode()
                    folderOpen -> closeFolder()
                    shelfOpen -> closeShelf()
                    drawerOpen -> closeDrawer()
                }
            }
        })

        val filter = IntentFilter().apply {
            addAction(Intent.ACTION_PACKAGE_ADDED)
            addAction(Intent.ACTION_PACKAGE_REMOVED)
            addAction(Intent.ACTION_PACKAGE_REPLACED)
            addDataScheme("package")
        }
        ContextCompat.registerReceiver(this, pkgReceiver, filter, ContextCompat.RECEIVER_EXPORTED)

        applyConfigIfChanged()

        if (!cfg.p.getBoolean("onboarded", false)) {
            handler.postDelayed({ showWelcome() }, 800)
        }
    }

    override fun onStart() {
        super.onStart()
        try {
            widgetHost.startListening()
        } catch (e: Exception) {
            // ignore
        }
        Badges.listener = {
            handler.removeCallbacks(badgeRunnable)
            handler.postDelayed(badgeRunnable, 500)
        }
    }

    override fun onStop() {
        try {
            widgetHost.stopListening()
        } catch (e: Exception) {
            // ignore
        }
        Badges.listener = null
        super.onStop()
    }

    override fun onDestroy() {
        unregisterReceiver(pkgReceiver)
        super.onDestroy()
    }

    override fun dispatchTouchEvent(ev: MotionEvent): Boolean {
        if (!drawerOpen && !editMode && !folderOpen) gestures.onTouchEvent(ev)
        return super.dispatchTouchEvent(ev)
    }

    // Home button pressed while already on the launcher
    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        when {
            editMode -> exitEditMode()
            folderOpen -> closeFolder()
            shelfOpen -> closeShelf()
            drawerOpen -> closeDrawer()
            else -> pager.setCurrentItem(0, true)
        }
    }

    override fun onResume() {
        super.onResume()
        applyConfigIfChanged()
        refreshBlur()
        refreshBackdrop(false)
        if (cfg.showGlance) glance.start()
        updateTilt()
        home.removeCallbacks(restoreRunnable)
        if (!launched) {
            resetHome()
            return
        }
        launched = false
        if (cfg.closeAnim == "none") {
            resetHome()
            return
        }
        // Closing animation: home zooms back in, and a colour tile shrinks into the icon
        home.animate().cancel()
        home.scaleX = 1.08f
        home.scaleY = 1.08f
        home.alpha = 0f
        home.animate().scaleX(1f).scaleY(1f).alpha(1f)
            .setDuration(cfg.dur(320)).setInterpolator(DecelerateInterpolator()).withLayer().start()
        if (cfg.closeAnim == "shrink") playShrink()
    }

    override fun onPause() {
        glance.stop()
        sensorManager?.unregisterListener(tiltListener)
        super.onPause()
    }

    private fun resetHome() {
        home.animate().cancel()
        home.scaleX = 1f
        home.scaleY = 1f
        home.alpha = 1f
    }

    private fun updateTilt() {
        sensorManager?.unregisterListener(tiltListener)
        if (cfg.tilt) {
            val sm = getSystemService(Context.SENSOR_SERVICE) as SensorManager
            sensorManager = sm
            val s = sm.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)
            if (s != null) sm.registerListener(tiltListener, s, SensorManager.SENSOR_DELAY_UI)
        } else {
            tiltX = 0f
            tiltY = 0f
            clockBox.translationX = 0f
            clockBox.translationY = 0f
            glanceBox.translationX = 0f
            dockHolder.translationX = 0f
        }
    }

    // =====================================================================
    // Settings, style and blur
    // =====================================================================
    private fun iconKey(): String = cfg.iconShape + "|" + cfg.iconTheme + "|" + cfg.iconPack

    private fun applyConfigIfChanged() {
        var force = false
        if (cfg.p.getBoolean("reset_layout_flag", false)) {
            cfg.p.edit().remove("reset_layout_flag").apply()
            store.reset()
            widgetViews.clear()
            force = true
        }
        if (cfg.p.getBoolean("restore_flag", false)) {
            cfg.p.edit().remove("restore_flag").apply()
            store = LayoutStore(this)
            widgetViews.clear()
            force = true
        }
        val sig = cfg.signature()
        if (sig == appliedSignature && !force) return
        appliedSignature = sig
        applyConfig()
        if (iconKey() != appliedIconKey) {
            appliedIconKey = iconKey()
            loadApps()
        } else {
            refreshLists()
            syncApps()
        }
    }

    private fun applyConfig() {
        val white = cfg.textColor == "white"
        val tc = if (white) Color.WHITE else Color.BLACK
        clockBox.visibility = if (cfg.showClock) View.VISIBLE else View.GONE
        clockTime.setTextColor(tc)
        clockDate.setTextColor(ColorUtils.setAlphaComponent(tc, 204))
        clockDate.typeface = LauncherPrefs.typeface(if (cfg.fontStyle == "default") "light" else cfg.fontStyle)
        if (white) {
            clockTime.setShadowLayer(8f, 0f, 2f, 0x66000000)
            clockDate.setShadowLayer(4f, 0f, 1f, 0x66000000)
        } else {
            clockTime.setShadowLayer(0f, 0f, 0f, 0)
            clockDate.setShadowLayer(0f, 0f, 0f, 0)
        }
        when (cfg.clockStyle) {
            "bold" -> {
                clockTime.typeface = Typeface.create("sans-serif-black", Typeface.NORMAL)
                clockTime.textSize = 56f
                clockTime.format12Hour = "hh:mm"
                clockTime.format24Hour = "HH:mm"
                clockTime.setLineSpacing(0f, 1f)
            }
            "stacked" -> {
                clockTime.typeface = Typeface.create("sans-serif-light", Typeface.NORMAL)
                clockTime.textSize = 72f
                clockTime.format12Hour = "hh\nmm"
                clockTime.format24Hour = "HH\nmm"
                clockTime.setLineSpacing(0f, 0.82f)
            }
            else -> {
                clockTime.typeface = Typeface.create("sans-serif-thin", Typeface.NORMAL)
                clockTime.textSize = 64f
                clockTime.format12Hour = "hh:mm"
                clockTime.format24Hour = "HH:mm"
                clockTime.setLineSpacing(0f, 1f)
            }
        }
        glanceBox.visibility = if (cfg.showGlance) View.VISIBLE else View.GONE
        if (cfg.showGlance) glance.start() else glance.stop()
        searchPill.visibility = if (cfg.showSearch) View.VISIBLE else View.GONE
        dots.visibility = if (cfg.showDots) View.VISIBLE else View.GONE
        dockHolder.visibility = when {
            !cfg.showDock -> View.GONE
            editMode -> View.INVISIBLE
            else -> View.VISIBLE
        }
        applyStyle()
        (drawerList.layoutManager as GridLayoutManager).spanCount = cfg.columns
        pager.setPageTransformer(transformer(cfg.pageEffect))
        Backdrop.enabled = cfg.frosted
        updateTilt()
    }

    private fun glass(v: View, radiusDp: Float, strength: Int) {
        v.background = UiStyle.panel(this, cfg.uiStyle, radiusDp, strength, v)
        glassViews.add(v)
    }

    /** Dock, search bar, cards, panels and popups in the chosen style (liquid glass / Material You / classic). */
    private fun applyStyle() {
        glassViews.clear()
        val st = cfg.uiStyle
        val s = cfg.glassStrength
        glass(dockHolder, 32f, if (st == "classic") cfg.dockOpacity else s)
        glass(searchPill, 18f, s)
        glass(search, 24f, s)
        glass(findViewById(R.id.gear), 24f, s)
        glass(findViewById(R.id.lockBtn), 24f, s)
        glass(findViewById(R.id.cardWeather), 22f, s)
        glass(findViewById(R.id.cardBattery), 22f, s)
        glass(findViewById(R.id.cardCalendar), 22f, s)
        glass(findViewById(R.id.cardMusic), 26f, s)
        glass(dragBar, 24f, max(s, 40))
        glass(editPanel, 28f, max(s, 40))
        glass(folderBox, 34f, max(s, 45))
        glass(suggestRow, 24f, s)
        val blurSupported = cfg.blur && Build.VERSION.SDK_INT >= 31
        val drawerPct = if (st == "glass" && blurSupported) cfg.drawerOpacity * 45 / 100 else cfg.drawerOpacity
        drawer.setBackgroundColor(Color.argb(drawerPct * 255 / 100, 16, 18, 22))
        shelf.setBackgroundColor(Color.argb(if (blurSupported) 120 else 238, 14, 16, 22))
    }

    private fun invalidateGlass() {
        for (v in glassViews) v.invalidate()
    }

    /** Builds (or refreshes) the blurred wallpaper that glass panels show behind themselves. */
    private fun refreshBackdrop(force: Boolean) {
        Backdrop.enabled = cfg.frosted
        if (!cfg.frosted) {
            invalidateGlass()
            return
        }
        val wm = WallpaperManager.getInstance(this)
        val id = try {
            wm.getWallpaperId(WallpaperManager.FLAG_SYSTEM)
        } catch (e: Exception) {
            -1
        }
        val savedId = getSharedPreferences("backdrop", MODE_PRIVATE).getInt("bd_id", -2)
        val f = Backdrop.savedFile(this)
        if (f.exists() && id != savedId) f.delete() // wallpaper was changed outside this launcher
        val now = System.currentTimeMillis()
        if (!force && id == lastWpId && now - lastBackdropAt < 120_000L) return
        lastWpId = id
        lastBackdropAt = now
        val dm = resources.displayMetrics
        val app = applicationContext
        thread {
            Backdrop.rebuild(app, dm.widthPixels, dm.heightPixels)
            runOnUiThread { invalidateGlass() }
        }
    }

    /** Blurs the home screen (and the wallpaper, if the phone allows) while the drawer, shelf or a folder is open. */
    private fun refreshBlur() {
        val target = if (cfg.blur && (drawerOpen || folderOpen || shelfOpen)) 1f else 0f
        if (target == blurLevel) return
        blurAnim?.cancel()
        val a = ValueAnimator.ofFloat(blurLevel, target)
        a.duration = cfg.dur(260)
        a.addUpdateListener { applyBlurLevel(it.animatedValue as Float) }
        blurAnim = a
        a.start()
    }

    private fun applyBlurLevel(level: Float) {
        blurLevel = level
        if (Build.VERSION.SDK_INT < 31) return
        val r = 24f * level
        home.setRenderEffect(
            if (r > 0.5f) RenderEffect.createBlurEffect(r, r, Shader.TileMode.CLAMP) else null
        )
        try {
            window.setBackgroundBlurRadius((60 * level).toInt())
        } catch (e: Exception) {
            // this phone does not allow window blur
        }
    }

    private fun transformer(effect: String): ViewPager2.PageTransformer? = when (effect) {
        "zoom" -> ViewPager2.PageTransformer { page, pos ->
            val d = abs(pos).coerceAtMost(1f)
            page.scaleX = 1f - 0.15f * d
            page.scaleY = 1f - 0.15f * d
            page.alpha = 1f - 0.5f * d
        }
        "fade" -> ViewPager2.PageTransformer { page, pos ->
            page.translationX = -page.width * pos
            page.alpha = 1f - abs(pos).coerceAtMost(1f)
        }
        "cube" -> ViewPager2.PageTransformer { page, pos ->
            page.cameraDistance = 12000f
            page.pivotX = if (pos < 0f) page.width.toFloat() else 0f
            page.pivotY = page.height * 0.5f
            page.rotationY = -60f * pos.coerceIn(-1f, 1f)
        }
        else -> ViewPager2.PageTransformer { page, _ ->
            page.scaleX = 1f
            page.scaleY = 1f
            page.alpha = 1f
            page.rotationY = 0f
            page.translationX = 0f
        }
    }

    private fun openSettings() {
        startActivity(Intent(this, SettingsActivity::class.java))
        if (drawerOpen) closeDrawer()
        if (shelfOpen) closeShelf()
    }

    private fun expandNotifications() {
        try {
            val sb = getSystemService("statusbar") ?: return
            sb.javaClass.getMethod("expandNotificationsPanel").invoke(sb)
        } catch (e: Exception) {
            // not supported on this phone
        }
    }

    private fun showWelcome() {
        if (isFinishing) return
        cfg.p.edit().putBoolean("onboarded", true).apply()
        val names = Presets.names + "Keep the defaults"
        AlertDialog.Builder(this)
            .setTitle("Welcome to Color Launcher")
            .setMessage("Pick a look to start with. You can change everything later in Settings (long-press an empty spot on the home screen).")
            .setItems(names) { _, i ->
                if (i < Presets.names.size) {
                    Presets.apply(cfg.p, i)
                    applyConfigIfChanged()
                }
            }
            .show()
    }

    private fun showThemesDialog() {
        val names = arrayOf("Theme presets", "Page transition effect")
        AlertDialog.Builder(this).setItems(names) { _, w ->
            if (w == 0) {
                AlertDialog.Builder(this).setTitle("Theme presets").setItems(Presets.names) { _, i ->
                    Presets.apply(cfg.p, i)
                    applyConfigIfChanged()
                }.show()
            } else {
                showEffectDialog()
            }
        }.show()
    }

    private fun showWallpaperDialog() {
        val names = arrayOf("Choose from gallery (best for frosted glass)", "System wallpaper picker")
        AlertDialog.Builder(this).setTitle("Wallpaper").setItems(names) { _, w ->
            exitEditMode()
            if (w == 0) {
                pickWallpaper.launch("image/*")
            } else {
                startActivity(Intent.createChooser(Intent(Intent.ACTION_SET_WALLPAPER), "Wallpaper"))
            }
        }.show()
    }

    // =====================================================================
    // Loading apps and keeping the layout in sync
    // =====================================================================
    private fun loadApps() {
        val shape = cfg.iconShape
        val themed = cfg.iconTheme == "themed"
        val packName = cfg.iconPack
        thread {
            val pm = packageManager
            val pack = if (packName != "none") IconPacks.load(this, packName) else null
            val query = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
            val list = pm.queryIntentActivities(query, 0)
                .filter { it.activityInfo.packageName != packageName }
                .distinctBy { it.activityInfo.packageName }
                .map { ri ->
                    val pkg = ri.activityInfo.packageName
                    val installed = try {
                        pm.getPackageInfo(pkg, 0).firstInstallTime
                    } catch (e: Exception) {
                        0L
                    }
                    val packIcon = if (pack != null) IconPacks.icon(pack, ComponentName(pkg, ri.activityInfo.name)) else null
                    AppInfo(
                        ri.loadLabel(pm).toString(), pkg,
                        styleIcon(ri.loadIcon(pm), shape, themed, packIcon), installed
                    )
                }
                .sortedBy { it.label.lowercase() }
            runOnUiThread {
                allApps = list
                appMap = HashMap(list.associateBy { it.pkg })
                refreshLists()
                syncApps()
            }
        }
    }

    private fun drawerSource(): List<AppInfo> =
        if (drawerPrivate) allApps.filter { it.pkg in cfg.hiddenApps } else visibleApps

    /** Apps shown in the drawer: hidden ones removed, sorted. */
    private fun refreshLists() {
        val hidden = cfg.hiddenApps
        val shown = allApps.filter { it.pkg !in hidden }
        visibleApps = when (cfg.sortOrder) {
            "newest" -> shown.sortedByDescending { it.installTime }
            "oldest" -> shown.sortedBy { it.installTime }
            else -> shown.sortedBy { it.label.lowercase() }
        }
        refreshDrawerResults()
    }

    private fun recomputeGrid() {
        val h = pager.height
        homeRows = if (cfg.rows != "auto") {
            cfg.rows.toInt()
        } else if (h == 0) {
            6
        } else {
            val rowDp = cfg.iconSize + 26 + (if (cfg.showLabels) (cfg.labelSize * 1.4f).toInt() else 0)
            max(3, h / dp(rowDp))
        }
    }

    private fun onPagerResized() {
        recomputeGrid()
        if (store.initialized && allApps.isNotEmpty()) {
            normalize()
            store.save()
            renderAll()
        } else {
            syncApps()
        }
    }

    private fun defaultDockPackages(): List<String> {
        val intents = listOf(
            Intent(Intent.ACTION_DIAL),
            Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:")),
            Intent(Intent.ACTION_VIEW, Uri.parse("https://")),
            Intent(MediaStore.ACTION_IMAGE_CAPTURE)
        )
        return intents.mapNotNull {
            packageManager.resolveActivity(it, PackageManager.MATCH_DEFAULT_ONLY)?.activityInfo?.packageName
        }.filter { it != "android" }.distinct()
    }

    private fun syncApps() {
        if (allApps.isEmpty()) return
        if (pager.height == 0 && syncTries < 20) {
            syncTries++
            pager.post { syncApps() }
            return
        }
        syncTries = 0
        recomputeGrid()
        val installed = allApps.map { it.pkg }.toSet()
        if (!store.initialized) {
            populateInitial()
        } else {
            store.removeMissing(installed)
            if (cfg.homeMode == "standard" && cfg.autoAdd) {
                val hidden = cfg.hiddenApps
                for (a in allApps) {
                    if (a.pkg !in store.knownPkgs && a.pkg !in hidden) addToHome(a.pkg)
                }
            }
        }
        store.knownPkgs = installed.toMutableSet()
        normalize()
        store.save()
        renderAll()
    }

    private fun populateInitial() {
        val dockPkgs = defaultDockPackages().filter { appMap.containsKey(it) }.take(cfg.dockCount)
        dockPkgs.forEachIndexed { i, p ->
            store.items.add(Item(store.newId(), APP, DOCK, 0, i, 0, pkg = p))
        }
        if (cfg.homeMode == "standard") {
            val hidden = cfg.hiddenApps
            allApps.filter { it.pkg !in dockPkgs && it.pkg !in hidden }.forEach { addToHome(it.pkg) }
        }
        store.initialized = true
    }

    private fun addToHome(pkg: String) {
        var spot = store.findFree(0, 1, 1, cfg.columns, homeRows, -1L)
        if (spot == null) {
            store.pageCount++
            spot = intArrayOf(store.pageCount - 1, 0, 0)
        }
        store.items.add(Item(store.newId(), APP, HOME, spot[0], spot[1], spot[2], pkg = pkg))
    }

    /** Make sure everything fits the current grid. */
    private fun normalize() {
        val cols = cfg.columns
        val rows = homeRows
        store.cleanFolders()
        // widgets that no longer exist (for example after a restore on another phone)
        store.items.removeAll { it.type == WIDGET && awm.getAppWidgetInfo(it.widgetId) == null }
        for (item in store.items.toList()) {
            if (item.container == DOCK) {
                if (item.x >= cfg.dockCount || item.type == WIDGET) relocate(item, cols, rows)
            } else {
                if (item.type == WIDGET) {
                    item.spanX = min(item.spanX, cols)
                    item.spanY = min(item.spanY, rows)
                }
                if (item.x + item.spanX > cols || item.y + item.spanY > rows || item.page < 0) {
                    relocate(item, cols, rows)
                }
            }
        }
        val maxPage = store.items.filter { it.container == HOME }.maxOfOrNull { it.page } ?: 0
        if (store.pageCount < maxPage + 1) store.pageCount = maxPage + 1
    }

    private fun relocate(item: Item, cols: Int, rows: Int) {
        item.container = HOME
        var spot = store.findFree(0, item.spanX, item.spanY, cols, rows, item.id)
        if (spot == null) {
            store.pageCount++
            spot = intArrayOf(store.pageCount - 1, 0, 0)
        }
        item.page = spot[0]
        item.x = spot[1]
        item.y = spot[2]
    }

    // =====================================================================
    // Icons
    // =====================================================================
    private fun shapePath(shape: String, s: Float): Path {
        val p = Path()
        when (shape) {
            "circle" -> p.addCircle(s / 2, s / 2, s / 2, Path.Direction.CW)
            "square" -> p.addRoundRect(RectF(0f, 0f, s, s), s * 0.12f, s * 0.12f, Path.Direction.CW)
            "rounded" -> p.addRoundRect(RectF(0f, 0f, s, s), s * 0.30f, s * 0.30f, Path.Direction.CW)
            else -> { // squircle (superellipse)
                val steps = 80
                for (i in 0..steps) {
                    val t = 2 * PI * i / steps
                    val c = cos(t)
                    val sn = sin(t)
                    val x = s / 2 + s / 2 * sign(c) * abs(c).pow(0.5)
                    val y = s / 2 + s / 2 * sign(sn) * abs(sn).pow(0.5)
                    if (i == 0) p.moveTo(x.toFloat(), y.toFloat()) else p.lineTo(x.toFloat(), y.toFloat())
                }
                p.close()
            }
        }
        return p
    }

    /** Same shape for every app icon (or an icon pack's own artwork). */
    private fun styleIcon(src: Drawable, shape: String, themed: Boolean, packIcon: Drawable?): Drawable {
        val size = 192
        val s = size.toFloat()
        val content = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val c = Canvas(content)
        if (packIcon != null) {
            packIcon.setBounds(0, 0, size, size)
            packIcon.draw(c)
            return BitmapDrawable(resources, content)
        }
        if (shape == "original") {
            src.setBounds(0, 0, size, size)
            src.draw(c)
            return BitmapDrawable(resources, content)
        }
        if (src is AdaptiveIconDrawable) {
            val off = (s * 0.25f).toInt() // layers are 108dp, visible area 72dp
            val r = Rect(-off, -off, size + off, size + off)
            val mono: Drawable? = if (themed && Build.VERSION.SDK_INT >= 33) src.monochrome else null
            if (mono != null) {
                // Material You themed icon: tinted symbol on a wallpaper-colour tile
                val dark = UiStyle.isDark(this)
                val tile = UiStyle.sys(
                    this,
                    if (dark) android.R.color.system_accent1_800 else android.R.color.system_accent1_100,
                    if (dark) 0xFF3A3F4B.toInt() else 0xFFE3E6F0.toInt()
                )
                val ink = UiStyle.sys(
                    this,
                    if (dark) android.R.color.system_accent1_100 else android.R.color.system_accent1_800,
                    if (dark) 0xFFE3E6F0.toInt() else 0xFF3A3F4B.toInt()
                )
                c.drawColor(tile)
                mono.setColorFilter(PorterDuffColorFilter(ink, PorterDuff.Mode.SRC_IN))
                mono.setBounds(r.left, r.top, r.right, r.bottom)
                mono.draw(c)
            } else {
                src.background?.apply { setBounds(r); draw(c) }
                src.foreground?.apply { setBounds(r); draw(c) }
            }
        } else {
            c.drawColor(0xFFF2F2F2.toInt())
            val inset = (s * 0.14f).toInt()
            src.setBounds(inset, inset, size - inset, size - inset)
            src.draw(c)
        }
        val out = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        paint.shader = BitmapShader(content, Shader.TileMode.CLAMP, Shader.TileMode.CLAMP)
        Canvas(out).drawPath(shapePath(shape, s), paint)
        content.recycle()
        return BitmapDrawable(resources, out)
    }

    private fun averageColor(d: Drawable): Int {
        val b = (d as? BitmapDrawable)?.bitmap ?: return Color.WHITE
        val px = Bitmap.createScaledBitmap(b, 1, 1, true).getPixel(0, 0)
        return Color.rgb(Color.red(px), Color.green(px), Color.blue(px))
    }

    // =====================================================================
    // Drawing the home screen
    // =====================================================================
    private fun renderAll() {
        workspace.count = max(1, store.pageCount)
        workspace.notifyDataSetChanged()
        if (pager.currentItem >= workspace.count) pager.setCurrentItem(workspace.count - 1, false)
        rebuildDots()
        renderDock()
        try {
            WallpaperManager.getInstance(this).setWallpaperOffsetSteps(1f / max(1, store.pageCount - 1), 1f)
        } catch (e: Exception) {
            // ignore
        }
    }

    private fun cancelWiggles(cell: CellLayout) {
        for (i in 0 until cell.childCount) {
            val v = cell.getChildAt(i)
            (v.tag as? Animator)?.cancel()
            v.rotation = 0f
        }
    }

    private fun populate(cell: CellLayout, page: Int) {
        cell.cols = cfg.columns
        cell.rows = homeRows
        cancelWiggles(cell)
        cell.removeAllViews()
        cell.setPadding(dp(4), dp(4), dp(4), dp(4))
        for (item in store.items) {
            if (item.container != HOME || item.page != page) continue
            val v = if (item.type == WIDGET) widgetView(item) else createItemView(item, false)
            if (v != null) cell.addView(v, CellLayout.LP(item.x, item.y, item.spanX, item.spanY))
        }
        cell.setOnClickListener { if (editMode) exitEditMode() }
        cell.setOnLongClickListener { enterEditMode(); true }
    }

    private fun renderDock() {
        dockCell.cols = cfg.dockCount
        dockCell.rows = 1
        cancelWiggles(dockCell)
        dockCell.removeAllViews()
        for (item in store.items) {
            if (item.container != DOCK || item.x >= cfg.dockCount) continue
            val v = createItemView(item, true)
            if (v != null) dockCell.addView(v, CellLayout.LP(item.x, 0, 1, 1))
        }
    }

    private fun rebuildDots() {
        dots.removeAllViews()
        if (store.pageCount > 1) {
            for (i in 0 until store.pageCount) {
                dots.addView(ImageView(this).apply {
                    layoutParams = LinearLayout.LayoutParams(dp(14), dp(14))
                    scaleType = ImageView.ScaleType.CENTER
                })
            }
            updateDots(pager.currentItem)
        }
    }

    private fun updateDots(selected: Int) {
        for (i in 0 until dots.childCount) {
            (dots.getChildAt(i) as ImageView)
                .setImageResource(if (i == selected) R.drawable.dot_on else R.drawable.dot_off)
        }
    }

    private fun styleLabel(label: TextView, hide: Boolean) {
        label.visibility = if (hide || !cfg.showLabels) View.GONE else View.VISIBLE
        label.textSize = cfg.labelSize.toFloat()
        label.typeface = LauncherPrefs.typeface(cfg.fontStyle)
        if (cfg.textColor == "white") {
            label.setTextColor(Color.WHITE)
            label.setShadowLayer(4f, 0f, 1f, 0x80000000.toInt())
        } else {
            label.setTextColor(Color.BLACK)
            label.setShadowLayer(0f, 0f, 0f, 0)
        }
    }

    private fun startWiggle(v: View) {
        val a = ObjectAnimator.ofFloat(v, View.ROTATION, -1.8f, 1.8f)
        a.duration = (110 + Random.nextInt(40)).toLong()
        a.repeatCount = ValueAnimator.INFINITE
        a.repeatMode = ValueAnimator.REVERSE
        a.startDelay = Random.nextInt(80).toLong()
        v.tag = a
        a.start()
    }

    private fun createItemView(item: Item, inDock: Boolean): View? {
        val v = layoutInflater.inflate(R.layout.item_app, null, false)
        val icon = v.findViewById<ImageView>(R.id.icon)
        val label = v.findViewById<TextView>(R.id.label)
        val badge = v.findViewById<View>(R.id.badge)
        val px = dp(cfg.iconSize)
        icon.layoutParams = icon.layoutParams.apply {
            width = px
            height = px
        }
        when (item.type) {
            APP -> {
                if (item.pkg in cfg.hiddenApps) return null
                val app = appMap[item.pkg] ?: return null
                icon.setImageDrawable(app.icon)
                label.text = app.label
                badge.visibility = if (cfg.badges && Badges.count(app.pkg) > 0) View.VISIBLE else View.GONE
                v.setOnClickListener { launch(app, icon) }
            }
            FOLDER -> {
                val bitmaps = item.children.mapNotNull { (appMap[it]?.icon as? BitmapDrawable)?.bitmap }
                icon.setImageDrawable(FolderDrawable(bitmaps))
                label.text = if (item.title.isEmpty()) "Folder" else item.title
                val dot = cfg.badges && item.children.any { Badges.count(it) > 0 }
                badge.visibility = if (dot) View.VISIBLE else View.GONE
                v.setOnClickListener { openFolder(item, icon) }
            }
            else -> return null
        }
        styleLabel(label, inDock)
        v.pressFeedback(cfg.pressEffect)
        v.setOnLongClickListener { startItemDrag(item, v); true }
        if (editMode) startWiggle(v)
        return v
    }

    // =====================================================================
    // Widgets
    // =====================================================================
    private fun widgetView(item: Item): View? {
        val cached = widgetViews[item.widgetId]
        if (cached != null) {
            (cached.parent as? ViewGroup)?.removeView(cached)
            return cached
        }
        val info = awm.getAppWidgetInfo(item.widgetId) ?: return null
        val hv = widgetHost.createView(this, item.widgetId, info)
        hv.setOnLongClickListener { startItemDrag(item, hv); true }
        hv.addOnLayoutChangeListener { view, l, t, r, b, oldL, oldT, oldR, oldB ->
            if (r - l != oldR - oldL || b - t != oldB - oldT) {
                val d = resources.displayMetrics.density
                val w = ((r - l) / d).toInt()
                val h = ((b - t) / d).toInt()
                try {
                    (view as AppWidgetHostView).updateAppWidgetSize(Bundle(), w, h, w, h)
                } catch (e: Exception) {
                    // ignore
                }
            }
        }
        widgetViews[item.widgetId] = hv
        return hv
    }

    private fun widgetSpan(info: AppWidgetProviderInfo): IntArray {
        val cols = cfg.columns
        val cellW = max(1, (pager.width - dp(8)) / cols)
        val cellH = max(1, (pager.height - dp(8)) / homeRows)
        val sx = ceil(info.minWidth.toDouble() / cellW).toInt().coerceIn(1, cols)
        val sy = ceil(info.minHeight.toDouble() / cellH).toInt().coerceIn(1, homeRows)
        return intArrayOf(sx, sy)
    }

    private fun showWidgetPicker() {
        val providers = awm.installedProviders.sortedBy { it.loadLabel(packageManager).lowercase() }
        val list = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), dp(8), dp(12), dp(8))
        }
        val sv = ScrollView(this).apply { addView(list) }
        val dialog = AlertDialog.Builder(this)
            .setTitle("Widgets")
            .setView(sv)
            .setNegativeButton("Close", null)
            .create()
        for (info in providers) {
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(0, dp(8), 0, dp(8))
            }
            val img = ImageView(this)
            img.layoutParams = LinearLayout.LayoutParams(dp(88), dp(60))
            img.scaleType = ImageView.ScaleType.FIT_CENTER
            val prev: Drawable? = try {
                info.loadPreviewImage(this, 0)
            } catch (e: Exception) {
                null
            }
            val fallback: Drawable? = try {
                info.loadIcon(this, 0)
            } catch (e: Exception) {
                null
            }
            img.setImageDrawable(prev ?: fallback)
            val span = widgetSpan(info)
            val tv = TextView(this)
            tv.text = "${info.loadLabel(packageManager)}\n${span[0]} x ${span[1]}"
            tv.setPadding(dp(12), 0, 0, 0)
            row.addView(img)
            row.addView(tv)
            row.setOnClickListener {
                dialog.dismiss()
                addWidget(info)
            }
            list.addView(row)
        }
        dialog.show()
    }

    @Suppress("DEPRECATION")
    private fun addWidget(info: AppWidgetProviderInfo) {
        val id = widgetHost.allocateAppWidgetId()
        pendingWidget = info
        pendingWidgetId = id
        if (awm.bindAppWidgetIdIfAllowed(id, info.provider)) {
            afterBind(info, id)
        } else {
            val i = Intent(AppWidgetManager.ACTION_APPWIDGET_BIND)
            i.putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, id)
            i.putExtra(AppWidgetManager.EXTRA_APPWIDGET_PROVIDER, info.provider)
            startActivityForResult(i, REQ_BIND)
        }
    }

    @Suppress("DEPRECATION")
    private fun afterBind(info: AppWidgetProviderInfo, id: Int) {
        if (info.configure != null) {
            try {
                widgetHost.startAppWidgetConfigureActivityForResult(this, id, 0, REQ_CONFIG, null)
            } catch (e: Exception) {
                placeWidget(info, id)
            }
        } else {
            placeWidget(info, id)
        }
    }

    @Suppress("DEPRECATION")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        val info = pendingWidget
        val id = pendingWidgetId
        if (requestCode == REQ_BIND) {
            if (resultCode == RESULT_OK && info != null) afterBind(info, id) else cancelWidget(id)
        } else if (requestCode == REQ_CONFIG) {
            if (resultCode == RESULT_OK && info != null) placeWidget(info, id) else cancelWidget(id)
        }
    }

    private fun cancelWidget(id: Int) {
        if (id != -1) widgetHost.deleteAppWidgetId(id)
        pendingWidget = null
        pendingWidgetId = -1
    }

    private fun placeWidget(info: AppWidgetProviderInfo, id: Int) {
        val span = widgetSpan(info)
        val cols = cfg.columns
        var spot = store.findFree(pager.currentItem, span[0], span[1], cols, homeRows, -1L)
            ?: store.findFree(0, span[0], span[1], cols, homeRows, -1L)
        if (spot == null) {
            store.pageCount++
            spot = intArrayOf(store.pageCount - 1, 0, 0)
        }
        store.items.add(Item(store.newId(), WIDGET, HOME, spot[0], spot[1], spot[2], span[0], span[1], widgetId = id))
        pendingWidget = null
        pendingWidgetId = -1
        store.save()
        exitEditMode()
        renderAll()
        pager.setCurrentItem(spot[0], true)
    }

    // =====================================================================
    // Drag and drop
    // =====================================================================
    private fun startItemDrag(item: Item, v: View) {
        if (cfg.lockLayout) {
            showItemMenu(item, null)
            return
        }
        beginDrag(v, Drag(item, item.pkg, -1L))
    }

    private fun startAppDrag(app: AppInfo, v: View, fromFolder: Long) {
        if (cfg.lockLayout) {
            showAppMenu(app)
            return
        }
        beginDrag(v, Drag(null, app.pkg, fromFolder))
    }

    private fun beginDrag(v: View, d: Drag) {
        drag = d
        v.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
        val started = v.startDragAndDrop(ClipData.newPlainText("launcher", "item"), View.DragShadowBuilder(v), null, 0)
        if (started) {
            v.visibility = View.INVISIBLE
        } else {
            drag = null
        }
    }

    private fun handleDrag(e: DragEvent): Boolean {
        if (drag == null) return false
        when (e.action) {
            DragEvent.ACTION_DRAG_STARTED -> {
                onDragBegin()
                return true
            }
            DragEvent.ACTION_DRAG_LOCATION -> {
                onDragMove(e.x, e.y)
                return true
            }
            DragEvent.ACTION_DROP -> {
                onDragDrop(e.x, e.y)
                return true
            }
            DragEvent.ACTION_DRAG_ENDED -> {
                onDragEnd()
                return true
            }
        }
        return true
    }

    private fun rectOf(v: View): Rect {
        val l = IntArray(2)
        val r = IntArray(2)
        v.getLocationOnScreen(l)
        root.getLocationOnScreen(r)
        val x = l[0] - r[0]
        val y = l[1] - r[1]
        return Rect(x, y, x + v.width, y + v.height)
    }

    private fun itemRect(item: Item): Rect? {
        val cell = if (item.container == DOCK) dockCell else (workspace.cells.get(item.page) ?: return null)
        val pr = rectOf(cell)
        val r = cell.cellRect(item.x, item.y, item.spanX, item.spanY)
        return Rect(pr.left + r.left, pr.top + r.top, pr.left + r.right, pr.top + r.bottom)
    }

    private fun onDragBegin() {
        dragBar.alpha = 0f
        dragBar.visibility = View.VISIBLE
        dragBar.animate().alpha(1f).setDuration(150).start()
        if (drawerOpen) closeDrawer()
        if (folderOpen) closeFolder()
        if (shelfOpen) closeShelf()
    }

    private fun zoneAt(x: Float): Int {
        val r = rectOf(dragBar)
        return ((x - r.left) / (r.width() / 3f)).toInt().coerceIn(0, 2)
    }

    private fun highlightBar(zone: Int) {
        for (i in barZones.indices) {
            barZones[i].setBackgroundColor(if (i == zone) 0x55FFFFFF else 0x00000000)
        }
    }

    private fun clearHints() {
        for (i in 0 until workspace.cells.size()) workspace.cells.valueAt(i).clearHint()
        dockCell.clearHint()
    }

    private fun targetAt(x: Float, y: Float): Target? {
        val ix = x.toInt()
        val iy = y.toInt()
        if (dockHolder.visibility == View.VISIBLE) {
            val r = rectOf(dockCell)
            if (r.contains(ix, iy)) {
                val c = dockCell.cellAt(x - r.left, y - r.top)
                return Target(dockCell, DOCK, 0, c[0], 0)
            }
        }
        val pr = rectOf(pager)
        if (pr.contains(ix, iy)) {
            val page = pager.currentItem
            val cl = workspace.cells.get(page) ?: return null
            val c = cl.cellAt(x - pr.left, y - pr.top)
            return Target(cl, HOME, page, c[0], c[1])
        }
        return null
    }

    private fun onDragMove(x: Float, y: Float) {
        val d = drag ?: return
        clearHints()
        val bar = rectOf(dragBar)
        if (bar.contains(x.toInt(), y.toInt())) {
            highlightBar(zoneAt(x))
            setEdge(0)
            return
        }
        highlightBar(-1)

        val pr = rectOf(pager)
        val edge = dp(32)
        val dir = if (y < pr.top || y > pr.bottom) 0 else if (x < edge) -1 else if (x > root.width - edge) 1 else 0
        setEdge(dir)

        val t = targetAt(x, y) ?: return
        val moving = d.item
        val sx = moving?.spanX ?: 1
        val sy = moving?.spanY ?: 1
        val type = moving?.type ?: APP
        val existingApp = if (moving == null && d.fromFolder == -1L) store.findApp(d.pkg) else null
        val ignoreId = moving?.id ?: existingApp?.id ?: -1L
        val occ = store.itemAt(t.container, t.page, t.cx, t.cy, ignoreId)
        if (type == APP && occ != null && (occ.type == APP || occ.type == FOLDER) && occ.pkg != d.pkg) {
            t.cell.showHint(occ.x, occ.y, 1, 1, true)
        } else {
            val cx = min(t.cx, t.cell.cols - sx).coerceAtLeast(0)
            val cy = min(t.cy, t.cell.rows - sy).coerceAtLeast(0)
            t.cell.showHint(cx, cy, sx, sy, false)
        }
    }

    private fun setEdge(dir: Int) {
        if (dir == edgeDir) return
        handler.removeCallbacks(edgeRunnable)
        edgeDir = dir
        if (dir != 0) handler.postDelayed(edgeRunnable, 650)
    }

    private fun edgeSwitch() {
        if (edgeDir == 0) return
        val cur = pager.currentItem
        if (edgeDir == 1) {
            if (cur == store.pageCount - 1) {
                store.pageCount++
                pageAddedByDrag = true
                workspace.count = store.pageCount
                workspace.notifyDataSetChanged()
                rebuildDots()
            }
            pager.setCurrentItem(cur + 1, true)
        } else if (cur > 0) {
            pager.setCurrentItem(cur - 1, true)
        }
        handler.postDelayed(edgeRunnable, 900)
    }

    private fun onDragDrop(x: Float, y: Float) {
        val d = drag ?: return
        setEdge(0)
        val bar = rectOf(dragBar)
        if (bar.contains(x.toInt(), y.toInt())) {
            dropOnBar(d, zoneAt(x))
            return
        }
        val t = targetAt(x, y) ?: return
        val moving = d.item
        val sx = moving?.spanX ?: 1
        val sy = moving?.spanY ?: 1
        val type = moving?.type ?: APP
        val existingApp = if (moving == null && d.fromFolder == -1L) store.findApp(d.pkg) else null
        val ignoreId = moving?.id ?: existingApp?.id ?: -1L
        val cols = t.cell.cols
        val rows = t.cell.rows

        if (type == WIDGET && t.container == DOCK) {
            toast("Widgets can't go in the dock")
            return
        }

        // released on its own spot: it was just a long-press -> show the menu
        if (moving != null && moving.container == t.container &&
            (t.container == DOCK || moving.page == t.page) &&
            t.cx >= moving.x && t.cx < moving.x + moving.spanX &&
            t.cy >= moving.y && t.cy < moving.y + moving.spanY
        ) {
            showItemMenu(moving, itemRect(moving))
            return
        }

        val occ = store.itemAt(t.container, t.page, t.cx, t.cy, ignoreId)

        // dropped on another app or a folder: make or fill a folder
        if (type == APP && occ != null && (occ.type == APP || occ.type == FOLDER) && occ.pkg != d.pkg) {
            if (moving == null) {
                store.items.removeAll { it.type == APP && it.pkg == d.pkg && it !== occ }
                for (f in store.items) {
                    if (f.type == FOLDER && f !== occ) f.children.remove(d.pkg)
                }
            }
            detach(d)
            if (occ.type == FOLDER) {
                if (!occ.children.contains(d.pkg)) occ.children.add(d.pkg)
            } else {
                val first = occ.pkg
                occ.type = FOLDER
                occ.pkg = ""
                occ.title = "Folder"
                occ.children = mutableListOf(first, d.pkg)
            }
            finishDrop()
            return
        }

        // normal move: find a free spot
        var page = t.page
        val cx = min(t.cx, cols - sx).coerceAtLeast(0)
        val cy = min(t.cy, rows - sy).coerceAtLeast(0)
        var spot: IntArray? = if (store.isFree(t.container, page, cx, cy, sx, sy, cols, rows, ignoreId)) {
            intArrayOf(cx, cy)
        } else {
            store.findNear(t.container, page, cx, cy, sx, sy, cols, rows, ignoreId)
        }
        if (spot == null && t.container == HOME) {
            var p = page + 1
            while (spot == null && p < store.pageCount) {
                val s = store.findNear(HOME, p, 0, 0, sx, sy, cols, rows, ignoreId)
                if (s != null) {
                    spot = s
                    page = p
                }
                p++
            }
            if (spot == null) {
                store.pageCount++
                page = store.pageCount - 1
                spot = intArrayOf(0, 0)
            }
        }
        if (spot == null) {
            toast("No space here")
            return
        }
        val newPage = if (t.container == DOCK) 0 else page
        if (moving != null) {
            moving.container = t.container
            moving.page = newPage
            moving.x = spot[0]
            moving.y = spot[1]
        } else {
            detach(d)
            store.removeFromFolders(d.pkg)
            if (existingApp != null) {
                existingApp.container = t.container
                existingApp.page = newPage
                existingApp.x = spot[0]
                existingApp.y = spot[1]
            } else {
                store.items.add(Item(store.newId(), APP, t.container, newPage, spot[0], spot[1], pkg = d.pkg))
            }
        }
        finishDrop()
    }

    /** Take the dragged thing out of where it came from. */
    private fun detach(d: Drag) {
        val m = d.item
        if (m != null) store.items.remove(m)
        if (d.fromFolder != -1L) {
            store.items.firstOrNull { it.id == d.fromFolder }?.children?.remove(d.pkg)
        }
    }

    private fun finishDrop() {
        store.cleanFolders()
        store.save()
    }

    private fun dropOnBar(d: Drag, zone: Int) {
        val m = d.item
        val isApp = m == null || m.type == APP
        when (zone) {
            0 -> if (isApp) openAppInfo(d.pkg)
            1 -> removeDragged(d)
            2 -> if (isApp) uninstall(d.pkg)
        }
    }

    private fun removeDragged(d: Drag) {
        val m = d.item
        if (m != null) {
            if (m.type == WIDGET) {
                widgetHost.deleteAppWidgetId(m.widgetId)
                widgetViews.remove(m.widgetId)
            }
            store.items.remove(m)
        } else if (d.fromFolder != -1L) {
            store.items.firstOrNull { it.id == d.fromFolder }?.children?.remove(d.pkg)
        } else {
            store.items.removeAll { it.type == APP && it.pkg == d.pkg }
        }
        finishDrop()
    }

    private fun onDragEnd() {
        setEdge(0)
        dragBar.visibility = View.GONE
        highlightBar(-1)
        clearHints()
        drag = null
        if (pageAddedByDrag) {
            pageAddedByDrag = false
            store.trimTrailingPages()
        }
        store.save()
        renderAll()
    }

    // =====================================================================
    // Menus
    // =====================================================================
    private fun openAppInfo(pkg: String) {
        startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$pkg")))
    }

    private fun uninstall(pkg: String) {
        startActivity(Intent(Intent.ACTION_DELETE, Uri.parse("package:$pkg")))
    }

    private fun hideApp(pkg: String) {
        cfg.p.edit().putStringSet("hidden_apps", cfg.hiddenApps + pkg).apply()
        applyConfigIfChanged()
    }

    /** Shortcuts the app offers itself (for example Camera -> Selfie). Works because we are the home app. */
    private fun shortcutEntries(pkg: String): List<Pair<String, () -> Unit>> {
        val out = mutableListOf<Pair<String, () -> Unit>>()
        try {
            val la = getSystemService(Context.LAUNCHER_APPS_SERVICE) as LauncherApps
            if (!la.hasShortcutHostPermission()) return out
            val q = LauncherApps.ShortcutQuery()
            q.setPackage(pkg)
            q.setQueryFlags(
                LauncherApps.ShortcutQuery.FLAG_MATCH_DYNAMIC or
                    LauncherApps.ShortcutQuery.FLAG_MATCH_MANIFEST or
                    LauncherApps.ShortcutQuery.FLAG_MATCH_PINNED
            )
            val list = la.getShortcuts(q, Process.myUserHandle()) ?: return out
            for (s in list.filter { it.isEnabled }.take(4)) {
                val label = "★ " + (s.shortLabel ?: s.id)
                out.add(Pair(label, {
                    try {
                        la.startShortcut(s, null, null)
                    } catch (e: Exception) {
                        // ignore
                    }
                }))
            }
        } catch (e: Exception) {
            // ignore
        }
        return out
    }

    private fun showAppMenu(app: AppInfo) {
        val entries = mutableListOf<Pair<String, () -> Unit>>()
        entries.addAll(shortcutEntries(app.pkg))
        entries.add(Pair("App info", { openAppInfo(app.pkg) }))
        entries.add(Pair("Uninstall", { uninstall(app.pkg) }))
        entries.add(Pair("Hide app", { hideApp(app.pkg) }))
        showEntries(app.label, entries)
    }

    private fun showItemMenu(item: Item, anchor: Rect?) {
        val entries = mutableListOf<Pair<String, () -> Unit>>()
        var title = "Widget"
        when (item.type) {
            APP -> {
                title = appMap[item.pkg]?.label ?: item.pkg
                entries.addAll(shortcutEntries(item.pkg))
                entries.add(Pair("App info", { openAppInfo(item.pkg) }))
                entries.add(Pair("Uninstall", { uninstall(item.pkg) }))
                entries.add(Pair("Hide app", { hideApp(item.pkg) }))
                if (!cfg.lockLayout) entries.add(Pair("Remove from home screen", { removeItem(item) }))
            }
            FOLDER -> {
                title = if (item.title.isEmpty()) "Folder" else item.title
                entries.add(Pair("Open", { openFolder(item, null) }))
                if (!cfg.lockLayout) entries.add(Pair("Dissolve folder", { dissolveFolder(item) }))
            }
            WIDGET -> {
                if (!cfg.lockLayout) entries.add(Pair("Remove widget", { removeItem(item) }))
            }
        }
        showPopupMenu(anchor ?: itemRect(item), title, entries)
    }

    private fun showEntries(title: String, entries: List<Pair<String, () -> Unit>>) {
        if (entries.isEmpty()) return
        AlertDialog.Builder(this)
            .setTitle(title)
            .setItems(entries.map { it.first }.toTypedArray()) { _, i -> entries[i].second() }
            .show()
    }

    /** Small glass menu next to the icon. Falls back to a normal dialog if we don't know where the icon is. */
    private fun showPopupMenu(anchor: Rect?, title: String, entries: List<Pair<String, () -> Unit>>) {
        if (entries.isEmpty()) return
        if (anchor == null) {
            showEntries(title, entries)
            return
        }
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(dp(6), dp(8), dp(6), dp(8))
        box.background = UiStyle.panel(this, cfg.uiStyle, 22f, max(cfg.glassStrength, 55), box)
        val popup = PopupWindow(box, ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, true)
        popup.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        popup.elevation = dp(8).toFloat()
        if (title.isNotEmpty()) {
            val t = TextView(this)
            t.text = title
            t.setTextColor(0xB3FFFFFF.toInt())
            t.textSize = 12f
            t.setPadding(dp(14), dp(4), dp(14), dp(6))
            box.addView(t)
        }
        for ((label, action) in entries) {
            val row = TextView(this)
            row.text = label
            row.setTextColor(Color.WHITE)
            row.textSize = 15f
            row.setPadding(dp(14), dp(10), dp(28), dp(10))
            row.setOnClickListener {
                popup.dismiss()
                action()
            }
            box.addView(row)
        }
        box.measure(View.MeasureSpec.UNSPECIFIED, View.MeasureSpec.UNSPECIFIED)
        val w = box.measuredWidth
        val h = box.measuredHeight
        val x = (anchor.centerX() - w / 2).coerceIn(dp(8), max(dp(8), root.width - w - dp(8)))
        var y = anchor.top - h - dp(6)
        if (y < dp(40)) y = anchor.bottom + dp(6)
        val rl = IntArray(2)
        root.getLocationOnScreen(rl)
        popup.showAtLocation(root, Gravity.NO_GRAVITY, rl[0] + x, rl[1] + y)
    }

    private fun removeItem(item: Item) {
        if (item.type == WIDGET) {
            widgetHost.deleteAppWidgetId(item.widgetId)
            widgetViews.remove(item.widgetId)
        }
        store.items.remove(item)
        store.cleanFolders()
        store.save()
        renderAll()
    }

    private fun dissolveFolder(item: Item) {
        val pkgs = item.children.toList()
        store.items.remove(item)
        for (p in pkgs) addToHome(p)
        normalize()
        store.save()
        renderAll()
    }

    // =====================================================================
    // Folders
    // =====================================================================
    private fun openFolder(item: Item, from: View?) {
        openFolderId = item.id
        folderOpen = true
        folderName.setText(item.title)
        val apps = item.children.mapNotNull { appMap[it] }
        folderAdapter.submit(apps)
        val rows = ceil(apps.size / 4.0).toInt().coerceAtLeast(1)
        val lp = folderList.layoutParams
        lp.height = min(rows * dp(100), dp(420))
        folderList.layoutParams = lp
        folderBox.scaleX = 1f
        folderBox.scaleY = 1f
        folderBox.translationX = 0f
        folderBox.translationY = 0f
        folderOverlay.alpha = 0f
        folderOverlay.visibility = View.VISIBLE
        folderOverlay.animate().alpha(1f).setDuration(cfg.dur(160)).start()
        folderOverlay.performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK)
        if (from != null) {
            // grow out of the folder icon
            folderBox.alpha = 0f
            folderBox.post {
                val a = rectOf(from)
                val b = rectOf(folderBox)
                folderBox.translationX = (a.centerX() - b.centerX()).toFloat()
                folderBox.translationY = (a.centerY() - b.centerY()).toFloat()
                folderBox.scaleX = 0.25f
                folderBox.scaleY = 0.25f
                folderBox.alpha = 1f
                for (prop in arrayOf(DynamicAnimation.SCALE_X, DynamicAnimation.SCALE_Y)) {
                    val sa = SpringAnimation(folderBox, prop, 1f)
                    sa.spring.setStiffness(SpringForce.STIFFNESS_LOW).setDampingRatio(0.68f)
                    sa.start()
                }
                for (prop in arrayOf(DynamicAnimation.TRANSLATION_X, DynamicAnimation.TRANSLATION_Y)) {
                    val sa = SpringAnimation(folderBox, prop, 0f)
                    sa.spring.setStiffness(SpringForce.STIFFNESS_LOW).setDampingRatio(0.8f)
                    sa.start()
                }
            }
        } else {
            folderBox.alpha = 1f
            folderBox.scaleX = 0.8f
            folderBox.scaleY = 0.8f
            for (prop in arrayOf(DynamicAnimation.SCALE_X, DynamicAnimation.SCALE_Y)) {
                val sa = SpringAnimation(folderBox, prop, 1f)
                sa.spring.setStiffness(SpringForce.STIFFNESS_LOW).setDampingRatio(0.62f)
                sa.start()
            }
        }
        refreshBlur()
    }

    private fun saveFolderName() {
        val f = store.items.firstOrNull { it.id == openFolderId } ?: return
        val t = folderName.text.toString().trim()
        if (t != f.title) {
            f.title = t
            store.save()
            renderDock()
            workspace.notifyDataSetChanged()
        }
    }

    private fun closeFolder() {
        if (!folderOpen) return
        saveFolderName()
        hideKeyboard(folderName)
        folderOpen = false
        refreshBlur()
        folderOverlay.animate().alpha(0f).setDuration(cfg.dur(140))
            .withEndAction { folderOverlay.visibility = View.GONE }.start()
    }

    private fun hideKeyboard(v: View) {
        (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager).hideSoftInputFromWindow(v.windowToken, 0)
    }

    // =====================================================================
    // Edit mode (long-press on empty home screen)
    // =====================================================================
    private fun enterEditMode() {
        if (editMode || drag != null) return
        editMode = true
        editPanel.alpha = 0f
        editPanel.visibility = View.VISIBLE
        editPanel.animate().alpha(1f).setDuration(cfg.dur(160)).start()
        if (cfg.showDock) dockHolder.visibility = View.INVISIBLE
        renderAll() // icons start to wiggle
    }

    private fun exitEditMode() {
        if (!editMode) return
        editMode = false
        editPanel.animate().alpha(0f).setDuration(cfg.dur(120))
            .withEndAction { editPanel.visibility = View.GONE }.start()
        dockHolder.visibility = if (cfg.showDock) View.VISIBLE else View.GONE
        renderAll()
    }

    private fun showEffectDialog() {
        val values = arrayOf("slide", "zoom", "fade", "cube")
        val names = arrayOf("Slide", "Zoom", "Fade", "Cube")
        val cur = values.indexOf(cfg.pageEffect).coerceAtLeast(0)
        AlertDialog.Builder(this)
            .setTitle("Page transition effect")
            .setSingleChoiceItems(names, cur) { dlg, which ->
                cfg.p.edit().putString("page_effect", values[which]).apply()
                applyConfigIfChanged()
                dlg.dismiss()
            }
            .show()
    }

    private fun showPagesDialog() {
        val names = arrayOf("Add page", "Delete this page (only if empty)")
        AlertDialog.Builder(this).setItems(names) { _, w ->
            if (w == 0) {
                store.pageCount++
                store.save()
                renderAll()
                pager.setCurrentItem(store.pageCount - 1, true)
            } else {
                deleteCurrentPage()
            }
        }.show()
    }

    private fun deleteCurrentPage() {
        val p = pager.currentItem
        if (store.pageCount <= 1) {
            toast("At least one page is needed")
            return
        }
        if (store.items.any { it.container == HOME && it.page == p }) {
            toast("Move or remove everything on this page first")
            return
        }
        for (i in store.items) {
            if (i.container == HOME && i.page > p) i.page--
        }
        store.pageCount--
        store.save()
        renderAll()
    }

    private fun showTidyDialog() {
        val names = arrayOf("Close gaps", "Sort A to Z", "Newest first")
        AlertDialog.Builder(this).setTitle("Tidy up home screen").setItems(names) { _, w ->
            tidy(w)
            exitEditMode()
        }.show()
    }

    private fun labelOf(i: Item): String =
        if (i.type == FOLDER) i.title else (appMap[i.pkg]?.label ?: i.pkg)

    private fun tidy(mode: Int) {
        val cols = cfg.columns
        val rows = homeRows
        val movable = store.items.filter { it.container == HOME && it.type != WIDGET }
        val sorted = when (mode) {
            1 -> movable.sortedBy { labelOf(it).lowercase() }
            2 -> movable.sortedByDescending { appMap[it.pkg]?.installTime ?: 0L }
            else -> movable.sortedWith(compareBy({ it.page }, { it.y }, { it.x }))
        }
        for (i in movable) i.page = -1
        for (i in sorted) {
            var spot = store.findFree(0, 1, 1, cols, rows, i.id)
            if (spot == null) {
                store.pageCount++
                spot = intArrayOf(store.pageCount - 1, 0, 0)
            }
            i.page = spot[0]
            i.x = spot[1]
            i.y = spot[2]
        }
        store.trimTrailingPages()
        store.save()
        renderAll()
    }

    // =====================================================================
    // Double-tap to lock
    // =====================================================================
    private fun handleDoubleTap(rawX: Float, rawY: Float) {
        if (!cfg.doubleTapLock || drawerOpen || editMode || folderOpen || shelfOpen) return
        val rl = IntArray(2)
        root.getLocationOnScreen(rl)
        val t = targetAt(rawX - rl[0], rawY - rl[1]) ?: return
        if (t.container != HOME) return
        if (store.itemAt(HOME, t.page, t.cx, t.cy, -1L) != null) return
        val svc = LockService.instance
        if (svc != null) {
            svc.lock()
        } else {
            AlertDialog.Builder(this)
                .setTitle("Turn on double-tap lock")
                .setMessage("Open Accessibility settings and switch on \"Color Launcher double-tap lock\".")
                .setPositiveButton("Open settings") { _, _ ->
                    startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
                }
                .setNegativeButton("Later", null)
                .show()
        }
    }

    // =====================================================================
    // App lock / private apps
    // =====================================================================
    private fun authenticate(title: String, onOk: () -> Unit) {
        val auth = if (Build.VERSION.SDK_INT >= 30) {
            BiometricManager.Authenticators.BIOMETRIC_WEAK or BiometricManager.Authenticators.DEVICE_CREDENTIAL
        } else {
            BiometricManager.Authenticators.BIOMETRIC_WEAK
        }
        if (BiometricManager.from(this).canAuthenticate(auth) != BiometricManager.BIOMETRIC_SUCCESS) {
            toast("Set up a screen lock or fingerprint in phone settings first")
            return
        }
        val prompt = BiometricPrompt(
            this, ContextCompat.getMainExecutor(this),
            object : BiometricPrompt.AuthenticationCallback() {
                override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) {
                    onOk()
                }
            }
        )
        val b = BiometricPrompt.PromptInfo.Builder()
            .setTitle(title)
            .setAllowedAuthenticators(auth)
        if (Build.VERSION.SDK_INT < 30) b.setNegativeButtonText("Cancel")
        prompt.authenticate(b.build())
    }

    // =====================================================================
    // Opening apps (with animations)
    // =====================================================================
    private fun launch(app: AppInfo, from: View) {
        if (app.pkg in cfg.lockedApps && unlockedOnce != app.pkg) {
            authenticate("Unlock " + app.label) {
                unlockedOnce = app.pkg
                launch(app, from)
                unlockedOnce = null
            }
            return
        }
        val intent = packageManager.getLaunchIntentForPackage(app.pkg) ?: return
        Usage.record(this, app.pkg)

        // remember where the icon is, for the closing animation
        val loc = IntArray(2)
        val rl = IntArray(2)
        from.getLocationOnScreen(loc)
        root.getLocationOnScreen(rl)
        val left = loc[0] - rl[0]
        val top = loc[1] - rl[1]
        lastRect = Rect(left, top, left + from.width, top + from.height)
        lastColor = averageColor(app.icon)

        val opts = when (cfg.openAnim) {
            "zoom" -> ActivityOptions.makeScaleUpAnimation(from, 0, 0, from.width, from.height)
            "fade" -> ActivityOptions.makeCustomAnimation(this, android.R.anim.fade_in, android.R.anim.fade_out)
            else -> ActivityOptions.makeCustomAnimation(this, 0, 0)
        }
        launched = true
        startActivity(intent, opts.toBundle())
        if (cfg.openAnim != "none") {
            home.animate().scaleX(0.9f).scaleY(0.9f).alpha(0f)
                .setDuration(cfg.dur(240)).withLayer().start()
        }
        home.removeCallbacks(restoreRunnable)
        home.postDelayed(restoreRunnable, 1500)
        if (drawerOpen) closeDrawer()
        if (shelfOpen) closeShelf()
        if (folderOpen) closeFolder()
        if (editMode) exitEditMode()
    }

    private fun lerp(a: Float, b: Float, t: Float) = a + (b - a) * t

    private fun playShrink() {
        val r = lastRect ?: return
        val w = max(1, r.width()).toFloat()
        val h = max(1, r.height()).toFloat()
        val fullW = root.width.toFloat()
        val fullH = root.height.toFloat()
        if (fullW == 0f || fullH == 0f) return

        val bg = GradientDrawable().apply { setColor(lastColor) }
        overlay.animate().cancel()
        overlay.layoutParams = FrameLayout.LayoutParams(w.toInt(), h.toInt())
        overlay.background = bg
        overlay.pivotX = 0f
        overlay.pivotY = 0f
        overlay.alpha = 1f
        overlay.visibility = View.VISIBLE
        val endRadius = w * 0.30f

        ValueAnimator.ofFloat(0f, 1f).apply {
            duration = cfg.dur(320)
            interpolator = DecelerateInterpolator(1.4f)
            addUpdateListener { a ->
                val t = a.animatedValue as Float
                overlay.scaleX = lerp(fullW / w, 1f, t)
                overlay.scaleY = lerp(fullH / h, 1f, t)
                overlay.translationX = lerp(0f, r.left.toFloat(), t)
                overlay.translationY = lerp(0f, r.top.toFloat(), t)
                bg.cornerRadius = lerp(0f, endRadius, t)
                overlay.alpha = if (t < 0.6f) 1f else 1f - (t - 0.6f) / 0.4f
            }
            addListener(object : AnimatorListenerAdapter() {
                override fun onAnimationEnd(animation: Animator) {
                    overlay.visibility = View.GONE
                }
            })
            start()
        }
    }

    // =====================================================================
    // Drawer / search
    // =====================================================================
    private fun openDrawer() {
        if (drawerOpen || editMode || folderOpen || shelfOpen) return
        drawerOpen = true
        drawer.visibility = View.VISIBLE
        drawer.animate().cancel()
        drawer.translationY = drawer.height.toFloat()
        val sa = SpringAnimation(drawer, DynamicAnimation.TRANSLATION_Y, 0f)
        sa.spring.setStiffness(SpringForce.STIFFNESS_LOW).setDampingRatio(0.82f)
        drawerSpring = sa
        sa.start()
        refreshDrawerResults()
        refreshBlur()
    }

    private fun closeDrawer() {
        if (!drawerOpen) return
        drawerOpen = false
        refreshBlur()
        drawerSpring?.cancel()
        if (drawerPrivate) {
            drawerPrivate = false
            refreshLists()
        }
        search.setText("")
        search.clearFocus()
        hideKeyboard(search)
        drawer.animate().translationY(drawer.height.toFloat()).setDuration(cfg.dur(200))
            .withLayer().withEndAction { drawer.visibility = View.INVISIBLE }.start()
    }

    /** Search results, extras (calculator, units, contacts, web), suggestions and A-Z index. */
    private fun refreshDrawerResults() {
        val q = search.text.toString().trim()
        val src = drawerSource()
        drawerAdapter.submit(if (q.isEmpty()) src else src.filter { it.label.lowercase().contains(q.lowercase()) })
        updateExtras(q)
        val empty = q.isEmpty() && !drawerPrivate
        alphaIndex.visibility = if (empty && cfg.sortOrder == "name") View.VISIBLE else View.GONE
        renderSuggested(empty)
    }

    private fun smallAppView(app: AppInfo): View {
        val v = layoutInflater.inflate(R.layout.item_app, null, false)
        v.layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        val icon = v.findViewById<ImageView>(R.id.icon)
        val px = dp(cfg.iconSize - 8)
        icon.layoutParams = icon.layoutParams.apply {
            width = px
            height = px
        }
        icon.setImageDrawable(app.icon)
        val label = v.findViewById<TextView>(R.id.label)
        label.text = app.label
        label.textSize = 11f
        v.pressFeedback(cfg.pressEffect)
        v.setOnClickListener { launch(app, icon) }
        v.setOnLongClickListener { startAppDrag(app, v, -1L); true }
        return v
    }

    private fun renderSuggested(show: Boolean) {
        suggestRow.removeAllViews()
        val list = if (show && cfg.showSuggested) {
            Usage.top(this, 5).mapNotNull { appMap[it] }.filter { it.pkg !in cfg.hiddenApps }
        } else {
            emptyList()
        }
        if (list.isEmpty()) {
            suggestRow.visibility = View.GONE
            return
        }
        suggestRow.visibility = View.VISIBLE
        for (app in list) suggestRow.addView(smallAppView(app))
        for (i in list.size until 5) suggestRow.addView(View(this), LinearLayout.LayoutParams(0, 1, 1f))
    }

    private fun extraRow(label: String, action: () -> Unit): View {
        val t = TextView(this)
        t.text = label
        t.setTextColor(Color.WHITE)
        t.textSize = 15f
        t.setPadding(dp(18), dp(12), dp(18), dp(12))
        t.background = UiStyle.panel(this, cfg.uiStyle, 20f, cfg.glassStrength, t)
        val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        lp.setMargins(dp(16), 0, dp(16), dp(8))
        t.layoutParams = lp
        t.setOnClickListener { action() }
        return t
    }

    private fun updateExtras(q: String) {
        searchExtras.removeAllViews()
        if (q.isEmpty() || drawerPrivate) {
            searchExtras.visibility = View.GONE
            return
        }
        val rows = mutableListOf<Pair<String, () -> Unit>>()
        QuickSearch.calculate(q)?.let { res ->
            rows.add(Pair("＝ $res    (tap to copy)", { copyText(res) }))
        }
        QuickSearch.convert(q)?.let { res ->
            rows.add(Pair("⇄ $res    (tap to copy)", { copyText(res) }))
        }
        if (cfg.searchContacts) {
            if (hasContacts()) {
                for (c in findContacts(q)) rows.add(Pair("👤 " + c.first, { openContact(c.second) }))
            } else {
                rows.add(Pair("👤 Tap to allow contacts in search", { reqContacts.launch(Manifest.permission.READ_CONTACTS) }))
            }
        }
        rows.add(Pair("🔎 Search the web for “$q”", { webSearch(q) }))
        for ((label, action) in rows) searchExtras.addView(extraRow(label, action))
        searchExtras.visibility = View.VISIBLE
    }

    private fun copyText(s: String) {
        (getSystemService(CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText("result", s))
        toast("Copied")
    }

    private fun hasContacts(): Boolean =
        ContextCompat.checkSelfPermission(this, Manifest.permission.READ_CONTACTS) == PackageManager.PERMISSION_GRANTED

    private fun findContacts(q: String): List<Pair<String, Uri>> {
        val out = mutableListOf<Pair<String, Uri>>()
        try {
            contentResolver.query(
                ContactsContract.Contacts.CONTENT_URI,
                arrayOf(
                    ContactsContract.Contacts._ID,
                    ContactsContract.Contacts.LOOKUP_KEY,
                    ContactsContract.Contacts.DISPLAY_NAME_PRIMARY
                ),
                ContactsContract.Contacts.DISPLAY_NAME_PRIMARY + " LIKE ?",
                arrayOf("%$q%"),
                ContactsContract.Contacts.DISPLAY_NAME_PRIMARY + " ASC LIMIT 3"
            )?.use { c ->
                while (c.moveToNext()) {
                    out.add(Pair(c.getString(2) ?: "", ContactsContract.Contacts.getLookupUri(c.getLong(0), c.getString(1))))
                }
            }
        } catch (e: Exception) {
            // ignore
        }
        return out
    }

    private fun openContact(uri: Uri) {
        try {
            startActivity(Intent(Intent.ACTION_VIEW, uri))
        } catch (e: Exception) {
            toast("Could not open contact")
        }
    }

    private fun webSearch(q: String) {
        try {
            startActivity(Intent(Intent.ACTION_WEB_SEARCH).putExtra(SearchManager.QUERY, q))
        } catch (e: Exception) {
            try {
                startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=" + Uri.encode(q))))
            } catch (e2: Exception) {
                toast("No browser found")
            }
        }
    }

    // =====================================================================
    // Shelf (swipe right on the first page)
    // =====================================================================
    private fun tryStart(i: Intent) {
        try {
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            startActivity(i)
        } catch (e: Exception) {
            toast("Not available on this phone")
        }
    }

    private fun toggleTorch() {
        try {
            val cm = getSystemService(Context.CAMERA_SERVICE) as CameraManager
            val id = cm.cameraIdList.firstOrNull {
                cm.getCameraCharacteristics(it).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
            } ?: return
            torchOn = !torchOn
            cm.setTorchMode(id, torchOn)
        } catch (e: Exception) {
            toast("Torch not available")
        }
    }

    private fun shelfCard(text: String, onClick: (() -> Unit)?): TextView {
        val t = TextView(this)
        t.text = text
        t.setTextColor(Color.WHITE)
        t.textSize = 15f
        t.setPadding(dp(18), dp(14), dp(18), dp(14))
        t.background = UiStyle.panel(this, cfg.uiStyle, 22f, cfg.glassStrength, t)
        val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        lp.setMargins(dp(16), dp(6), dp(16), dp(6))
        t.layoutParams = lp
        if (onClick != null) t.setOnClickListener { onClick() }
        return t
    }

    private fun shelfTitle(text: String): TextView {
        val t = TextView(this)
        t.text = text
        t.setTextColor(0xCCFFFFFF.toInt())
        t.textSize = 14f
        t.setPadding(dp(24), dp(18), dp(24), dp(4))
        return t
    }

    private fun appRow(apps: List<AppInfo>): View {
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.setPadding(dp(12), 0, dp(12), 0)
        for (app in apps) {
            val v = smallAppView(app)
            v.setOnClickListener {
                closeShelf()
                launch(app, v.findViewById(R.id.icon))
            }
            row.addView(v)
        }
        for (i in apps.size until 4) row.addView(View(this), LinearLayout.LayoutParams(0, 1, 1f))
        return row
    }

    private fun buildShelf() {
        shelfContent.removeAllViews()
        val title = TextView(this)
        title.text = "Shelf"
        title.setTextColor(Color.WHITE)
        title.textSize = 30f
        title.typeface = Typeface.create("sans-serif-light", Typeface.NORMAL)
        title.setPadding(dp(24), dp(24), dp(24), dp(8))
        shelfContent.addView(title)

        shelfContent.addView(shelfCard("🔎  Search apps, contacts, web") {
            closeShelf()
            openDrawer()
        })

        // quick actions
        val actions = LinearLayout(this)
        actions.orientation = LinearLayout.HORIZONTAL
        actions.setPadding(dp(12), dp(6), dp(12), dp(6))
        val quick = listOf<Pair<String, () -> Unit>>(
            Pair("🔦\nTorch", { toggleTorch() }),
            Pair("🧮\nCalc", {
                tryStart(Intent.makeMainSelectorActivity(Intent.ACTION_MAIN, Intent.CATEGORY_APP_CALCULATOR))
            }),
            Pair("📷\nCamera", { tryStart(Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA)) }),
            Pair("⏰\nClock", { tryStart(Intent(AlarmClock.ACTION_SHOW_ALARMS)) }),
            Pair("⚙\nSettings", { tryStart(Intent(Settings.ACTION_SETTINGS)) })
        )
        for ((label, action) in quick) {
            val b = TextView(this)
            b.text = label
            b.gravity = Gravity.CENTER
            b.setTextColor(Color.WHITE)
            b.textSize = 12f
            b.setPadding(0, dp(12), 0, dp(12))
            b.background = UiStyle.panel(this, cfg.uiStyle, 20f, cfg.glassStrength, b)
            val lp = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            lp.setMargins(dp(4), 0, dp(4), 0)
            b.layoutParams = lp
            b.setOnClickListener { action() }
            actions.addView(b)
        }
        shelfContent.addView(actions)

        // today
        shelfContent.addView(shelfTitle("TODAY"))
        if (glance.weatherText.isNotEmpty()) shelfContent.addView(shelfCard(glance.weatherText.replace("\n", "  ·  "), null))
        if (glance.calendarText.isNotEmpty()) shelfContent.addView(shelfCard(glance.calendarText.replace("\n", "  ·  "), null))
        if (glance.batteryText.isNotEmpty()) shelfContent.addView(shelfCard(glance.batteryText.replace("\n", "  ·  "), null))

        val frequent = Usage.top(this, 8).mapNotNull { appMap[it] }.filter { it.pkg !in cfg.hiddenApps }
        if (frequent.isNotEmpty()) {
            shelfContent.addView(shelfTitle("FREQUENTLY USED"))
            frequent.chunked(4).forEach { shelfContent.addView(appRow(it)) }
        }
        val recent = Usage.recent(this, 8).mapNotNull { appMap[it] }.filter { it.pkg !in cfg.hiddenApps }
        if (recent.isNotEmpty()) {
            shelfContent.addView(shelfTitle("RECENT"))
            recent.chunked(4).forEach { shelfContent.addView(appRow(it)) }
        }
    }

    private fun openShelf() {
        if (shelfOpen || drawerOpen || editMode || folderOpen) return
        shelfOpen = true
        buildShelf()
        shelf.visibility = View.VISIBLE
        shelf.animate().cancel()
        shelf.translationX = -root.width.toFloat()
        val sa = SpringAnimation(shelf, DynamicAnimation.TRANSLATION_X, 0f)
        sa.spring.setStiffness(SpringForce.STIFFNESS_LOW).setDampingRatio(0.85f)
        shelfSpring = sa
        sa.start()
        refreshBlur()
    }

    private fun closeShelf() {
        if (!shelfOpen) return
        shelfOpen = false
        refreshBlur()
        shelfSpring?.cancel()
        shelf.animate().translationX(-root.width.toFloat()).setDuration(cfg.dur(220))
            .withLayer().withEndAction { shelf.visibility = View.GONE }.start()
    }
}
