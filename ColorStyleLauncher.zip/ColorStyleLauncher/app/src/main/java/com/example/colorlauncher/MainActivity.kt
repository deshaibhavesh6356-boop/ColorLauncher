package com.example.colorlauncher

import android.app.ActivityOptions
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Path
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.drawable.AdaptiveIconDrawable
import android.graphics.drawable.BitmapDrawable
import android.graphics.drawable.Drawable
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.provider.Settings
import android.text.Editable
import android.text.TextWatcher
import android.view.GestureDetector
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.animation.DecelerateInterpolator
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import androidx.viewpager2.widget.ViewPager2
import kotlin.concurrent.thread
import kotlin.math.abs
import kotlin.math.max

class MainActivity : AppCompatActivity() {

    private lateinit var home: View
    private lateinit var drawer: View
    private lateinit var search: EditText
    private lateinit var dock: LinearLayout
    private lateinit var dots: LinearLayout
    private lateinit var pager: ViewPager2
    private lateinit var pagesAdapter: PagesAdapter
    private lateinit var drawerAdapter: AppAdapter
    private lateinit var gestures: GestureDetector

    private var apps = listOf<AppInfo>()
    private var drawerOpen = false
    private val prefs by lazy { getSharedPreferences("launcher", MODE_PRIVATE) }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private val pkgReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            loadApps()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        home = findViewById(R.id.home)
        drawer = findViewById(R.id.drawer)
        search = findViewById(R.id.search)
        dock = findViewById(R.id.dock)
        dots = findViewById(R.id.dots)
        pager = findViewById(R.id.pager)

        // Home pages
        pagesAdapter = PagesAdapter(::launch, ::showMenu)
        pager.adapter = pagesAdapter
        pager.addOnLayoutChangeListener { _, _, t, _, b, _, ot, _, ob ->
            if (b - t != ob - ot) rebuildPages()
        }
        pager.registerOnPageChangeCallback(object : ViewPager2.OnPageChangeCallback() {
            override fun onPageSelected(position: Int) = updateDots(position)
        })

        // Drawer / search
        drawerAdapter = AppAdapter(::launch, ::showMenu)
        findViewById<RecyclerView>(R.id.recycler).apply {
            layoutManager = GridLayoutManager(this@MainActivity, 4)
            adapter = drawerAdapter
        }
        findViewById<View>(R.id.searchPill).setOnClickListener { openDrawer() }
        search.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) {
                val q = s?.toString().orEmpty().trim().lowercase()
                drawerAdapter.submit(if (q.isEmpty()) apps else apps.filter { it.label.lowercase().contains(q) })
            }
        })
        search.setOnEditorActionListener { _, id, _ ->
            if (id == EditorInfo.IME_ACTION_GO) drawerAdapter.first()?.let { launch(it, search) }
            true
        }

        // Long-press the clock = wallpaper picker
        findViewById<View>(R.id.clockBox).setOnLongClickListener {
            startActivity(Intent.createChooser(Intent(Intent.ACTION_SET_WALLPAPER), "Wallpaper"))
            true
        }

        // Swipe up anywhere on home = open search/drawer
        gestures = GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onDown(e: MotionEvent) = true
            override fun onFling(e1: MotionEvent?, e2: MotionEvent, vx: Float, vy: Float): Boolean {
                if (e1 != null && e1.y - e2.y > 160 && abs(e1.y - e2.y) > abs(e1.x - e2.x) * 1.5f && vy < -400) {
                    openDrawer()
                    return true
                }
                return false
            }
        })

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (drawerOpen) closeDrawer() // on the home screen, back does nothing
            }
        })

        val filter = IntentFilter().apply {
            addAction(Intent.ACTION_PACKAGE_ADDED)
            addAction(Intent.ACTION_PACKAGE_REMOVED)
            addAction(Intent.ACTION_PACKAGE_REPLACED)
            addDataScheme("package")
        }
        ContextCompat.registerReceiver(this, pkgReceiver, filter, ContextCompat.RECEIVER_EXPORTED)

        loadApps()
    }

    override fun dispatchTouchEvent(ev: MotionEvent): Boolean {
        if (!drawerOpen) gestures.onTouchEvent(ev)
        return super.dispatchTouchEvent(ev)
    }

    override fun onDestroy() {
        unregisterReceiver(pkgReceiver)
        super.onDestroy()
    }

    // Home button pressed while already on the launcher
    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        if (drawerOpen) closeDrawer() else pager.setCurrentItem(0, true)
    }

    // Closing animation: home zooms back in when you return from an app
    override fun onResume() {
        super.onResume()
        if (home.alpha < 1f || home.scaleX != 1f) {
            home.scaleX = 1.08f
            home.scaleY = 1.08f
            home.alpha = 0f
            home.animate().scaleX(1f).scaleY(1f).alpha(1f)
                .setDuration(320).setInterpolator(DecelerateInterpolator()).start()
        }
    }

    // ---------- Apps ----------
    private fun loadApps() {
        thread {
            val pm = packageManager
            val query = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
            val list = pm.queryIntentActivities(query, 0)
                .filter { it.activityInfo.packageName != packageName }
                .map { AppInfo(it.loadLabel(pm).toString(), it.activityInfo.packageName, styleIcon(it.loadIcon(pm))) }
                .distinctBy { it.pkg }
                .sortedBy { it.label.lowercase() }
            runOnUiThread {
                apps = list
                drawerAdapter.submit(list)
                rebuildPages()
                renderDock()
            }
        }
    }

    /** Same rounded-square icon shape for every app (ColorOS look). */
    private fun styleIcon(src: Drawable): Drawable {
        val size = 160
        val bmp = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        if (src is AdaptiveIconDrawable) {
            val path = Path().apply {
                addRoundRect(RectF(0f, 0f, size.toFloat(), size.toFloat()), size * 0.30f, size * 0.30f, Path.Direction.CW)
            }
            c.clipPath(path)
            val off = (size * 0.25f).toInt() // adaptive layers are 108dp, visible area 72dp
            val r = Rect(-off, -off, size + off, size + off)
            src.background?.apply { setBounds(r); draw(c) }
            src.foreground?.apply { setBounds(r); draw(c) }
        } else {
            src.setBounds(0, 0, size, size)
            src.draw(c)
        }
        return BitmapDrawable(resources, bmp)
    }

    private fun rebuildPages() {
        val h = pager.height
        if (h == 0 || apps.isEmpty()) return
        val rows = max(3, h / dp(92))
        val pages = apps.chunked(rows * 4)
        pagesAdapter.submit(pages)
        dots.removeAllViews()
        if (pages.size > 1) {
            pages.indices.forEach { _ ->
                dots.addView(ImageView(this).apply {
                    layoutParams = LinearLayout.LayoutParams(dp(14), dp(14))
                    scaleType = ImageView.ScaleType.CENTER
                })
            }
            updateDots(pager.currentItem)
        }
    }

    private fun updateDots(selected: Int) {
        for (i in 0 until dots.childCount) {
            (dots.getChildAt(i) as ImageView).setImageResource(if (i == selected) R.drawable.dot_on else R.drawable.dot_off)
        }
    }

    // Opening animation: app zooms out of its icon while the home screen fades back
    private fun launch(app: AppInfo, from: View) {
        val intent = packageManager.getLaunchIntentForPackage(app.pkg) ?: return
        val opts = ActivityOptions.makeScaleUpAnimation(from, 0, 0, from.width, from.height)
        startActivity(intent, opts.toBundle())
        home.animate().scaleX(0.9f).scaleY(0.9f).alpha(0f).setDuration(240).start()
        if (drawerOpen) closeDrawer()
    }

    // ---------- Drawer / search ----------
    private fun openDrawer() {
        if (drawerOpen) return
        drawerOpen = true
        drawer.visibility = View.VISIBLE
        drawer.translationY = drawer.height.toFloat()
        drawer.animate().translationY(0f).setDuration(240).setInterpolator(DecelerateInterpolator()).start()
    }

    private fun closeDrawer() {
        if (!drawerOpen) return
        drawerOpen = false
        search.setText("")
        search.clearFocus()
        (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager)
            .hideSoftInputFromWindow(search.windowToken, 0)
        drawer.animate().translationY(drawer.height.toFloat()).setDuration(200)
            .withEndAction { drawer.visibility = View.INVISIBLE }.start()
    }

    // ---------- Dock ----------
    private fun dockPackages(): List<String> {
        val saved = prefs.getString("dock", null)
        if (!saved.isNullOrEmpty()) return saved.split(",")
        val intents = listOf(
            Intent(Intent.ACTION_DIAL),
            Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:")),
            Intent(Intent.ACTION_VIEW, Uri.parse("https://")),
            Intent(MediaStore.ACTION_IMAGE_CAPTURE)
        )
        return intents.mapNotNull {
            packageManager.resolveActivity(it, PackageManager.MATCH_DEFAULT_ONLY)?.activityInfo?.packageName
        }.filter { it != "android" }.distinct()
    }

    private fun saveDock(list: List<String>) {
        prefs.edit().putString("dock", list.joinToString(",")).apply()
        renderDock()
    }

    private fun renderDock() {
        dock.removeAllViews()
        dockPackages().mapNotNull { p -> apps.find { it.pkg == p } }.take(5).forEach { app ->
            val v = layoutInflater.inflate(R.layout.item_app, dock, false)
            v.layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            val icon = v.findViewById<ImageView>(R.id.icon)
            icon.setImageDrawable(app.icon)
            v.findViewById<TextView>(R.id.label).visibility = View.GONE
            v.pressFeedback()
            v.setOnClickListener { launch(app, icon) }
            v.setOnLongClickListener { showMenu(app); true }
            dock.addView(v)
        }
    }

    // ---------- Long-press menu ----------
    private fun showMenu(app: AppInfo) {
        val items = arrayOf("Add to dock", "Remove from dock", "App info", "Uninstall")
        AlertDialog.Builder(this).setTitle(app.label).setItems(items) { _, which ->
            when (which) {
                0 -> saveDock((dockPackages() + app.pkg).distinct().takeLast(5))
                1 -> saveDock(dockPackages() - app.pkg)
                2 -> startActivity(
                    Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${app.pkg}"))
                )
                3 -> startActivity(Intent(Intent.ACTION_DELETE, Uri.parse("package:${app.pkg}")))
            }
        }.show()
    }
}
