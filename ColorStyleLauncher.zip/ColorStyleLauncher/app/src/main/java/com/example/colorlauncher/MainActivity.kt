package com.example.colorlauncher

import android.Manifest
import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.ObjectAnimator
import android.animation.ValueAnimator
import android.app.ActivityOptions
import android.app.SearchManager
import android.app.WallpaperManager
import android.appwidget.AppWidgetHost
import android.appwidget.AppWidgetHostView
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProviderInfo
import android.content.BroadcastReceiver
import android.content.ClipData
import android.content.ClipboardManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ApplicationInfo
import android.content.pm.LauncherApps
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapShader
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PorterDuff
import android.graphics.PorterDuffColorFilter
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.RenderEffect
import android.graphics.Shader
import android.graphics.Typeface
import android.graphics.drawable.AdaptiveIconDrawable
import android.graphics.drawable.BitmapDrawable
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.Process
import android.provider.AlarmClock
import android.provider.ContactsContract
import android.provider.MediaStore
import android.provider.Settings
import android.text.Editable
import android.text.TextWatcher
import android.view.DragEvent
import android.view.GestureDetector
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.VelocityTracker
import android.view.View
import android.view.ViewConfiguration
import android.view.ViewGroup
import android.view.animation.DecelerateInterpolator
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.PopupWindow
import android.widget.ScrollView
import android.widget.TextClock
import android.widget.TextView
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.core.content.ContextCompat
import androidx.core.graphics.ColorUtils
import androidx.dynamicanimation.animation.DynamicAnimation
import androidx.dynamicanimation.animation.SpringAnimation
import androidx.dynamicanimation.animation.SpringForce
import androidx.preference.PreferenceManager
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import androidx.viewpager2.widget.ViewPager2
import kotlin.concurrent.thread
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.ceil
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.sign
import kotlin.math.sin
import kotlin.random.Random

class MainActivity : AppCompatActivity() {

    private class Drag(val item: Item?, val pkg: String, val fromFolder: Long)
    private class Target(val cell: CellLayout, val container: Int, val page: Int, val cx: Int, val cy: Int)

    companion object {
        private const val REQ_BIND = 41
        private const val REQ_CONFIG = 42
    }

    private lateinit var cfg: LauncherPrefs
    private lateinit var store: LayoutStore

    private lateinit var root: FrameLayout
    private lateinit var home: View
    private lateinit var clockBox: View
    private lateinit var clockTime: TextClock
    private lateinit var clockDate: TextClock
    private lateinit var glanceBox: View
    private lateinit var searchPill: TextView
    private lateinit var drawer: MorphLayout
    private lateinit var categoryRow: LinearLayout
    private lateinit var search: EditText
    private lateinit var searchExtras: LinearLayout
    private lateinit var suggestRow: LinearLayout
    private lateinit var alphaIndex: LinearLayout
    private lateinit var shelf: View
    private lateinit var shelfContent: LinearLayout
    private lateinit var dockHolder: FrameLayout
    private lateinit var dockCell: CellLayout
    private lateinit var dots: LinearLayout
    private lateinit var pager: ViewPager2
    private lateinit var overlay: View
    private lateinit var drawerList: RecyclerView
    private lateinit var dragBar: View
    private lateinit var barZones: Array<TextView>
    private lateinit var editPanel: View
    private lateinit var folderOverlay: View
    private lateinit var folderBox: View
    private lateinit var folderName: EditText
    private lateinit var folderList: RecyclerView

    private lateinit var workspace: WorkspaceAdapter
    private lateinit var drawerAdapter: AppAdapter
    private lateinit var folderAdapter: AppAdapter
    private lateinit var gestures: GestureDetector
    private lateinit var awm: AppWidgetManager
    private lateinit var widgetHost: AppWidgetHost
    private lateinit var glance: Glance
    private val widgetViews = HashMap<Int, AppWidgetHostView>()
    private val glassViews = ArrayList<View>()
    private var touchedGlass: View? = null
    private var drawerProgress = 0f
    private var drawerAnim: SpringAnimation? = null
    private var overlayLevel = 0f
    private var gestureMode = 0
    private var gStartX = 0f
    private var gStartY = 0f
    private var gArmed = false
    private var velocity: VelocityTracker? = null
    private var categoryFilter = "all"
    private var lastPingAt = 0L
    private val failedTries = HashMap<Int, Int>()
    private lateinit var widgetFactory: WidgetFactory
    private var widgetSheet: WidgetSheet? = null
    private var popItemId = -1L
    private val tmpLoc = IntArray(2)

    private var allApps = listOf<AppInfo>()
    private var appMap = HashMap<String, AppInfo>()
    private var visibleApps = listOf<AppInfo>()
    private var homeRows = 6

    private var drawerOpen = false
    private var shelfOpen = false
    private var editMode = false
    private var folderOpen = false
    private var drawerPrivate = false
    private var openFolderId = -1L
    private var unlockedOnce: String? = null

    private var launched = false
    private var lastRect: Rect? = null
    private var lastColor = Color.WHITE

    private var appliedSignature = ""
    private var appliedIconKey = ""
    private var syncTries = 0
    private var blurAnim: ValueAnimator? = null
    private var blurLevel = 0f
    private var drawerSpring: SpringAnimation? = null
    private var shelfSpring: SpringAnimation? = null
    private var torchOn = false
    private var lastWpId = -999
    private var lastBackdropAt = 0L

    private var drag: Drag? = null
    private var edgeDir = 0
    private var pageAddedByDrag = false

    private var pendingWidget: AppWidgetProviderInfo? = null
    private var pendingWidgetId = -1

    private var sensorManager: SensorManager? = null
    private var tiltX = 0f
    private var tiltY = 0f
    private var scrollBias = 0f
    private var dragSource: View? = null
    private var editSpringY: SpringAnimation? = null

    private val handler = Handler(Looper.getMainLooper())

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    // ---------- permission / picker launchers ----------
    private val pickWallpaper = registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) {
            val app = applicationContext
            thread {
                val ok = WallpaperHelper.setFromUri(app, uri)
                runOnUiThread {
                    toast(if (ok) "Wallpaper set" else "Could not set wallpaper")
                    refreshBackdrop(true)
                }
            }
        }
    }
    private val reqCalendar = registerForActivityResult(ActivityResultContracts.RequestPermission()) {
        if (::glance.isInitialized) glance.refreshNow()
    }
    private val reqContacts = registerForActivityResult(ActivityResultContracts.RequestPermission()) {
        if (::search.isInitialized) updateExtras(search.text.toString().trim())
    }

    private val pkgReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            loadApps()
        }
    }

    // If a launch silently failed, bring the home screen back
    private val restoreRunnable = Runnable {
        if (launched && hasWindowFocus()) {
            launched = false
            resetHome()
        }
    }

    private val badgeRunnable = Runnable {
        renderDock()
        workspace.notifyDataSetChanged()
        drawerAdapter.notifyDataSetChanged()
    }

    private val edgeRunnable = Runnable { edgeSwitch() }

    private val tiltListener = object : SensorEventListener {
        override fun onSensorChanged(e: SensorEvent) {
            val x = (-e.values[0] / 9.8f).coerceIn(-1f, 1f)
            val y = (e.values[1] / 9.8f).coerceIn(-1f, 1f)
            tiltX += (x - tiltX) * 0.1f
            tiltY += (y - tiltY) * 0.1f
            if (cfg.tilt) {
                clockBox.translationX = tiltX * dp(7)
                clockBox.translationY = -tiltY * dp(5)
                glanceBox.translationX = tiltX * dp(4)
                dockHolder.translationX = -tiltX * dp(5)
            }
            if (cfg.glassMotion && cfg.uiStyle == "glass") updateGlassShift()
        }

        override fun onAccuracyChanged(s: Sensor?, accuracy: Int) {}
    }

    // =====================================================================
    // Lifecycle
    // =====================================================================
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        PreferenceManager.setDefaultValues(this, R.xml.preferences, false)
        cfg = LauncherPrefs(this)
        store = LayoutStore(this)
        setContentView(R.layout.activity_main)

        root = findViewById(R.id.root)
        home = findViewById(R.id.home)
        clockBox = findViewById(R.id.clockBox)
        clockTime = findViewById(R.id.clockTime)
        clockDate = findViewById(R.id.clockDate)
        glanceBox = findViewById(R.id.glanceBox)
        searchPill = findViewById(R.id.searchPill)
        drawer = findViewById(R.id.drawer)
        categoryRow = findViewById(R.id.categoryRow)
        drawer.onProgress = { p ->
            drawerProgress = p
            // the dock melts into the drawer: its icons fade out as the glass grows
            dockHolder.alpha = 1f - (p * 5f).coerceIn(0f, 1f)
            updateBlur()
        }
        search = findViewById(R.id.search)
        searchExtras = findViewById(R.id.searchExtras)
        suggestRow = findViewById(R.id.suggestRow)
        alphaIndex = findViewById(R.id.alphaIndex)
        shelf = findViewById(R.id.shelf)
        shelfContent = findViewById(R.id.shelfContent)
        dockHolder = findViewById(R.id.dockHolder)
        dots = findViewById(R.id.dots)
        pager = findViewById(R.id.pager)
        overlay = findViewById(R.id.overlay)
        drawerList = findViewById(R.id.recycler)
        dragBar = findViewById(R.id.dragBar)
        editPanel = findViewById(R.id.editPanel)
        folderOverlay = findViewById(R.id.folderOverlay)
        folderBox = findViewById(R.id.folderBox)
        folderName = findViewById(R.id.folderName)
        folderList = findViewById(R.id.folderList)
        barZones = arrayOf(
            findViewById<TextView>(R.id.tInfo),
            findViewById<TextView>(R.id.tRemove),
            findViewById<TextView>(R.id.tUninstall)
        )

        awm = AppWidgetManager.getInstance(this)
        widgetHost = LauncherWidgetHost(this, 1024)

        glance = Glance(
            this, cfg,
            findViewById(R.id.glanceRow), findViewById(R.id.cardWeather),
            findViewById(R.id.cardBattery), findViewById(R.id.cardCalendar),
            findViewById(R.id.cardMusic), findViewById(R.id.musicArt),
            findViewById(R.id.musicTitle), findViewById(R.id.musicArtist),
            findViewById(R.id.musicPrev), findViewById(R.id.musicPlay), findViewById(R.id.musicNext)
        ) { reqCalendar.launch(Manifest.permission.READ_CALENDAR) }
        widgetFactory = WidgetFactory(this, glance) { name -> widgetAction(name) }

        // dock
        dockCell = CellLayout(this)
        dockCell.setPadding(dp(4), dp(4), dp(4), dp(4))
        dockHolder.addView(dockCell, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(88)))
        dockCell.setOnLongClickListener { enterEditMode(); true }

        // home pages
        workspace = WorkspaceAdapter { page, cell -> populate(cell, page) }
        pager.adapter = workspace
        pager.offscreenPageLimit = 2
        pager.addOnLayoutChangeListener { _, _, t, _, b, _, ot, _, ob ->
            if (b - t != ob - ot) onPagerResized()
        }
        pager.registerOnPageChangeCallback(object : ViewPager2.OnPageChangeCallback() {
            override fun onPageSelected(position: Int) {
                updateDots(position)
                pager.performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK)
            }

            override fun onPageScrolled(position: Int, positionOffset: Float, positionOffsetPixels: Int) {
                if (cfg.parallax && store.pageCount > 1) {
                    try {
                        WallpaperManager.getInstance(this@MainActivity).setWallpaperOffsets(
                            pager.windowToken, (position + positionOffset) / (store.pageCount - 1), 0.5f
                        )
                    } catch (e: Exception) {
                        // ignore
                    }
                }
            }
        })

        // drawer
        drawerAdapter = AppAdapter(cfg, ::launch) { app, v -> startAppDrag(app, v, -1L) }
        drawerList.layoutManager = GridLayoutManager(this, cfg.columns)
        drawerList.adapter = drawerAdapter
        searchPill.setOnClickListener { openDrawer() }
        findViewById<View>(R.id.gear).setOnClickListener { openSettings() }
        findViewById<View>(R.id.lockBtn).setOnClickListener {
            if (drawerPrivate) {
                drawerPrivate = false
                refreshLists()
            } else {
                authenticate("Private apps") {
                    drawerPrivate = true
                    refreshLists()
                    toast("Showing your hidden apps")
                }
            }
        }
        search.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) {
                refreshDrawerResults()
            }
        })
        search.setOnEditorActionListener { _, id, _ ->
            if (id == EditorInfo.IME_ACTION_GO) drawerAdapter.first()?.let { launch(it, search) }
            true
        }

        // A-Z fast scroll
        val letters = "ABCDEFGHIJKLMNOPQRSTUVWXYZ#"
        for (ch in letters) {
            val tv = TextView(this)
            tv.text = ch.toString()
            tv.textSize = 9f
            tv.setTextColor(0xB3FFFFFF.toInt())
            tv.gravity = Gravity.CENTER
            tv.layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(15))
            alphaIndex.addView(tv)
        }
        alphaIndex.setOnTouchListener { v, e ->
            val frac = (e.y / v.height).coerceIn(0f, 0.999f)
            val ch = letters[(frac * letters.length).toInt()]
            val pos = drawerAdapter.indexOfLetter(ch)
            if (pos >= 0) (drawerList.layoutManager as GridLayoutManager).scrollToPositionWithOffset(pos, 0)
            true
        }

        // folder popup
        folderAdapter = AppAdapter(cfg, ::launch) { app, v -> startAppDrag(app, v, openFolderId) }
        folderList.layoutManager = GridLayoutManager(this, 4)
        folderList.adapter = folderAdapter
        folderOverlay.setOnClickListener { closeFolder() }
        folderName.setOnEditorActionListener { _, id, _ ->
            if (id == EditorInfo.IME_ACTION_DONE) {
                saveFolderName()
                hideKeyboard(folderName)
            }
            true
        }

        // edit panel (long-press on empty home screen)
        findViewById<View>(R.id.eWallpaper).setOnClickListener { showWallpaperDialog() }
        findViewById<View>(R.id.eWidgets).setOnClickListener { showWidgetPicker() }
        findViewById<View>(R.id.eEffects).setOnClickListener { showThemesDialog() }
        findViewById<View>(R.id.ePages).setOnClickListener { showPagesDialog() }
        findViewById<View>(R.id.eTidy).setOnClickListener { showTidyDialog() }
        findViewById<View>(R.id.eSettings).setOnClickListener {
            exitEditMode()
            openSettings()
        }

        val quick = View.OnLongClickListener { enterEditMode(); true }
        clockBox.setOnLongClickListener(quick)
        searchPill.setOnLongClickListener(quick)
        dots.setOnLongClickListener(quick)

        // drag and drop
        root.setOnDragListener { _, e -> handleDrag(e) }

        // swipe gestures
        gestures = GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onDown(e: MotionEvent) = true

            override fun onDoubleTap(e: MotionEvent): Boolean {
                handleDoubleTap(e.rawX, e.rawY)
                return false
            }

            override fun onFling(e1: MotionEvent?, e2: MotionEvent, vx: Float, vy: Float): Boolean {
                if (e1 == null) return false
                val dy = e2.y - e1.y
                val dx = e2.x - e1.x
                if (shelfOpen) {
                    if (dx < -dp(80) && abs(dx) > abs(dy)) {
                        closeShelf()
                        return true
                    }
                    return false
                }
                if (cfg.shelf && dx > dp(90) && abs(dx) > abs(dy) * 1.5f && abs(vx) > 400 && pager.currentItem == 0) {
                    openShelf()
                    return true
                }
                if (abs(dy) < dp(60) || abs(dy) < abs(dx) * 1.5f || abs(vy) < 400) return false
                if (dy < 0) {
                    if (cfg.swipeUp && cfg.drawerGesture != "off") {
                        openDrawer()
                        return true
                    }
                } else {
                    when (cfg.swipeDown) {
                        "notifications" -> expandNotifications()
                        "search" -> openDrawer()
                    }
                    return true
                }
                return false
            }
        })

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                val sheet = widgetSheet
                when {
                    sheet != null && sheet.isShowing -> sheet.dismiss()
                    editMode -> exitEditMode()
                    folderOpen -> closeFolder()
                    shelfOpen -> closeShelf()
                    drawerOpen -> closeDrawer()
                }
            }
        })

        val filter = IntentFilter().apply {
            addAction(Intent.ACTION_PACKAGE_ADDED)
            addAction(Intent.ACTION_PACKAGE_REMOVED)
            addAction(Intent.ACTION_PACKAGE_REPLACED)
            addDataScheme("package")
        }
        ContextCompat.registerReceiver(this, pkgReceiver, filter, ContextCompat.RECEIVER_EXPORTED)

        applyConfigIfChanged()

        if (!cfg.p.getBoolean("onboarded", false)) {
            handler.postDelayed({ showWelcome() }, 800)
        }
        val crash = CrashLog.last(this)
        if (crash != null) handler.postDelayed({ showCrashDialog(crash) }, 1500)
    }

    override fun onStart() {
        super.onStart()
        try {
            widgetHost.startListening()
        } catch (e: Exception) {
            DiagLog.add("widgetHost.startListening failed: " + e)
        }
        Badges.listener = {
            handler.removeCallbacks(badgeRunnable)
            handler.postDelayed(badgeRunnable, 500)
        }
    }

    override fun onStop() {
        try {
            widgetHost.stopListening()
        } catch (e: Exception) {
            // ignore
        }
        Badges.listener = null
        super.onStop()
    }

    override fun onDestroy() {
        unregisterReceiver(pkgReceiver)
        super.onDestroy()
    }

    override fun dispatchTouchEvent(ev: MotionEvent): Boolean {
        if (handleDrawerGesture(ev)) return true
        if (!drawerOpen && !editMode && !folderOpen) gestures.onTouchEvent(ev)
        feedGlassTouch(ev)
        return super.dispatchTouchEvent(ev)
    }

    private fun springView(v: View, prop: DynamicAnimation.ViewProperty, target: Float, damping: Float) {
        val sa = SpringAnimation(v, prop, target)
        sa.spring.setStiffness(SpringForce.STIFFNESS_MEDIUM).setDampingRatio(damping)
        sa.start()
    }

    /** Glass panels light up under your finger and bulge a little towards it, then spring back like liquid. */
    private fun feedGlassTouch(ev: MotionEvent) {
        if (cfg.uiStyle != "glass") return
        when (ev.actionMasked) {
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_MOVE -> {
                val x = ev.rawX
                val y = ev.rawY
                var hit: View? = null
                for (v in glassViews) {
                    if (!v.isShown) continue
                    v.getLocationOnScreen(tmpLoc)
                    if (x >= tmpLoc[0] && x <= tmpLoc[0] + v.width && y >= tmpLoc[1] && y <= tmpLoc[1] + v.height) {
                        hit = v
                        break
                    }
                }
                val prev = touchedGlass
                if (prev != null && prev !== hit) releaseGlass(prev)
                if (hit != null) {
                    hit.getLocationOnScreen(tmpLoc)
                    val lx = x - tmpLoc[0]
                    val ly = y - tmpLoc[1]
                    (hit.background as? GlassDrawable)?.touch(lx, ly, true)
                    if (prev !== hit) {
                        hit.pivotX = lx
                        hit.pivotY = ly
                        val sx = (1f + dp(7).toFloat() / max(hit.width, 1)).coerceAtMost(1.06f)
                        val sy = (1f + dp(5).toFloat() / max(hit.height, 1)).coerceAtMost(1.07f)
                        springView(hit, DynamicAnimation.SCALE_X, sx, 0.6f)
                        springView(hit, DynamicAnimation.SCALE_Y, sy, 0.6f)
                    }
                }
                touchedGlass = hit
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                touchedGlass?.let { releaseGlass(it) }
                touchedGlass = null
            }
        }
    }

    private fun releaseGlass(v: View) {
        (v.background as? GlassDrawable)?.touch(0f, 0f, false)
        springView(v, DynamicAnimation.SCALE_X, 1f, 0.42f)
        springView(v, DynamicAnimation.SCALE_Y, 1f, 0.42f)
    }

    // Home button pressed while already on the launcher
    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        val sheet = widgetSheet
        when {
            sheet != null && sheet.isShowing -> sheet.dismiss()
            editMode -> exitEditMode()
            folderOpen -> closeFolder()
            shelfOpen -> closeShelf()
            drawerOpen -> closeDrawer()
            else -> pager.setCurrentItem(0, true)
        }
    }

    override fun onResume() {
        super.onResume()
        applyConfigIfChanged()
        refreshBlur()
        refreshBackdrop(false)
        if (drawerProgress <= 0.001f) dockHolder.alpha = 1f
        pingAllWidgets()
        if (cfg.showGlance) glance.start()
        updateTilt()
        home.removeCallbacks(restoreRunnable)
        if (!launched) {
            resetHome()
            return
        }
        launched = false
        if (cfg.closeAnim == "none") {
            resetHome()
            return
        }
        // Closing animation: home zooms back in, and a colour tile shrinks into the icon
        home.animate().cancel()
        home.scaleX = 1.08f
        home.scaleY = 1.08f
        home.alpha = 0f
        home.animate().scaleX(1f).scaleY(1f).alpha(1f)
            .setDuration(cfg.dur(320)).setInterpolator(DecelerateInterpolator()).withLayer().start()
        if (cfg.closeAnim == "shrink") playShrink()
    }

    override fun onPause() {
        glance.stop()
        sensorManager?.unregisterListener(tiltListener)
        super.onPause()
    }

    private fun resetHome() {
        home.animate().cancel()
        home.scaleX = 1f
        home.scaleY = 1f
        home.alpha = 1f - 0.65f * blurLevel
    }

    private fun setGlassShift(v: Float) {
        val c = v.coerceIn(-1f, 1f)
        if (abs(c - Glass.shift) > 0.01f) {
            Glass.shift = c
            invalidateGlass()
        }
    }

    private fun updateGlassShift() {
        setGlassShift(tiltX * 0.8f + scrollBias)
    }

    private fun updateTilt() {
        sensorManager?.unregisterListener(tiltListener)
        if (cfg.tilt || (cfg.glassMotion && cfg.uiStyle == "glass")) {
            val sm = getSystemService(Context.SENSOR_SERVICE) as SensorManager
            sensorManager = sm
            val s = sm.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)
            if (s != null) sm.registerListener(tiltListener, s, SensorManager.SENSOR_DELAY_UI)
        } else {
            tiltX = 0f
            tiltY = 0f
            Glass.shift = 0f
        }
        if (!cfg.tilt) {
            clockBox.translationX = 0f
            clockBox.translationY = 0f
            glanceBox.translationX = 0f
            dockHolder.translationX = 0f
        }
    }

    // =====================================================================
    // Settings, style and blur
    // =====================================================================
    private fun iconKey(): String = cfg.iconShape + "|" + cfg.iconTheme + "|" + cfg.iconPack

    private fun applyConfigIfChanged() {
        var force = false
        if (cfg.p.getBoolean("reset_layout_flag", false)) {
            cfg.p.edit().remove("reset_layout_flag").apply()
            store.reset()
            widgetViews.clear()
            force = true
        }
        if (cfg.p.getBoolean("restore_flag", false)) {
            cfg.p.edit().remove("restore_flag").apply()
            store = LayoutStore(this)
            widgetViews.clear()
            force = true
        }
        val sig = cfg.signature()
        if (sig == appliedSignature && !force) return
        appliedSignature = sig
        applyConfig()
        if (iconKey() != appliedIconKey) {
            appliedIconKey = iconKey()
            loadApps()
        } else {
            refreshLists()
            syncApps()
        }
    }

    private fun applyConfig() {
        val white = cfg.textColor == "white"
        val tc = if (white) Color.WHITE else Color.BLACK
        clockBox.visibility = if (cfg.showClock) View.VISIBLE else View.GONE
        clockTime.setTextColor(tc)
        clockDate.setTextColor(ColorUtils.setAlphaComponent(tc, 204))
        clockDate.typeface = LauncherPrefs.typeface(if (cfg.fontStyle == "default") "light" else cfg.fontStyle)
        if (white) {
            clockTime.setShadowLayer(8f, 0f, 2f, 0x66000000)
            clockDate.setShadowLayer(4f, 0f, 1f, 0x66000000)
        } else {
            clockTime.setShadowLayer(0f, 0f, 0f, 0)
            clockDate.setShadowLayer(0f, 0f, 0f, 0)
        }
        when (cfg.clockStyle) {
            "bold" -> {
                clockTime.typeface = Typeface.create("sans-serif-black", Typeface.NORMAL)
                clockTime.textSize = 56f
                clockTime.format12Hour = "hh:mm"
                clockTime.format24Hour = "HH:mm"
                clockTime.setLineSpacing(0f, 1f)
            }
            "stacked" -> {
                clockTime.typeface = Typeface.create("sans-serif-light", Typeface.NORMAL)
                clockTime.textSize = 72f
                clockTime.format12Hour = "hh\nmm"
                clockTime.format24Hour = "HH\nmm"
                clockTime.setLineSpacing(0f, 0.82f)
            }
            else -> {
                clockTime.typeface = Typeface.create("sans-serif-thin", Typeface.NORMAL)
                clockTime.textSize = 64f
                clockTime.format12Hour = "hh:mm"
                clockTime.format24Hour = "HH:mm"
                clockTime.setLineSpacing(0f, 1f)
            }
        }
        glanceBox.visibility = if (cfg.showGlance) View.VISIBLE else View.GONE
        if (cfg.showGlance) glance.start() else glance.stop()
        searchPill.visibility = if (cfg.showSearch) View.VISIBLE else View.GONE
        dots.visibility = if (cfg.showDots) View.VISIBLE else View.GONE
        dockHolder.visibility = if (cfg.showDock) View.VISIBLE else View.GONE
        applyStyle()
        (drawerList.layoutManager as GridLayoutManager).spanCount = cfg.columns
        pager.setPageTransformer(transformer(cfg.pageEffect))
        Backdrop.enabled = cfg.frosted
        updateTilt()
    }

    private fun glass(v: View, radiusDp: Float, strength: Int) {
        v.background = UiStyle.panel(this, cfg.uiStyle, radiusDp, strength, v)
        glassViews.add(v)
    }

    /** Dock, search bar, cards, panels and popups in the chosen style (liquid glass / Material You / classic). */
    private fun applyStyle() {
        glassViews.clear()
        val st = cfg.uiStyle
        val s = cfg.glassStrength
        glass(dockHolder, 32f, if (st == "classic") cfg.dockOpacity else s)
        glass(searchPill, 18f, s)
        glass(search, 24f, s)
        glass(findViewById(R.id.gear), 24f, s)
        glass(findViewById(R.id.lockBtn), 24f, s)
        glass(findViewById(R.id.cardWeather), 22f, s)
        glass(findViewById(R.id.cardBattery), 22f, s)
        glass(findViewById(R.id.cardCalendar), 22f, s)
        glass(findViewById(R.id.cardMusic), 26f, s)
        glass(dragBar, 24f, max(s, 40))
        glass(editPanel, 28f, max(s, 40))
        glass(folderBox, 34f, max(s, 45))
        glass(suggestRow, 24f, s)
        val blurSupported = cfg.blur && Build.VERSION.SDK_INT >= 31
        val drawerPct = if (st == "glass" && blurSupported) cfg.drawerOpacity * 45 / 100 else cfg.drawerOpacity
        drawer.scrimAlpha = drawerPct / 100f * 0.7f
        drawer.panel = UiStyle.panel(this, st, 34f, max(s, 55), drawer)
        shelf.setBackgroundColor(Color.argb(if (blurSupported) 120 else 238, 14, 16, 22))
    }

    private fun invalidateGlass() {
        for (v in glassViews) v.invalidate()
    }

    /** Builds (or refreshes) the blurred wallpaper that glass panels show behind themselves. */
    private fun refreshBackdrop(force: Boolean) {
        Glass.updateColors(this)
        Backdrop.enabled = cfg.frosted
        if (!cfg.frosted) {
            invalidateGlass()
            return
        }
        val wm = WallpaperManager.getInstance(this)
        val id = try {
            wm.getWallpaperId(WallpaperManager.FLAG_SYSTEM)
        } catch (e: Exception) {
            -1
        }
        val savedId = getSharedPreferences("backdrop", MODE_PRIVATE).getInt("bd_id", -2)
        val f = Backdrop.savedFile(this)
        if (f.exists() && id != savedId) f.delete() // wallpaper was changed outside this launcher
        val now = System.currentTimeMillis()
        if (!force && id == lastWpId && now - lastBackdropAt < 120_000L) return
        lastWpId = id
        lastBackdropAt = now
        val dm = resources.displayMetrics
        val app = applicationContext
        thread {
            Backdrop.rebuild(app, dm.widthPixels, dm.heightPixels)
            runOnUiThread { invalidateGlass() }
        }
    }

    /** Blurs the home screen (and the wallpaper, if the phone allows) while the drawer, shelf or a folder is open. */
    /** Folder and shelf fade the home screen in and out; the drawer does it through its own progress. */
    private fun refreshBlur() {
        val target = if (folderOpen || shelfOpen) 1f else 0f
        if (target == overlayLevel) return
        blurAnim?.cancel()
        val a = ValueAnimator.ofFloat(overlayLevel, target)
        a.duration = cfg.dur(260)
        a.addUpdateListener {
            overlayLevel = it.animatedValue as Float
            updateBlur()
        }
        blurAnim = a
        a.start()
    }

    private fun updateBlur() {
        applyBlurLevel(max(overlayLevel, drawerProgress.coerceIn(0f, 1f)))
    }

    private var lastBlurR = -1f

    private fun applyBlurLevel(level: Float) {
        blurLevel = level
        if (!launched) home.alpha = 1f - 0.5f * level
        clockBox.alpha = 1f - level
        glanceBox.alpha = 1f - level
        if (!cfg.blur || Build.VERSION.SDK_INT < 31) return
        val strength = cfg.drawerBlur / 60f
        // update in steps: a blur effect is expensive, so we only change it when it visibly changes
        val r = (Math.round(24f * level * strength / 2f) * 2).toFloat()
        if (r == lastBlurR) return
        lastBlurR = r
        home.setRenderEffect(
            if (r > 0.5f) RenderEffect.createBlurEffect(r, r, Shader.TileMode.CLAMP) else null
        )
        try {
            window.setBackgroundBlurRadius(Math.round(60f * level * strength / 8f) * 8)
        } catch (e: Exception) {
            // this phone does not allow window blur
        }
    }

    private fun transformer(effect: String): ViewPager2.PageTransformer? = when (effect) {
        "zoom" -> ViewPager2.PageTransformer { page, pos ->
            val d = abs(pos).coerceAtMost(1f)
            page.scaleX = 1f - 0.15f * d
            page.scaleY = 1f - 0.15f * d
            page.alpha = 1f - 0.5f * d
        }
        "fade" -> ViewPager2.PageTransformer { page, pos ->
            page.translationX = -page.width * pos
            page.alpha = 1f - abs(pos).coerceAtMost(1f)
        }
        "cube" -> ViewPager2.PageTransformer { page, pos ->
            page.cameraDistance = 12000f
            page.pivotX = if (pos < 0f) page.width.toFloat() else 0f
            page.pivotY = page.height * 0.5f
            page.rotationY = -60f * pos.coerceIn(-1f, 1f)
        }
        else -> ViewPager2.PageTransformer { page, _ ->
            page.scaleX = 1f
            page.scaleY = 1f
            page.alpha = 1f
            page.rotationY = 0f
            page.translationX = 0f
        }
    }

    private fun openSettings() {
        startActivity(Intent(this, SettingsActivity::class.java))
        if (drawerOpen) closeDrawer()
        if (shelfOpen) closeShelf()
    }

    private fun expandNotifications() {
        try {
            val sb = getSystemService("statusbar") ?: return
            sb.javaClass.getMethod("expandNotificationsPanel").invoke(sb)
        } catch (e: Exception) {
            // not supported on this phone
        }
    }

    private fun showCrashDialog(report: String) {
        if (isFinishing) return
        val preview = if (report.length > 1400) report.substring(0, 1400) + "\n..." else report
        AlertDialog.Builder(this)
            .setTitle("The launcher closed unexpectedly")
            .setMessage("Copy this report and send it so it can be fixed:\n\n" + preview)
            .setPositiveButton("Copy report") { _, _ ->
                (getSystemService(CLIPBOARD_SERVICE) as ClipboardManager)
                    .setPrimaryClip(ClipData.newPlainText("report", Diagnostics.report(this)))
                toast("Copied")
            }
            .setNegativeButton("Close", null)
            .setOnDismissListener { CrashLog.clear(this) }
            .show()
    }

    private fun showWidgetHelp() {
        AlertDialog.Builder(this)
            .setTitle("Widget not loading?")
            .setMessage(
                "1. Long-press the widget and choose Reload.\n\n" +
                    "2. Open the widget's own app once (for example Google), then come back.\n\n" +
                    "3. On Xiaomi / Redmi phones: Settings > Apps > Manage apps > the widget's app > " +
                    "turn on Autostart and set Battery saver to No restrictions. Do the same for Color Launcher.\n\n" +
                    "4. Settings > Widget compatibility: try the other two options, then Reload.\n\n" +
                    "The widgets built into this launcher (clock, weather, music, search ...) never need this."
            )
            .setPositiveButton("Launcher settings") { _, _ -> openAppInfo(packageName) }
            .setNegativeButton("Close", null)
            .show()
    }

    private fun showWelcome() {
        if (isFinishing) return
        cfg.p.edit().putBoolean("onboarded", true).apply()
        val names = Presets.names + "Keep the defaults"
        AlertDialog.Builder(this)
            .setTitle("Welcome to Color Launcher")
            .setMessage("Pick a look to start with. You can change everything later in Settings (long-press an empty spot on the home screen).")
            .setItems(names) { _, i ->
                if (i < Presets.names.size) {
                    Presets.apply(cfg.p, i)
                    applyConfigIfChanged()
                }
                AlertDialog.Builder(this)
                    .setTitle("Real frosted glass")
                    .setMessage("Android does not let a launcher read your wallpaper on its own. Pick your wallpaper image once here, and the glass panels will show a blurred copy of it behind them.")
                    .setPositiveButton("Choose wallpaper") { _, _ -> pickWallpaper.launch("image/*") }
                    .setNegativeButton("Later", null)
                    .show()
            }
            .show()
    }

    private fun showThemesDialog() {
        val names = arrayOf("Theme presets", "Page transition effect")
        AlertDialog.Builder(this).setItems(names) { _, w ->
            if (w == 0) {
                AlertDialog.Builder(this).setTitle("Theme presets").setItems(Presets.names) { _, i ->
                    Presets.apply(cfg.p, i)
                    applyConfigIfChanged()
                }.show()
            } else {
                showEffectDialog()
            }
        }.show()
    }

    private fun showWallpaperDialog() {
        val names = arrayOf("Choose from gallery (best for frosted glass)", "System wallpaper picker")
        AlertDialog.Builder(this).setTitle("Wallpaper").setItems(names) { _, w ->
            exitEditMode()
            if (w == 0) {
                pickWallpaper.launch("image/*")
            } else {
                startActivity(Intent.createChooser(Intent(Intent.ACTION_SET_WALLPAPER), "Wallpaper"))
            }
        }.show()
    }

    // =====================================================================
    // Loading apps and keeping the layout in sync
    // =====================================================================
    private fun loadApps() {
        val shape = cfg.iconShape
        val themed = cfg.iconTheme == "themed"
        val packName = cfg.iconPack
        thread {
            val pm = packageManager
            val pack = if (packName != "none") IconPacks.load(this, packName) else null
            val query = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
            val list = pm.queryIntentActivities(query, 0)
                .filter { it.activityInfo.packageName != packageName }
                .distinctBy { it.activityInfo.packageName }
                .map { ri ->
                    val pkg = ri.activityInfo.packageName
                    val installed = try {
                        pm.getPackageInfo(pkg, 0).firstInstallTime
                    } catch (e: Exception) {
                        0L
                    }
                    val packIcon = if (pack != null) IconPacks.icon(pack, ComponentName(pkg, ri.activityInfo.name)) else null
                    val cat = try {
                        pm.getApplicationInfo(pkg, 0).category
                    } catch (e: Exception) {
                        -1
                    }
                    AppInfo(
                        ri.loadLabel(pm).toString(), pkg,
                        styleIcon(ri.loadIcon(pm), shape, themed, packIcon), installed, cat
                    )
                }
                .sortedBy { it.label.lowercase() }
            runOnUiThread {
                allApps = list
                appMap = HashMap(list.associateBy { it.pkg })
                refreshLists()
                syncApps()
            }
        }
    }

    private fun categoryOf(a: AppInfo): String = when (a.category) {
        ApplicationInfo.CATEGORY_GAME -> "games"
        ApplicationInfo.CATEGORY_SOCIAL -> "social"
        ApplicationInfo.CATEGORY_AUDIO, ApplicationInfo.CATEGORY_VIDEO, ApplicationInfo.CATEGORY_IMAGE -> "media"
        ApplicationInfo.CATEGORY_PRODUCTIVITY, ApplicationInfo.CATEGORY_NEWS, ApplicationInfo.CATEGORY_MAPS -> "work"
        else -> "other"
    }

    private fun drawerSource(): List<AppInfo> {
        val base = if (drawerPrivate) allApps.filter { it.pkg in cfg.hiddenApps } else visibleApps
        if (categoryFilter == "all" || drawerPrivate) return base
        if (categoryFilter == "recent") {
            val used = Usage.recent(this, 12)
            val weekAgo = System.currentTimeMillis() - 10L * 24 * 3600 * 1000
            return base.filter { it.pkg in used || it.installTime > weekAgo }
                .sortedByDescending { max(it.installTime, if (it.pkg in used) Long.MAX_VALUE - used.indexOf(it.pkg) else 0L) }
        }
        return base.filter { categoryOf(it) == categoryFilter }
    }

    private fun renderCategories() {
        categoryRow.removeAllViews()
        if (drawerPrivate) return
        val labels = listOf("all" to "All", "recent" to "Recent", "games" to "Games", "social" to "Social",
            "media" to "Media", "work" to "Work", "other" to "Other")
        for ((key, label) in labels) {
            val has = key == "all" || key == "recent" || visibleApps.any { categoryOf(it) == key }
            if (!has) continue
            val chip = TextView(this)
            chip.text = label
            chip.textSize = 13f
            chip.setPadding(dp(16), dp(8), dp(16), dp(8))
            val sel = key == categoryFilter
            chip.setTextColor(if (sel) Color.BLACK else Color.WHITE)
            if (sel) {
                val g = GradientDrawable()
                g.cornerRadius = dp(20).toFloat()
                g.setColor(Color.argb(235, 255, 255, 255))
                chip.background = g
            } else {
                chip.background = UiStyle.panel(this, cfg.uiStyle, 20f, cfg.glassStrength, chip)
            }
            chip.setOnClickListener {
                categoryFilter = key
                refreshDrawerResults()
            }
            val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            lp.marginEnd = dp(8)
            categoryRow.addView(chip, lp)
        }
    }

    /** Apps shown in the drawer: hidden ones removed, sorted. */
    private fun refreshLists() {
        val hidden = cfg.hiddenApps
        val shown = allApps.filter { it.pkg !in hidden }
        visibleApps = when (cfg.sortOrder) {
            "newest" -> shown.sortedByDescending { it.installTime }
            "oldest" -> shown.sortedBy { it.installTime }
            else -> shown.sortedBy { it.label.lowercase() }
        }
        refreshDrawerResults()
    }

    private fun recomputeGrid() {
        val h = pager.height
        homeRows = if (cfg.rows != "auto") {
            cfg.rows.toInt()
        } else if (h == 0) {
            6
        } else {
            val rowDp = cfg.iconSize + 26 + (if (cfg.showLabels) (cfg.labelSize * 1.4f).toInt() else 0)
            max(3, h / dp(rowDp))
        }
    }

    private fun onPagerResized() {
        val oldRows = homeRows
        recomputeGrid()
        if (store.initialized && !store.edited && oldRows != homeRows && allApps.isNotEmpty()) {
            // nothing was customised yet, so just lay the apps out again for the new height
            store.reset()
            syncApps()
            return
        }
        if (store.initialized && allApps.isNotEmpty()) {
            normalize()
            store.save()
            renderAll()
        } else {
            syncApps()
        }
    }

    private fun defaultDockPackages(): List<String> {
        val intents = listOf(
            Intent(Intent.ACTION_DIAL),
            Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:")),
            Intent(Intent.ACTION_VIEW, Uri.parse("https://")),
            Intent(MediaStore.ACTION_IMAGE_CAPTURE)
        )
        val found = intents.mapNotNull {
            packageManager.resolveActivity(it, PackageManager.MATCH_DEFAULT_ONLY)?.activityInfo?.packageName
        }.filter { it != "android" }.distinct().toMutableList()
        // some phones answer the camera intent with a chooser, so also look for an app literally called Camera
        val cam = appMap.values.firstOrNull { it.label.equals("Camera", true) }?.pkg
        if (cam != null && cam !in found) found.add(cam)
        return found
    }

    private fun syncApps() {
        if (allApps.isEmpty()) return
        if (pager.height == 0 && syncTries < 20) {
            syncTries++
            pager.post { syncApps() }
            return
        }
        syncTries = 0
        recomputeGrid()
        val installed = allApps.map { it.pkg }.toSet()
        if (!store.initialized) {
            populateInitial()
        } else {
            // only drop apps that are really gone (never because of a half-finished app list)
            val gone = HashSet<String>()
            for (it in store.items) {
                if (it.type == APP) gone.add(it.pkg) else if (it.type == FOLDER) gone.addAll(it.children)
            }
            val stillThere = gone.filter { it !in installed && packageManager.getLaunchIntentForPackage(it) != null }
            store.removeMissing(installed + stillThere)
            if (cfg.homeMode == "standard" && cfg.autoAdd) {
                val hidden = cfg.hiddenApps
                for (a in allApps) {
                    if (a.pkg !in store.knownPkgs && a.pkg !in hidden) addToHome(a.pkg)
                }
            }
        }
        store.knownPkgs = installed.toMutableSet()
        ensureDock()
        normalize()
        store.save()
        renderAll()
    }

    /** If the dock is empty (and the user did not empty it on purpose), put the usual apps back. */
    private fun ensureDock() {
        if (!cfg.showDock || store.dockEmptyOk) return
        if (store.items.any { it.container == DOCK }) return
        val wanted = ArrayList<String>()
        for (p in defaultDockPackages()) {
            if (appMap.containsKey(p) && p !in wanted) wanted.add(p)
        }
        val patterns = listOf("phone|dialer", "messag|sms", "camera", "chrome|browser")
        for (pat in patterns) {
            val rx = Regex(pat)
            val hit = allApps.firstOrNull { rx.containsMatchIn(it.label.lowercase()) && it.pkg !in wanted }
            if (hit != null && wanted.size < cfg.dockCount) wanted.add(hit.pkg)
        }
        if (wanted.isEmpty()) {
            for (p in Usage.top(this, cfg.dockCount)) {
                if (appMap.containsKey(p)) wanted.add(p)
            }
        }
        var i = 0
        for (p in wanted.take(cfg.dockCount)) {
            store.items.removeAll { it.type == APP && it.container == HOME && it.pkg == p }
            store.removeFromFolders(p)
            store.items.add(Item(store.newId(), APP, DOCK, 0, i, 0, pkg = p))
            i++
        }
    }

    /** Remember that the user changed the layout. */
    private fun touched() {
        store.edited = true
        // the dock only counts as "emptied on purpose" when you remove its last icon yourself
        if (store.items.any { it.container == DOCK }) store.dockEmptyOk = false
    }

    private fun noteDockEmpty() {
        if (store.items.none { it.container == DOCK }) store.dockEmptyOk = true
    }

    private fun populateInitial() {
        val dockPkgs = defaultDockPackages().filter { appMap.containsKey(it) }.take(cfg.dockCount)
        dockPkgs.forEachIndexed { i, p ->
            store.items.add(Item(store.newId(), APP, DOCK, 0, i, 0, pkg = p))
        }
        if (cfg.homeMode == "standard") {
            val hidden = cfg.hiddenApps
            allApps.filter { it.pkg !in dockPkgs && it.pkg !in hidden }.forEach { addToHome(it.pkg) }
        }
        store.initialized = true
    }

    private fun addToHome(pkg: String) {
        var spot = store.findFree(0, 1, 1, cfg.columns, homeRows, -1L)
        if (spot == null) {
            store.pageCount++
            spot = intArrayOf(store.pageCount - 1, 0, 0)
        }
        store.items.add(Item(store.newId(), APP, HOME, spot[0], spot[1], spot[2], pkg = pkg))
    }

    /** Make sure everything fits the current grid. */
    private fun normalize() {
        val cols = cfg.columns
        val rows = homeRows
        store.cleanFolders()
        // widgets that no longer exist (for example after a restore on another phone)
        store.items.removeAll { it.type == WIDGET && it.widgetId >= 0 && awm.getAppWidgetInfo(it.widgetId) == null }
        for (item in store.items.toList()) {
            if (item.container == DOCK) {
                if (item.x >= cfg.dockCount || item.type == WIDGET) relocate(item, cols, rows)
            } else {
                if (item.type == WIDGET) {
                    item.spanX = min(item.spanX, cols)
                    item.spanY = min(item.spanY, rows)
                }
                if (item.x + item.spanX > cols || item.y + item.spanY > rows || item.page < 0) {
                    relocate(item, cols, rows)
                }
            }
        }
        val maxPage = store.items.filter { it.container == HOME }.maxOfOrNull { it.page } ?: 0
        if (store.pageCount < maxPage + 1) store.pageCount = maxPage + 1
    }

    private fun relocate(item: Item, cols: Int, rows: Int) {
        item.container = HOME
        var spot = store.findFree(0, item.spanX, item.spanY, cols, rows, item.id)
        if (spot == null) {
            store.pageCount++
            spot = intArrayOf(store.pageCount - 1, 0, 0)
        }
        item.page = spot[0]
        item.x = spot[1]
        item.y = spot[2]
    }

    // =====================================================================
    // Icons
    // =====================================================================
    private fun shapePath(shape: String, s: Float): Path {
        val p = Path()
        when (shape) {
            "circle" -> p.addCircle(s / 2, s / 2, s / 2, Path.Direction.CW)
            "square" -> p.addRoundRect(RectF(0f, 0f, s, s), s * 0.12f, s * 0.12f, Path.Direction.CW)
            "rounded" -> p.addRoundRect(RectF(0f, 0f, s, s), s * 0.30f, s * 0.30f, Path.Direction.CW)
            else -> { // squircle (superellipse)
                val steps = 80
                for (i in 0..steps) {
                    val t = 2 * PI * i / steps
                    val c = cos(t)
                    val sn = sin(t)
                    val x = s / 2 + s / 2 * sign(c) * abs(c).pow(0.5)
                    val y = s / 2 + s / 2 * sign(sn) * abs(sn).pow(0.5)
                    if (i == 0) p.moveTo(x.toFloat(), y.toFloat()) else p.lineTo(x.toFloat(), y.toFloat())
                }
                p.close()
            }
        }
        return p
    }

    /** Same shape for every app icon (or an icon pack's own artwork). */
    private fun styleIcon(src: Drawable, shape: String, themed: Boolean, packIcon: Drawable?): Drawable {
        val size = 192
        val s = size.toFloat()
        val content = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val c = Canvas(content)
        if (packIcon != null) {
            packIcon.setBounds(0, 0, size, size)
            packIcon.draw(c)
            return BitmapDrawable(resources, content)
        }
        if (shape == "original") {
            src.setBounds(0, 0, size, size)
            src.draw(c)
            return BitmapDrawable(resources, content)
        }
        if (src is AdaptiveIconDrawable) {
            val off = (s * 0.25f).toInt() // layers are 108dp, visible area 72dp
            val r = Rect(-off, -off, size + off, size + off)
            var mono: Drawable? = if (themed && Build.VERSION.SDK_INT >= 33) src.monochrome else null
            if (mono != null && !monoLooksOk(mono, r, size)) mono = null
            if (mono != null) {
                // Material You themed icon: tinted symbol on a wallpaper-colour tile
                // light tile + dark symbol: stays visible on the dark glass dock as well as on a bright wallpaper
                val tile = UiStyle.sys(this, android.R.color.system_accent1_200, 0xFFCDD2F0.toInt())
                val ink = UiStyle.sys(this, android.R.color.system_accent1_900, 0xFF1F2340.toInt())
                c.drawColor(tile)
                mono.setColorFilter(PorterDuffColorFilter(ink, PorterDuff.Mode.SRC_IN))
                mono.setBounds(r.left, r.top, r.right, r.bottom)
                mono.draw(c)
            } else {
                src.background?.apply { setBounds(r); draw(c) }
                src.foreground?.apply { setBounds(r); draw(c) }
            }
        } else {
            c.drawColor(0xFFF2F2F2.toInt())
            val inset = (s * 0.14f).toInt()
            src.setBounds(inset, inset, size - inset, size - inset)
            src.draw(c)
        }
        val out = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        paint.shader = BitmapShader(content, Shader.TileMode.CLAMP, Shader.TileMode.CLAMP)
        Canvas(out).drawPath(shapePath(shape, s), paint)
        content.recycle()
        return BitmapDrawable(resources, out)
    }

    /** Some apps ship a themed layer that is a solid block. Those would turn into a blank tile, so skip them. */
    private fun monoLooksOk(mono: Drawable, r: Rect, size: Int): Boolean {
        return try {
            val t = 48
            val bmp = Bitmap.createBitmap(t, t, Bitmap.Config.ARGB_8888)
            val c = Canvas(bmp)
            val k = t / size.toFloat()
            mono.setBounds((r.left * k).toInt(), (r.top * k).toInt(), (r.right * k).toInt(), (r.bottom * k).toInt())
            mono.draw(c)
            val px = IntArray(t * t)
            bmp.getPixels(px, 0, t, 0, 0, t, t)
            bmp.recycle()
            val transparent = px.count { (it ushr 24) < 24 }
            transparent > t * t * 0.12 && transparent < t * t * 0.995
        } catch (e: Exception) {
            false
        }
    }

    private fun averageColor(d: Drawable): Int {
        val b = (d as? BitmapDrawable)?.bitmap ?: return Color.WHITE
        val px = Bitmap.createScaledBitmap(b, 1, 1, true).getPixel(0, 0)
        return Color.rgb(Color.red(px), Color.green(px), Color.blue(px))
    }

    // =====================================================================
    // Drawing the home screen
    // =====================================================================
    private fun renderAll() {
        workspace.count = max(1, store.pageCount)
        workspace.notifyDataSetChanged()
        if (pager.currentItem >= workspace.count) pager.setCurrentItem(workspace.count - 1, false)
        rebuildDots()
        renderDock()
        try {
            WallpaperManager.getInstance(this).setWallpaperOffsetSteps(1f / max(1, store.pageCount - 1), 1f)
        } catch (e: Exception) {
            // ignore
        }
    }

    private fun startAllWiggles() {
        val cells = ArrayList<CellLayout>()
        for (i in 0 until workspace.cells.size()) cells.add(workspace.cells.valueAt(i))
        cells.add(dockCell)
        for (cell in cells) {
            for (i in 0 until cell.childCount) {
                val v = cell.getChildAt(i)
                if (v.findViewById<View>(R.id.icon) != null && (v.tag as? Animator)?.isRunning != true) startWiggle(v)
            }
        }
    }

    private fun stopAllWiggles() {
        for (i in 0 until workspace.cells.size()) cancelWiggles(workspace.cells.valueAt(i))
        cancelWiggles(dockCell)
    }

    private fun cancelWiggles(cell: CellLayout) {
        for (i in 0 until cell.childCount) {
            val v = cell.getChildAt(i)
            (v.tag as? Animator)?.cancel()
            v.rotation = 0f
        }
    }

    private fun populate(cell: CellLayout, page: Int) {
        cell.cols = cfg.columns
        cell.rows = homeRows
        cancelWiggles(cell)
        cell.removeAllViews()
        cell.setPadding(dp(4), dp(4), dp(4), dp(4))
        for (item in store.items) {
            if (item.container != HOME || item.page != page) continue
            val v = if (item.type == WIDGET) widgetView(item) else createItemView(item, false)
            if (v != null) {
                cell.addView(v, CellLayout.LP(item.x, item.y, item.spanX, item.spanY))
                if (item.id == popItemId) {
                    popItemId = -1L
                    popIn(v)
                }
            }
        }
        cell.setOnClickListener { if (editMode) exitEditMode() }
        cell.setOnLongClickListener { enterEditMode(); true }
    }

    private fun renderDock() {
        dockCell.cols = cfg.dockCount
        dockCell.rows = 1
        cancelWiggles(dockCell)
        dockCell.removeAllViews()
        for (item in store.items) {
            if (item.container != DOCK || item.x >= cfg.dockCount) continue
            val v = createItemView(item, true)
            if (v != null) dockCell.addView(v, CellLayout.LP(item.x, 0, 1, 1))
        }
    }

    private fun rebuildDots() {
        dots.removeAllViews()
        if (store.pageCount > 1) {
            for (i in 0 until store.pageCount) {
                dots.addView(ImageView(this).apply {
                    layoutParams = LinearLayout.LayoutParams(dp(14), dp(14))
                    scaleType = ImageView.ScaleType.CENTER
                })
            }
            updateDots(pager.currentItem)
        }
    }

    private fun updateDots(selected: Int) {
        for (i in 0 until dots.childCount) {
            (dots.getChildAt(i) as ImageView)
                .setImageResource(if (i == selected) R.drawable.dot_on else R.drawable.dot_off)
        }
    }

    private fun styleLabel(label: TextView, hide: Boolean) {
        label.visibility = if (hide || !cfg.showLabels) View.GONE else View.VISIBLE
        label.textSize = cfg.labelSize.toFloat()
        label.typeface = LauncherPrefs.typeface(cfg.fontStyle)
        if (cfg.textColor == "white") {
            label.setTextColor(Color.WHITE)
            label.setShadowLayer(4f, 0f, 1f, 0x80000000.toInt())
        } else {
            label.setTextColor(Color.BLACK)
            label.setShadowLayer(0f, 0f, 0f, 0)
        }
    }

    private fun startWiggle(v: View) {
        val a = ObjectAnimator.ofFloat(v, View.ROTATION, -1.8f, 1.8f)
        a.duration = (110 + Random.nextInt(40)).toLong()
        a.repeatCount = ValueAnimator.INFINITE
        a.repeatMode = ValueAnimator.REVERSE
        a.startDelay = Random.nextInt(80).toLong()
        v.tag = a
        a.start()
    }

    private fun createItemView(item: Item, inDock: Boolean): View? {
        val v = layoutInflater.inflate(R.layout.item_app, null, false)
        val icon = v.findViewById<ImageView>(R.id.icon)
        val label = v.findViewById<TextView>(R.id.label)
        val badge = v.findViewById<View>(R.id.badge)
        val px = dp(cfg.iconSize)
        icon.layoutParams = icon.layoutParams.apply {
            width = px
            height = px
        }
        when (item.type) {
            APP -> {
                if (item.pkg in cfg.hiddenApps) return null
                val app = appMap[item.pkg] ?: return null
                icon.setImageDrawable(app.icon)
                label.text = app.label
                badge.visibility = if (cfg.badges && Badges.count(app.pkg) > 0) View.VISIBLE else View.GONE
                v.setOnClickListener { launch(app, icon) }
            }
            FOLDER -> {
                val bitmaps = item.children.mapNotNull { (appMap[it]?.icon as? BitmapDrawable)?.bitmap }
                icon.setImageDrawable(FolderDrawable(bitmaps))
                label.text = if (item.title.isEmpty()) "Folder" else item.title
                val dot = cfg.badges && item.children.any { Badges.count(it) > 0 }
                badge.visibility = if (dot) View.VISIBLE else View.GONE
                v.setOnClickListener { openFolder(item, icon) }
            }
            else -> return null
        }
        styleLabel(label, inDock)
        v.pressFeedback(cfg.pressEffect)
        v.setOnLongClickListener { startItemDrag(item, v); true }
        if (editMode) startWiggle(v)
        return v
    }

    // =====================================================================
    // Widgets
    // =====================================================================
    private fun widgetContext(): Context = when (cfg.widgetCtx) {
        "themed" -> android.view.ContextThemeWrapper(this, android.R.style.Theme_DeviceDefault)
        "app" -> applicationContext
        else -> this
    }

    private fun widgetView(item: Item): View? {
        if (item.pkg.startsWith("builtin:")) {
            val bv = widgetFactory.create(item.pkg.removePrefix("builtin:")) ?: return null
            bv.setOnLongClickListener { startItemDrag(item, bv); true }
            return bv
        }
        val cached = widgetViews[item.widgetId]
        if (cached != null) {
            (cached.parent as? ViewGroup)?.removeView(cached)
            return cached
        }
        val info = awm.getAppWidgetInfo(item.widgetId)
        if (info == null) {
            DiagLog.add("widget " + item.widgetId + ": not bound, no info")
            return null
        }
        val hv = try {
            widgetHost.createView(widgetContext(), item.widgetId, info)
        } catch (e: Exception) {
            DiagLog.add("widget " + item.widgetId + ": createView failed: " + e)
            return null
        }
        DiagLog.add("widget " + item.widgetId + " " + info.provider.flattenToShortString() + " created, mode=" + cfg.widgetCtx)
        (hv as? LauncherWidgetHostView)?.onFailed = {
            DiagLog.add("widget " + item.widgetId + " could not draw its content (error view)")
            retryWidget(item.widgetId)
        }
        hv.setOnClickListener {
            if ((hv as? LauncherWidgetHostView)?.failed == true) reloadWidget(item)
        }
        hv.setOnLongClickListener { startItemDrag(item, hv); true }
        hv.addOnLayoutChangeListener { view, l, t, r, b, oldL, oldT, oldR, oldB ->
            if (r - l != oldR - oldL || b - t != oldB - oldT) {
                val d = resources.displayMetrics.density
                val w = ((r - l) / d).toInt()
                val h = ((b - t) / d).toInt()
                try {
                    (view as AppWidgetHostView).updateAppWidgetSize(Bundle(), w, h, w, h)
                } catch (e: Exception) {
                    // ignore
                }
            }
        }
        widgetViews[item.widgetId] = hv
        return hv
    }

    private fun widgetSpan(info: AppWidgetProviderInfo): IntArray {
        val cols = cfg.columns
        val cellW = max(1, (pager.width - dp(8)) / cols)
        val cellH = max(1, (pager.height - dp(8)) / homeRows)
        val sx = ceil(info.minWidth.toDouble() / cellW).toInt().coerceIn(1, cols)
        val sy = ceil(info.minHeight.toDouble() / cellH).toInt().coerceIn(1, homeRows)
        return intArrayOf(sx, sy)
    }

    private fun showWidgetPicker() {
        val sheet = WidgetSheet(
            this, root, cfg, widgetFactory, awm.installedProviders,
            { info -> widgetSpan(info) },
            { kind -> addBuiltin(kind) },
            { info -> addWidget(info) }
        )
        widgetSheet = sheet
        sheet.show()
    }

    private fun widgetAction(name: String) {
        when (name) {
            "torch" -> toggleTorch()
            "camera" -> tryStart(Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA))
            "calc" -> tryStart(Intent.makeMainSelectorActivity(Intent.ACTION_MAIN, Intent.CATEGORY_APP_CALCULATOR))
            "clock" -> tryStart(Intent(AlarmClock.ACTION_SHOW_ALARMS))
            "settings" -> tryStart(Intent(Settings.ACTION_SETTINGS))
            "calendar" -> tryStart(Intent.makeMainSelectorActivity(Intent.ACTION_MAIN, Intent.CATEGORY_APP_CALENDAR))
            "search" -> {
                val g = packageManager.getLaunchIntentForPackage("com.google.android.googlequicksearchbox")
                if (g != null) tryStart(g) else tryStart(Intent(Intent.ACTION_WEB_SEARCH))
            }
            "voice" -> tryStart(Intent(android.speech.RecognizerIntent.ACTION_WEB_SEARCH))
            "lens" -> {
                val l = packageManager.getLaunchIntentForPackage("com.google.ar.lens")
                if (l != null) tryStart(l) else tryStart(Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA))
            }
        }
    }

    private fun addBuiltin(kind: BuiltinKind) {
        placeWidgetItem(kind.spanX, kind.spanY, "builtin:" + kind.id, -2)
    }

    /** Size information that many widgets need before they can draw themselves. */
    private fun widgetOptions(sx: Int, sy: Int): Bundle {
        val d = resources.displayMetrics.density
        val cellW = max(1, (pager.width - dp(8)) / cfg.columns)
        val cellH = max(1, (pager.height - dp(8)) / homeRows)
        val w = (cellW * sx / d).toInt()
        val h = (cellH * sy / d).toInt()
        val b = Bundle()
        b.putInt(AppWidgetManager.OPTION_APPWIDGET_MIN_WIDTH, w)
        b.putInt(AppWidgetManager.OPTION_APPWIDGET_MIN_HEIGHT, h)
        b.putInt(AppWidgetManager.OPTION_APPWIDGET_MAX_WIDTH, w)
        b.putInt(AppWidgetManager.OPTION_APPWIDGET_MAX_HEIGHT, h)
        b.putInt(AppWidgetManager.OPTION_APPWIDGET_HOST_CATEGORY, AppWidgetProviderInfo.WIDGET_CATEGORY_HOME_SCREEN)
        if (Build.VERSION.SDK_INT >= 31) {
            b.putParcelableArrayList(AppWidgetManager.OPTION_APPWIDGET_SIZES, arrayListOf(android.util.SizeF(w.toFloat(), h.toFloat())))
        }
        return b
    }

    /** Ask the widget's app to send a fresh update (fixes "Couldn't add widget" for widgets that were still asleep). */
    private fun pingWidget(info: AppWidgetProviderInfo, id: Int) {
        try {
            val i = Intent(AppWidgetManager.ACTION_APPWIDGET_UPDATE)
            i.component = info.provider
            i.putExtra(AppWidgetManager.EXTRA_APPWIDGET_IDS, intArrayOf(id))
            sendBroadcast(i)
        } catch (e: Exception) {
            // ignore
        }
    }

    private fun reloadWidget(item: Item) {
        val info = awm.getAppWidgetInfo(item.widgetId)
        if (info != null) {
            try {
                awm.updateAppWidgetOptions(item.widgetId, widgetOptions(item.spanX, item.spanY))
            } catch (e: Exception) {
                // ignore
            }
            pingWidget(info, item.widgetId)
        }
        widgetViews.remove(item.widgetId)
        renderAll()
    }

    private fun retryWidget(id: Int) {
        val tries = failedTries[id] ?: 0
        if (tries >= 3) return
        failedTries[id] = tries + 1
        val info = awm.getAppWidgetInfo(id) ?: return
        handler.postDelayed({ pingWidget(info, id) }, 2500L * (tries + 1))
    }

    /** Asks every widget's app for a fresh update now and then, so none of them stay stuck on "loading". */
    private fun pingAllWidgets() {
        val now = System.currentTimeMillis()
        if (now - lastPingAt < 90_000L) return
        lastPingAt = now
        for (it in store.items) {
            if (it.type == WIDGET && it.widgetId >= 0) {
                val info = awm.getAppWidgetInfo(it.widgetId) ?: continue
                pingWidget(info, it.widgetId)
            }
        }
    }

    private fun popIn(v: View) {
        v.alpha = 0f
        v.scaleX = 0.7f
        v.scaleY = 0.7f
        v.animate().alpha(1f).setDuration(240L).start()
        springView(v, DynamicAnimation.SCALE_X, 1f, 0.55f)
        springView(v, DynamicAnimation.SCALE_Y, 1f, 0.55f)
    }

    @Suppress("DEPRECATION")
    private fun addWidget(info: AppWidgetProviderInfo) {
        val id = widgetHost.allocateAppWidgetId()
        pendingWidget = info
        pendingWidgetId = id
        val span = widgetSpan(info)
        val opts = widgetOptions(span[0], span[1])
        DiagLog.add("add widget " + info.provider.flattenToShortString() + " id=" + id + " " + span[0] + "x" + span[1])
        val bound = try {
            awm.bindAppWidgetIdIfAllowed(id, info.provider, opts)
        } catch (e: Exception) {
            DiagLog.add("bindAppWidgetIdIfAllowed threw: " + e)
            false
        }
        DiagLog.add("bindAppWidgetIdIfAllowed -> " + bound)
        if (bound) {
            afterBind(info, id)
        } else {
            val i = Intent(AppWidgetManager.ACTION_APPWIDGET_BIND)
            i.putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, id)
            i.putExtra(AppWidgetManager.EXTRA_APPWIDGET_PROVIDER, info.provider)
            i.putExtra(AppWidgetManager.EXTRA_APPWIDGET_OPTIONS, opts)
            try {
                startActivityForResult(i, REQ_BIND)
            } catch (e: Exception) {
                DiagLog.add("bind permission screen failed: " + e)
                toast("Could not ask for widget permission on this phone")
                cancelWidget(id)
            }
        }
    }

    @Suppress("DEPRECATION")
    private fun afterBind(info: AppWidgetProviderInfo, id: Int) {
        DiagLog.add("bound id=" + id + " configure=" + info.configure)
        if (info.configure != null) {
            try {
                widgetHost.startAppWidgetConfigureActivityForResult(this, id, 0, REQ_CONFIG, null)
            } catch (e: Exception) {
                DiagLog.add("configure screen failed: " + e + " (placing anyway)")
                placeWidget(info, id)
            }
        } else {
            placeWidget(info, id)
        }
    }

    @Suppress("DEPRECATION")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        val info = pendingWidget
        val id = pendingWidgetId
        if (requestCode == REQ_BIND) {
            DiagLog.add("widget permission result=" + resultCode)
            if (resultCode == RESULT_OK && info != null) {
                afterBind(info, id)
            } else {
                toast("The widget was not allowed. Tap Allow in the box that appears.")
                cancelWidget(id)
            }
        } else if (requestCode == REQ_CONFIG) {
            DiagLog.add("widget setup result=" + resultCode)
            if (resultCode == RESULT_OK && info != null) {
                placeWidget(info, id)
            } else {
                toast("Widget setup was cancelled")
                cancelWidget(id)
            }
        }
    }

    private fun cancelWidget(id: Int) {
        if (id != -1) {
            try {
                widgetHost.deleteAppWidgetId(id)
            } catch (e: Exception) {
                // ignore
            }
        }
        pendingWidget = null
        pendingWidgetId = -1
    }

    private fun placeWidget(info: AppWidgetProviderInfo, id: Int) {
        val span = widgetSpan(info)
        try {
            awm.updateAppWidgetOptions(id, widgetOptions(span[0], span[1]))
        } catch (e: Exception) {
            // ignore
        }
        pingWidget(info, id)
        pendingWidget = null
        pendingWidgetId = -1
        placeWidgetItem(span[0], span[1], "", id)
    }

    private fun placeWidgetItem(sx0: Int, sy0: Int, pkg: String, wid: Int) {
        val cols = cfg.columns
        val sx = min(sx0, cols)
        val sy = min(sy0, homeRows)
        var spot = store.findFree(pager.currentItem, sx, sy, cols, homeRows, -1L)
            ?: store.findFree(0, sx, sy, cols, homeRows, -1L)
        if (spot == null) {
            store.pageCount++
            spot = intArrayOf(store.pageCount - 1, 0, 0)
        }
        val item = Item(store.newId(), WIDGET, HOME, spot[0], spot[1], spot[2], sx, sy, pkg = pkg, widgetId = wid)
        store.items.add(item)
        popItemId = item.id
        touched()
        store.save()
        exitEditMode()
        renderAll()
        pager.setCurrentItem(spot[0], true)
    }

    // =====================================================================
    // Drag and drop
    // =====================================================================
    private fun startItemDrag(item: Item, v: View) {
        if (cfg.lockLayout) {
            showItemMenu(item, null)
            return
        }
        beginDrag(v, Drag(item, item.pkg, -1L))
    }

    private fun startAppDrag(app: AppInfo, v: View, fromFolder: Long) {
        if (cfg.lockLayout) {
            showAppMenu(app)
            return
        }
        beginDrag(v, Drag(null, app.pkg, fromFolder))
    }

    private fun beginDrag(v: View, d: Drag) {
        drag = d
        v.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
        val started = v.startDragAndDrop(ClipData.newPlainText("launcher", "item"), View.DragShadowBuilder(v), null, 0)
        if (started) {
            dragSource = v
            v.visibility = View.INVISIBLE
        } else {
            drag = null
        }
    }

    private fun handleDrag(e: DragEvent): Boolean {
        if (drag == null) return false
        when (e.action) {
            DragEvent.ACTION_DRAG_STARTED -> {
                onDragBegin()
                return true
            }
            DragEvent.ACTION_DRAG_LOCATION -> {
                onDragMove(e.x, e.y)
                return true
            }
            DragEvent.ACTION_DROP -> {
                onDragDrop(e.x, e.y)
                return true
            }
            DragEvent.ACTION_DRAG_ENDED -> {
                onDragEnd()
                return true
            }
        }
        return true
    }

    private fun rectOf(v: View): Rect {
        val l = IntArray(2)
        val r = IntArray(2)
        v.getLocationOnScreen(l)
        root.getLocationOnScreen(r)
        val x = l[0] - r[0]
        val y = l[1] - r[1]
        return Rect(x, y, x + v.width, y + v.height)
    }

    private fun itemRect(item: Item): Rect? {
        val cell = if (item.container == DOCK) dockCell else (workspace.cells.get(item.page) ?: return null)
        val pr = rectOf(cell)
        val r = cell.cellRect(item.x, item.y, item.spanX, item.spanY)
        return Rect(pr.left + r.left, pr.top + r.top, pr.left + r.right, pr.top + r.bottom)
    }

    private fun onDragBegin() {
        dragBar.alpha = 0f
        dragBar.visibility = View.VISIBLE
        dragBar.animate().alpha(1f).setDuration(150).start()
        if (drawerOpen) closeDrawer()
        if (folderOpen) closeFolder()
        if (shelfOpen) closeShelf()
    }

    private fun zoneAt(x: Float): Int {
        val r = rectOf(dragBar)
        return ((x - r.left) / (r.width() / 3f)).toInt().coerceIn(0, 2)
    }

    private fun highlightBar(zone: Int) {
        for (i in barZones.indices) {
            barZones[i].setBackgroundColor(if (i == zone) 0x55FFFFFF else 0x00000000)
        }
    }

    private fun clearHints() {
        for (i in 0 until workspace.cells.size()) workspace.cells.valueAt(i).clearHint()
        dockCell.clearHint()
    }

    private fun targetAt(x: Float, y: Float): Target? {
        val ix = x.toInt()
        val iy = y.toInt()
        if (dockHolder.visibility == View.VISIBLE) {
            val r = rectOf(dockCell)
            if (r.contains(ix, iy)) {
                val c = dockCell.cellAt(x - r.left, y - r.top)
                return Target(dockCell, DOCK, 0, c[0], 0)
            }
        }
        val pr = rectOf(pager)
        if (pr.contains(ix, iy)) {
            val page = pager.currentItem
            val cl = workspace.cells.get(page) ?: return null
            val c = cl.cellAt(x - pr.left, y - pr.top)
            return Target(cl, HOME, page, c[0], c[1])
        }
        return null
    }

    private fun onDragMove(x: Float, y: Float) {
        val d = drag ?: return
        clearHints()
        val bar = rectOf(dragBar)
        if (bar.contains(x.toInt(), y.toInt())) {
            highlightBar(zoneAt(x))
            setEdge(0)
            return
        }
        highlightBar(-1)

        val pr = rectOf(pager)
        val edge = dp(32)
        val dir = if (y < pr.top || y > pr.bottom) 0 else if (x < edge) -1 else if (x > root.width - edge) 1 else 0
        setEdge(dir)

        val t = targetAt(x, y) ?: return
        val moving = d.item
        val sx = moving?.spanX ?: 1
        val sy = moving?.spanY ?: 1
        val type = moving?.type ?: APP
        val existingApp = if (moving == null && d.fromFolder == -1L) store.findApp(d.pkg) else null
        val ignoreId = moving?.id ?: existingApp?.id ?: -1L
        val occ = store.itemAt(t.container, t.page, t.cx, t.cy, ignoreId)
        if (type == APP && occ != null && (occ.type == APP || occ.type == FOLDER) && occ.pkg != d.pkg) {
            t.cell.showHint(occ.x, occ.y, 1, 1, true)
        } else {
            val cx = min(t.cx, t.cell.cols - sx).coerceAtLeast(0)
            val cy = min(t.cy, t.cell.rows - sy).coerceAtLeast(0)
            t.cell.showHint(cx, cy, sx, sy, false)
        }
    }

    private fun setEdge(dir: Int) {
        if (dir == edgeDir) return
        handler.removeCallbacks(edgeRunnable)
        edgeDir = dir
        if (dir != 0) handler.postDelayed(edgeRunnable, 650)
    }

    private fun edgeSwitch() {
        if (edgeDir == 0) return
        val cur = pager.currentItem
        if (edgeDir == 1) {
            if (cur == store.pageCount - 1) {
                store.pageCount++
                pageAddedByDrag = true
                workspace.count = store.pageCount
                workspace.notifyDataSetChanged()
                rebuildDots()
            }
            pager.setCurrentItem(cur + 1, true)
        } else if (cur > 0) {
            pager.setCurrentItem(cur - 1, true)
        }
        handler.postDelayed(edgeRunnable, 900)
    }

    private fun onDragDrop(x: Float, y: Float) {
        val d = drag ?: return
        setEdge(0)
        val bar = rectOf(dragBar)
        if (bar.contains(x.toInt(), y.toInt())) {
            dropOnBar(d, zoneAt(x))
            return
        }
        val t = targetAt(x, y) ?: return
        val moving = d.item
        val sx = moving?.spanX ?: 1
        val sy = moving?.spanY ?: 1
        val type = moving?.type ?: APP
        val existingApp = if (moving == null && d.fromFolder == -1L) store.findApp(d.pkg) else null
        val ignoreId = moving?.id ?: existingApp?.id ?: -1L
        val cols = t.cell.cols
        val rows = t.cell.rows

        if (type == WIDGET && t.container == DOCK) {
            toast("Widgets can't go in the dock")
            return
        }

        // released on its own spot: it was just a long-press -> show the menu
        if (moving != null && moving.container == t.container &&
            (t.container == DOCK || moving.page == t.page) &&
            t.cx >= moving.x && t.cx < moving.x + moving.spanX &&
            t.cy >= moving.y && t.cy < moving.y + moving.spanY
        ) {
            showItemMenu(moving, itemRect(moving))
            return
        }

        val occ = store.itemAt(t.container, t.page, t.cx, t.cy, ignoreId)

        // dropped on another app or a folder: make or fill a folder
        if (type == APP && occ != null && (occ.type == APP || occ.type == FOLDER) && occ.pkg != d.pkg) {
            if (moving == null) {
                store.items.removeAll { it.type == APP && it.pkg == d.pkg && it !== occ }
                for (f in store.items) {
                    if (f.type == FOLDER && f !== occ) f.children.remove(d.pkg)
                }
            }
            detach(d)
            if (occ.type == FOLDER) {
                if (!occ.children.contains(d.pkg)) occ.children.add(d.pkg)
            } else {
                val first = occ.pkg
                occ.type = FOLDER
                occ.pkg = ""
                occ.title = "Folder"
                occ.children = mutableListOf(first, d.pkg)
            }
            finishDrop()
            return
        }

        // normal move: find a free spot
        var page = t.page
        val cx = min(t.cx, cols - sx).coerceAtLeast(0)
        val cy = min(t.cy, rows - sy).coerceAtLeast(0)
        var spot: IntArray? = if (store.isFree(t.container, page, cx, cy, sx, sy, cols, rows, ignoreId)) {
            intArrayOf(cx, cy)
        } else {
            store.findNear(t.container, page, cx, cy, sx, sy, cols, rows, ignoreId)
        }
        if (spot == null && t.container == HOME) {
            var p = page + 1
            while (spot == null && p < store.pageCount) {
                val s = store.findNear(HOME, p, 0, 0, sx, sy, cols, rows, ignoreId)
                if (s != null) {
                    spot = s
                    page = p
                }
                p++
            }
            if (spot == null) {
                store.pageCount++
                page = store.pageCount - 1
                spot = intArrayOf(0, 0)
            }
        }
        if (spot == null) {
            toast("No space here")
            return
        }
        val newPage = if (t.container == DOCK) 0 else page
        if (moving != null) {
            moving.container = t.container
            moving.page = newPage
            moving.x = spot[0]
            moving.y = spot[1]
        } else {
            detach(d)
            store.removeFromFolders(d.pkg)
            if (existingApp != null) {
                existingApp.container = t.container
                existingApp.page = newPage
                existingApp.x = spot[0]
                existingApp.y = spot[1]
            } else {
                store.items.add(Item(store.newId(), APP, t.container, newPage, spot[0], spot[1], pkg = d.pkg))
            }
        }
        finishDrop()
    }

    /** Take the dragged thing out of where it came from. */
    private fun detach(d: Drag) {
        val m = d.item
        if (m != null) store.items.remove(m)
        if (d.fromFolder != -1L) {
            store.items.firstOrNull { it.id == d.fromFolder }?.children?.remove(d.pkg)
        }
    }

    private fun finishDrop() {
        store.cleanFolders()
        touched()
        store.save()
    }

    private fun dropOnBar(d: Drag, zone: Int) {
        val m = d.item
        val isApp = m == null || m.type == APP
        when (zone) {
            0 -> if (isApp) openAppInfo(d.pkg)
            1 -> removeDragged(d)
            2 -> if (isApp) uninstall(d.pkg)
        }
    }

    private fun removeDragged(d: Drag) {
        val m = d.item
        if (m != null) {
            if (m.type == WIDGET && m.widgetId >= 0) {
                widgetHost.deleteAppWidgetId(m.widgetId)
                widgetViews.remove(m.widgetId)
            }
            store.items.remove(m)
        } else if (d.fromFolder != -1L) {
            store.items.firstOrNull { it.id == d.fromFolder }?.children?.remove(d.pkg)
        } else {
            store.items.removeAll { it.type == APP && it.pkg == d.pkg }
        }
        noteDockEmpty()
        finishDrop()
    }

    private fun onDragEnd() {
        setEdge(0)
        dragBar.visibility = View.GONE
        highlightBar(-1)
        clearHints()
        drag = null
        dragSource?.visibility = View.VISIBLE
        dragSource = null
        if (pageAddedByDrag) {
            pageAddedByDrag = false
            store.trimTrailingPages()
        }
        store.save()
        renderAll()
    }

    // =====================================================================
    // Menus
    // =====================================================================
    private fun openAppInfo(pkg: String) {
        startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$pkg")))
    }

    private fun uninstall(pkg: String) {
        startActivity(Intent(Intent.ACTION_DELETE, Uri.parse("package:$pkg")))
    }

    private fun hideApp(pkg: String) {
        cfg.p.edit().putStringSet("hidden_apps", cfg.hiddenApps + pkg).apply()
        applyConfigIfChanged()
    }

    /** Shortcuts the app offers itself (for example Camera -> Selfie). Works because we are the home app. */
    private fun shortcutEntries(pkg: String): List<Pair<String, () -> Unit>> {
        val out = mutableListOf<Pair<String, () -> Unit>>()
        try {
            val la = getSystemService(Context.LAUNCHER_APPS_SERVICE) as LauncherApps
            if (!la.hasShortcutHostPermission()) return out
            val q = LauncherApps.ShortcutQuery()
            q.setPackage(pkg)
            q.setQueryFlags(
                LauncherApps.ShortcutQuery.FLAG_MATCH_DYNAMIC or
                    LauncherApps.ShortcutQuery.FLAG_MATCH_MANIFEST or
                    LauncherApps.ShortcutQuery.FLAG_MATCH_PINNED
            )
            val list = la.getShortcuts(q, Process.myUserHandle()) ?: return out
            for (s in list.filter { it.isEnabled }.take(4)) {
                val label = (s.shortLabel ?: s.id).toString()
                out.add(Pair(label, {
                    try {
                        la.startShortcut(s, null, null)
                    } catch (e: Exception) {
                        // ignore
                    }
                }))
            }
        } catch (e: Exception) {
            // ignore
        }
        return out
    }

    private fun showAppMenu(app: AppInfo) {
        val entries = mutableListOf<Pair<String, () -> Unit>>()
        entries.addAll(shortcutEntries(app.pkg))
        entries.add(Pair("App info", { openAppInfo(app.pkg) }))
        entries.add(Pair("Uninstall", { uninstall(app.pkg) }))
        entries.add(Pair("Hide app", { hideApp(app.pkg) }))
        showEntries(app.label, entries)
    }

    private fun showItemMenu(item: Item, anchor: Rect?) {
        val entries = mutableListOf<Pair<String, () -> Unit>>()
        var title = "Widget"
        when (item.type) {
            APP -> {
                title = appMap[item.pkg]?.label ?: item.pkg
                entries.addAll(shortcutEntries(item.pkg))
                entries.add(Pair("App info", { openAppInfo(item.pkg) }))
                entries.add(Pair("Uninstall", { uninstall(item.pkg) }))
                entries.add(Pair("Hide app", { hideApp(item.pkg) }))
                if (!cfg.lockLayout) entries.add(Pair("Remove from home screen", { removeItem(item) }))
            }
            FOLDER -> {
                title = if (item.title.isEmpty()) "Folder" else item.title
                entries.add(Pair("Open", { openFolder(item, null) }))
                if (!cfg.lockLayout) entries.add(Pair("Dissolve folder", { dissolveFolder(item) }))
            }
            WIDGET -> {
                if (item.widgetId >= 0) {
                    entries.add(Pair("Reload widget", { reloadWidget(item) }))
                    val wp = awm.getAppWidgetInfo(item.widgetId)?.provider?.packageName
                    if (wp != null) entries.add(Pair("Widget app settings", { openAppInfo(wp) }))
                    entries.add(Pair("Widget not loading?", { showWidgetHelp() }))
                }
                if (!cfg.lockLayout) entries.add(Pair("Remove widget", { removeItem(item) }))
            }
        }
        showPopupMenu(anchor ?: itemRect(item), title, entries)
    }

    private fun showEntries(title: String, entries: List<Pair<String, () -> Unit>>) {
        if (entries.isEmpty()) return
        AlertDialog.Builder(this)
            .setTitle(title)
            .setItems(entries.map { it.first }.toTypedArray()) { _, i -> entries[i].second() }
            .show()
    }

    /** Small glass menu next to the icon. Falls back to a normal dialog if we don't know where the icon is. */
    private fun showPopupMenu(anchor: Rect?, title: String, entries: List<Pair<String, () -> Unit>>) {
        if (entries.isEmpty()) return
        if (anchor == null) {
            showEntries(title, entries)
            return
        }
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(dp(6), dp(8), dp(6), dp(8))
        box.background = UiStyle.panel(this, cfg.uiStyle, 22f, max(cfg.glassStrength, 55), box)
        val popup = PopupWindow(box, ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, true)
        popup.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        popup.elevation = dp(8).toFloat()
        if (title.isNotEmpty()) {
            val t = TextView(this)
            t.text = title
            t.setTextColor(0xB3FFFFFF.toInt())
            t.textSize = 12f
            t.setPadding(dp(14), dp(4), dp(14), dp(6))
            box.addView(t)
        }
        for ((label, action) in entries) {
            val row = TextView(this)
            row.text = label
            row.setTextColor(Color.WHITE)
            row.textSize = 15f
            row.setPadding(dp(14), dp(10), dp(28), dp(10))
            row.setOnClickListener {
                popup.dismiss()
                action()
            }
            box.addView(row)
        }
        box.measure(View.MeasureSpec.UNSPECIFIED, View.MeasureSpec.UNSPECIFIED)
        val w = box.measuredWidth
        val h = box.measuredHeight
        val x = (anchor.centerX() - w / 2).coerceIn(dp(8), max(dp(8), root.width - w - dp(8)))
        var y = anchor.top - h - dp(6)
        if (y < dp(40)) y = anchor.bottom + dp(6)
        val rl = IntArray(2)
        root.getLocationOnScreen(rl)
        popup.showAtLocation(root, Gravity.NO_GRAVITY, rl[0] + x, rl[1] + y)
    }

    private fun removeItem(item: Item) {
        if (item.type == WIDGET && item.widgetId >= 0) {
            widgetHost.deleteAppWidgetId(item.widgetId)
            widgetViews.remove(item.widgetId)
        }
        store.items.remove(item)
        store.cleanFolders()
        touched()
        noteDockEmpty()
        store.save()
        renderAll()
    }

    private fun dissolveFolder(item: Item) {
        val pkgs = item.children.toList()
        store.items.remove(item)
        for (p in pkgs) addToHome(p)
        normalize()
        touched()
        store.save()
        renderAll()
    }

    // =====================================================================
    // Folders
    // =====================================================================
    private fun openFolder(item: Item, from: View?) {
        openFolderId = item.id
        folderOpen = true
        folderName.setText(item.title)
        val apps = item.children.mapNotNull { appMap[it] }
        folderAdapter.submit(apps)
        val rows = ceil(apps.size / 4.0).toInt().coerceAtLeast(1)
        val lp = folderList.layoutParams
        lp.height = min(rows * dp(100), dp(420))
        folderList.layoutParams = lp
        folderBox.scaleX = 1f
        folderBox.scaleY = 1f
        folderBox.translationX = 0f
        folderBox.translationY = 0f
        folderOverlay.alpha = 0f
        folderOverlay.visibility = View.VISIBLE
        folderOverlay.animate().alpha(1f).setDuration(cfg.dur(160)).start()
        folderOverlay.performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK)
        if (from != null) {
            // grow out of the folder icon
            folderBox.alpha = 0f
            folderBox.post {
                val a = rectOf(from)
                val b = rectOf(folderBox)
                folderBox.translationX = (a.centerX() - b.centerX()).toFloat()
                folderBox.translationY = (a.centerY() - b.centerY()).toFloat()
                folderBox.scaleX = 0.25f
                folderBox.scaleY = 0.25f
                folderBox.alpha = 1f
                for (prop in arrayOf(DynamicAnimation.SCALE_X, DynamicAnimation.SCALE_Y)) {
                    val sa = SpringAnimation(folderBox, prop, 1f)
                    sa.spring.setStiffness(SpringForce.STIFFNESS_LOW).setDampingRatio(0.68f)
                    sa.start()
                }
                for (prop in arrayOf(DynamicAnimation.TRANSLATION_X, DynamicAnimation.TRANSLATION_Y)) {
                    val sa = SpringAnimation(folderBox, prop, 0f)
                    sa.spring.setStiffness(SpringForce.STIFFNESS_LOW).setDampingRatio(0.8f)
                    sa.start()
                }
            }
        } else {
            folderBox.alpha = 1f
            folderBox.scaleX = 0.8f
            folderBox.scaleY = 0.8f
            for (prop in arrayOf(DynamicAnimation.SCALE_X, DynamicAnimation.SCALE_Y)) {
                val sa = SpringAnimation(folderBox, prop, 1f)
                sa.spring.setStiffness(SpringForce.STIFFNESS_LOW).setDampingRatio(0.62f)
                sa.start()
            }
        }
        refreshBlur()
    }

    private fun saveFolderName() {
        val f = store.items.firstOrNull { it.id == openFolderId } ?: return
        val t = folderName.text.toString().trim()
        if (t != f.title) {
            f.title = t
            store.save()
            renderDock()
            workspace.notifyDataSetChanged()
        }
    }

    private fun closeFolder() {
        if (!folderOpen) return
        saveFolderName()
        hideKeyboard(folderName)
        folderOpen = false
        refreshBlur()
        folderOverlay.animate().alpha(0f).setDuration(cfg.dur(140))
            .withEndAction { folderOverlay.visibility = View.GONE }.start()
    }

    private fun hideKeyboard(v: View) {
        (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager).hideSoftInputFromWindow(v.windowToken, 0)
    }

    // =====================================================================
    // Edit mode (long-press on empty home screen)
    // =====================================================================
    private fun enterEditMode() {
        if (editMode || drag != null) return
        editMode = true
        // the panel sits right above the dock, so the dock stays visible
        val lp = editPanel.layoutParams as FrameLayout.LayoutParams
        lp.bottomMargin = if (cfg.showDock && dockHolder.height > 0) {
            root.height - rectOf(dockHolder).top + dp(10)
        } else {
            dp(80)
        }
        editPanel.layoutParams = lp
        editPanel.animate().cancel()
        editSpringY?.cancel()
        editPanel.visibility = View.VISIBLE
        editPanel.alpha = 0f
        editPanel.translationY = dp(70).toFloat()
        editPanel.scaleX = 0.9f
        editPanel.scaleY = 0.9f
        editPanel.animate().alpha(1f).setDuration(cfg.dur(200)).start()
        val sy = SpringAnimation(editPanel, DynamicAnimation.TRANSLATION_Y, 0f)
        sy.spring.setStiffness(SpringForce.STIFFNESS_LOW).setDampingRatio(0.66f)
        editSpringY = sy
        sy.start()
        for (prop in arrayOf(DynamicAnimation.SCALE_X, DynamicAnimation.SCALE_Y)) {
            val sa = SpringAnimation(editPanel, prop, 1f)
            sa.spring.setStiffness(SpringForce.STIFFNESS_LOW).setDampingRatio(0.6f)
            sa.start()
        }
        // the buttons pop in one after another
        val group = editPanel as ViewGroup
        for (i in 0 until group.childCount) {
            val c = group.getChildAt(i)
            c.animate().cancel()
            c.alpha = 0f
            c.translationY = dp(16).toFloat()
            c.animate().alpha(1f).translationY(0f)
                .setStartDelay(cfg.dur(60L + 45L * i)).setDuration(cfg.dur(260))
                .setInterpolator(DecelerateInterpolator()).start()
        }
        editPanel.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
        startAllWiggles()
    }

    private fun exitEditMode() {
        if (!editMode) return
        editMode = false
        editSpringY?.cancel()
        editPanel.animate().cancel()
        editPanel.animate().alpha(0f).translationY(dp(50).toFloat()).setDuration(cfg.dur(180))
            .withEndAction {
                editPanel.visibility = View.GONE
                editPanel.translationY = 0f
            }.start()
        stopAllWiggles()
    }

    private fun showEffectDialog() {
        val values = arrayOf("slide", "zoom", "fade", "cube")
        val names = arrayOf("Slide", "Zoom", "Fade", "Cube")
        val cur = values.indexOf(cfg.pageEffect).coerceAtLeast(0)
        AlertDialog.Builder(this)
            .setTitle("Page transition effect")
            .setSingleChoiceItems(names, cur) { dlg, which ->
                cfg.p.edit().putString("page_effect", values[which]).apply()
                applyConfigIfChanged()
                dlg.dismiss()
            }
            .show()
    }

    private fun showPagesDialog() {
        val names = arrayOf("Add page", "Delete this page (only if empty)")
        AlertDialog.Builder(this).setItems(names) { _, w ->
            if (w == 0) {
                store.pageCount++
                touched()
                store.save()
                renderAll()
                pager.setCurrentItem(store.pageCount - 1, true)
            } else {
                deleteCurrentPage()
            }
        }.show()
    }

    private fun deleteCurrentPage() {
        val p = pager.currentItem
        if (store.pageCount <= 1) {
            toast("At least one page is needed")
            return
        }
        if (store.items.any { it.container == HOME && it.page == p }) {
            toast("Move or remove everything on this page first")
            return
        }
        for (i in store.items) {
            if (i.container == HOME && i.page > p) i.page--
        }
        store.pageCount--
        touched()
        store.save()
        renderAll()
    }

    private fun showTidyDialog() {
        val names = arrayOf("Close gaps", "Sort A to Z", "Newest first")
        AlertDialog.Builder(this).setTitle("Tidy up home screen").setItems(names) { _, w ->
            tidy(w)
            exitEditMode()
        }.show()
    }

    private fun labelOf(i: Item): String =
        if (i.type == FOLDER) i.title else (appMap[i.pkg]?.label ?: i.pkg)

    private fun tidy(mode: Int) {
        val cols = cfg.columns
        val rows = homeRows
        val movable = store.items.filter { it.container == HOME && it.type != WIDGET }
        val sorted = when (mode) {
            1 -> movable.sortedBy { labelOf(it).lowercase() }
            2 -> movable.sortedByDescending { appMap[it.pkg]?.installTime ?: 0L }
            else -> movable.sortedWith(compareBy({ it.page }, { it.y }, { it.x }))
        }
        for (i in movable) i.page = -1
        for (i in sorted) {
            var spot = store.findFree(0, 1, 1, cols, rows, i.id)
            if (spot == null) {
                store.pageCount++
                spot = intArrayOf(store.pageCount - 1, 0, 0)
            }
            i.page = spot[0]
            i.x = spot[1]
            i.y = spot[2]
        }
        store.trimTrailingPages()
        touched()
        store.save()
        renderAll()
    }

    // =====================================================================
    // Double-tap to lock
    // =====================================================================
    private fun handleDoubleTap(rawX: Float, rawY: Float) {
        if (!cfg.doubleTapLock || drawerOpen || editMode || folderOpen || shelfOpen) return
        val rl = IntArray(2)
        root.getLocationOnScreen(rl)
        val t = targetAt(rawX - rl[0], rawY - rl[1]) ?: return
        if (t.container != HOME) return
        if (store.itemAt(HOME, t.page, t.cx, t.cy, -1L) != null) return
        val svc = LockService.instance
        if (svc != null) {
            svc.lock()
        } else {
            AlertDialog.Builder(this)
                .setTitle("Turn on double-tap lock")
                .setMessage("Open Accessibility settings and switch on \"Color Launcher double-tap lock\".")
                .setPositiveButton("Open settings") { _, _ ->
                    startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
                }
                .setNegativeButton("Later", null)
                .show()
        }
    }

    // =====================================================================
    // App lock / private apps
    // =====================================================================
    private fun authenticate(title: String, onOk: () -> Unit) {
        val auth = if (Build.VERSION.SDK_INT >= 30) {
            BiometricManager.Authenticators.BIOMETRIC_WEAK or BiometricManager.Authenticators.DEVICE_CREDENTIAL
        } else {
            BiometricManager.Authenticators.BIOMETRIC_WEAK
        }
        if (BiometricManager.from(this).canAuthenticate(auth) != BiometricManager.BIOMETRIC_SUCCESS) {
            toast("Set up a screen lock or fingerprint in phone settings first")
            return
        }
        val prompt = BiometricPrompt(
            this, ContextCompat.getMainExecutor(this),
            object : BiometricPrompt.AuthenticationCallback() {
                override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) {
                    onOk()
                }
            }
        )
        val b = BiometricPrompt.PromptInfo.Builder()
            .setTitle(title)
            .setAllowedAuthenticators(auth)
        if (Build.VERSION.SDK_INT < 30) b.setNegativeButtonText("Cancel")
        prompt.authenticate(b.build())
    }

    // =====================================================================
    // Opening apps (with animations)
    // =====================================================================
    private fun launch(app: AppInfo, from: View) {
        if (app.pkg in cfg.lockedApps && unlockedOnce != app.pkg) {
            authenticate("Unlock " + app.label) {
                unlockedOnce = app.pkg
                launch(app, from)
                unlockedOnce = null
            }
            return
        }
        val intent = packageManager.getLaunchIntentForPackage(app.pkg) ?: return
        Usage.record(this, app.pkg)

        // remember where the icon is, for the closing animation
        val loc = IntArray(2)
        val rl = IntArray(2)
        from.getLocationOnScreen(loc)
        root.getLocationOnScreen(rl)
        val left = loc[0] - rl[0]
        val top = loc[1] - rl[1]
        lastRect = Rect(left, top, left + from.width, top + from.height)
        lastColor = averageColor(app.icon)

        val opts = when (cfg.openAnim) {
            "zoom" -> ActivityOptions.makeScaleUpAnimation(from, 0, 0, from.width, from.height)
            "fade" -> ActivityOptions.makeCustomAnimation(this, android.R.anim.fade_in, android.R.anim.fade_out)
            else -> ActivityOptions.makeCustomAnimation(this, 0, 0)
        }
        launched = true
        startActivity(intent, opts.toBundle())
        if (cfg.openAnim != "none") {
            home.animate().scaleX(0.9f).scaleY(0.9f).alpha(0f)
                .setDuration(cfg.dur(240)).withLayer().start()
        }
        home.removeCallbacks(restoreRunnable)
        home.postDelayed(restoreRunnable, 1500)
        if (drawerOpen) closeDrawer()
        if (shelfOpen) closeShelf()
        if (folderOpen) closeFolder()
        if (editMode) exitEditMode()
    }

    private fun lerp(a: Float, b: Float, t: Float) = a + (b - a) * t

    private fun playShrink() {
        val r = lastRect ?: return
        val w = max(1, r.width()).toFloat()
        val h = max(1, r.height()).toFloat()
        val fullW = root.width.toFloat()
        val fullH = root.height.toFloat()
        if (fullW == 0f || fullH == 0f) return

        val bg = GradientDrawable().apply { setColor(lastColor) }
        overlay.animate().cancel()
        overlay.layoutParams = FrameLayout.LayoutParams(w.toInt(), h.toInt())
        overlay.background = bg
        overlay.pivotX = 0f
        overlay.pivotY = 0f
        overlay.alpha = 1f
        overlay.visibility = View.VISIBLE
        val endRadius = w * 0.30f

        ValueAnimator.ofFloat(0f, 1f).apply {
            duration = cfg.dur(320)
            interpolator = DecelerateInterpolator(1.4f)
            addUpdateListener { a ->
                val t = a.animatedValue as Float
                overlay.scaleX = lerp(fullW / w, 1f, t)
                overlay.scaleY = lerp(fullH / h, 1f, t)
                overlay.translationX = lerp(0f, r.left.toFloat(), t)
                overlay.translationY = lerp(0f, r.top.toFloat(), t)
                bg.cornerRadius = lerp(0f, endRadius, t)
                overlay.alpha = if (t < 0.6f) 1f else 1f - (t - 0.6f) / 0.4f
            }
            addListener(object : AnimatorListenerAdapter() {
                override fun onAnimationEnd(animation: Animator) {
                    overlay.visibility = View.GONE
                }
            })
            start()
        }
    }

    // =====================================================================
    // Drawer / search
    // =====================================================================
    /** Sets up where the drawer starts and ends, depending on the chosen animation style and shape. */
    private fun prepareDrawer() {
        val w = root.width.toFloat()
        val h = root.height.toFloat()
        val sheet = cfg.drawerShape == "sheet"
        drawer.endRadius = if (sheet) dp(34).toFloat() else 0f
        drawer.endBleed = if (sheet) 0f else dp(10).toFloat()
        drawer.endTop = if (sheet) dp(46).toFloat() else Float.NaN
        drawer.revealZoom = cfg.drawerReveal == "zoom"
        drawer.panelFade = cfg.drawerStyle == "fade"
        when (cfg.drawerStyle) {
            "slide" -> {
                drawer.startRect.set(0f, h, w, h + dp(40))
                drawer.startRadius = drawer.endRadius
            }
            "zoom" -> {
                val cx = w / 2f
                val cy = h * 0.6f
                drawer.startRect.set(cx - dp(70), cy - dp(70), cx + dp(70), cy + dp(70))
                drawer.startRadius = dp(70).toFloat()
            }
            "fade" -> {
                val top = if (sheet) dp(46).toFloat() else -drawer.endBleed
                drawer.startRect.set(-drawer.endBleed, top, w + drawer.endBleed, h + drawer.endBleed)
                drawer.startRadius = drawer.endRadius
            }
            else -> {
                // liquid: exactly on top of the dock
                val r = if (dockHolder.visibility == View.VISIBLE && dockHolder.width > 0) {
                    rectOf(dockHolder)
                } else {
                    Rect(dp(12), root.height - dp(150), root.width - dp(12), root.height - dp(60))
                }
                drawer.startRect.set(r.left.toFloat(), r.top.toFloat(), r.right.toFloat(), r.bottom.toFloat())
                drawer.startRadius = dp(32).toFloat()
            }
        }
        drawer.visibility = View.VISIBLE
        refreshDrawerResults()
    }

    private fun openDrawer() {
        if (drawerOpen || editMode || folderOpen || shelfOpen) return
        prepareDrawer()
        settleDrawer(true, 0f)
    }

    private fun closeDrawer() {
        if (!drawerOpen) return
        settleDrawer(false, 0f)
    }

    /** Lets the drawer glide to open or closed with a springy, liquid finish. */
    private fun settleDrawer(open: Boolean, velocityPx: Float) {
        drawerAnim?.cancel()
        drawerOpen = open
        if (open) {
            drawer.visibility = View.VISIBLE
        } else {
            if (drawerPrivate) {
                drawerPrivate = false
                refreshLists()
            }
            categoryFilter = "all"
            search.setText("")
            search.clearFocus()
            hideKeyboard(search)
        }
        if (cfg.drawerHaptic) drawer.performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK)
        val sa = SpringAnimation(drawer, MorphLayout.PROGRESS, if (open) 1f else 0f)
        // the progress runs from 0 to 1, so the spring must notice tiny steps (the default would end it instantly)
        sa.setMinimumVisibleChange(0.001f)
        sa.spring.setStiffness(cfg.drawerStiffness).setDampingRatio(cfg.drawerDamping)
        // positive velocity = opening
        sa.setStartVelocity(velocityPx / max(1f, root.height * cfg.drawerPullFraction))
        sa.addEndListener { _, canceled, _, _ ->
            if (!canceled && !open) {
                drawer.visibility = View.INVISIBLE
                drawer.progress = 0f
                dockHolder.alpha = 1f
            }
        }
        drawerAnim = sa
        sa.start()
    }

    private fun canPullOpen(x: Float, y: Float): Boolean {
        if (editMode || folderOpen || shelfOpen || drawerOpen) return false
        val mode = cfg.drawerGesture
        if (mode == "off") return false
        val rl = IntArray(2)
        root.getLocationOnScreen(rl)
        val ly = y - rl[1]
        if (mode == "anywhere") return ly > root.height * 0.15f
        val top = if (dockHolder.visibility == View.VISIBLE && dockHolder.width > 0) {
            rectOf(dockHolder).top - dp(70)
        } else {
            (root.height * 0.82f).toInt()
        }
        return ly >= top
    }

    private fun startPull(mode: Int, ev: MotionEvent) {
        gestureMode = mode
        touchedGlass?.let { releaseGlass(it) }
        touchedGlass = null
        // cancel whatever the apps under the finger were doing with this touch
        val c = MotionEvent.obtain(ev)
        c.action = MotionEvent.ACTION_CANCEL
        window.superDispatchTouchEvent(c)
        c.recycle()
        hideKeyboard(search)
        drawerAnim?.cancel()
        if (mode == 1) {
            prepareDrawer()
            drawerOpen = true
        }
    }

    /** Swipe the dock up to open the drawer, pull the drawer down to close it. The glass follows your finger. */
    private fun handleDrawerGesture(ev: MotionEvent): Boolean {
        val slop = ViewConfiguration.get(this).scaledTouchSlop
        when (ev.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                gStartX = ev.rawX
                gStartY = ev.rawY
                gestureMode = 0
                velocity?.recycle()
                velocity = VelocityTracker.obtain()
                velocity?.addMovement(ev)
                gArmed = if (drawerOpen) {
                    val onIndex = rectOf(alphaIndex).contains(ev.rawX.toInt(), ev.rawY.toInt())
                    !folderOpen && !shelfOpen && !editMode && !onIndex
                } else {
                    cfg.swipeUp && canPullOpen(ev.rawX, ev.rawY)
                }
                return false
            }
            MotionEvent.ACTION_MOVE -> {
                velocity?.addMovement(ev)
                val dy = ev.rawY - gStartY
                val dx = ev.rawX - gStartX
                if (gestureMode == 0 && gArmed) {
                    if (!drawerOpen && dy < -slop && abs(dy) > abs(dx) * 1.3f) {
                        startPull(1, ev)
                    } else if (drawerOpen && dy > slop && abs(dy) > abs(dx) * 1.3f && !drawerList.canScrollVertically(-1)) {
                        startPull(2, ev)
                    }
                }
                val dist = max(dp(240), (root.height * cfg.drawerPullFraction).toInt()).toFloat()
                if (gestureMode == 1) {
                    drawer.progress = ((-dy - slop) / dist).coerceIn(0f, 1f)
                    return true
                }
                if (gestureMode == 2) {
                    drawer.progress = (1f - (dy - slop) / dist).coerceIn(0f, 1f)
                    return true
                }
                return false
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                val mode = gestureMode
                var vy = 0f
                velocity?.let {
                    it.computeCurrentVelocity(1000)
                    vy = it.yVelocity
                }
                velocity?.recycle()
                velocity = null
                gArmed = false
                gestureMode = 0
                if (mode == 1 || mode == 2) {
                    val open = when {
                        ev.actionMasked == MotionEvent.ACTION_CANCEL -> drawerProgress > 0.5f
                        vy < -900f -> true
                        vy > 900f -> false
                        else -> drawerProgress > 0.5f
                    }
                    settleDrawer(open, -vy)
                    return true
                }
                return false
            }
        }
        return false
    }

    /** Search results, extras (calculator, units, contacts, web), suggestions and A-Z index. */
    private fun refreshDrawerResults() {
        val q = search.text.toString().trim()
        val src = if (q.isEmpty()) drawerSource() else (if (drawerPrivate) allApps.filter { it.pkg in cfg.hiddenApps } else visibleApps)
        drawerAdapter.submit(if (q.isEmpty()) src else src.filter { it.label.lowercase().contains(q.lowercase()) })
        renderCategories()
        updateExtras(q)
        val empty = q.isEmpty() && !drawerPrivate
        alphaIndex.visibility = if (empty && cfg.sortOrder == "name") View.VISIBLE else View.GONE
        renderSuggested(empty)
    }

    private fun smallAppView(app: AppInfo): View {
        val v = layoutInflater.inflate(R.layout.item_app, null, false)
        v.layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        val icon = v.findViewById<ImageView>(R.id.icon)
        val px = dp(cfg.iconSize - 8)
        icon.layoutParams = icon.layoutParams.apply {
            width = px
            height = px
        }
        icon.setImageDrawable(app.icon)
        val label = v.findViewById<TextView>(R.id.label)
        label.text = app.label
        label.textSize = 11f
        v.pressFeedback(cfg.pressEffect)
        v.setOnClickListener { launch(app, icon) }
        v.setOnLongClickListener { startAppDrag(app, v, -1L); true }
        return v
    }

    private fun renderSuggested(show: Boolean) {
        suggestRow.removeAllViews()
        val list = if (show && cfg.showSuggested) {
            Usage.top(this, 5).mapNotNull { appMap[it] }.filter { it.pkg !in cfg.hiddenApps }
        } else {
            emptyList()
        }
        if (list.isEmpty()) {
            suggestRow.visibility = View.GONE
            return
        }
        suggestRow.visibility = View.VISIBLE
        for (app in list) suggestRow.addView(smallAppView(app))
        for (i in list.size until 5) suggestRow.addView(View(this), LinearLayout.LayoutParams(0, 1, 1f))
    }

    private fun extraRow(label: String, iconRes: Int, action: () -> Unit): View {
        val t = TextView(this)
        t.text = label
        t.setCompoundDrawablesRelativeWithIntrinsicBounds(iconRes, 0, 0, 0)
        t.compoundDrawablePadding = dp(12)
        t.gravity = Gravity.CENTER_VERTICAL
        t.setTextColor(Color.WHITE)
        t.textSize = 15f
        t.setPadding(dp(18), dp(12), dp(18), dp(12))
        t.background = UiStyle.panel(this, cfg.uiStyle, 20f, cfg.glassStrength, t)
        val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        lp.setMargins(dp(16), 0, dp(16), dp(8))
        t.layoutParams = lp
        t.setOnClickListener { action() }
        return t
    }

    private fun updateExtras(q: String) {
        searchExtras.removeAllViews()
        if (q.isEmpty() || drawerPrivate) {
            searchExtras.visibility = View.GONE
            return
        }
        val rows = mutableListOf<Triple<String, Int, () -> Unit>>()
        QuickSearch.calculate(q)?.let { res ->
            rows.add(Triple("$res    (tap to copy)", R.drawable.ic_equals, { copyText(res) }))
        }
        QuickSearch.convert(q)?.let { res ->
            rows.add(Triple("$res    (tap to copy)", R.drawable.ic_swap, { copyText(res) }))
        }
        if (cfg.searchContacts) {
            if (hasContacts()) {
                for (c in findContacts(q)) rows.add(Triple(c.first, R.drawable.ic_person, { openContact(c.second) }))
            } else {
                rows.add(Triple("Tap to allow contacts in search", R.drawable.ic_person, { reqContacts.launch(Manifest.permission.READ_CONTACTS) }))
            }
        }
        rows.add(Triple("Search the web for “$q”", R.drawable.ic_globe, { webSearch(q) }))
        for ((label, icon, action) in rows) searchExtras.addView(extraRow(label, icon, action))
        searchExtras.visibility = View.VISIBLE
    }

    private fun copyText(s: String) {
        (getSystemService(CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText("result", s))
        toast("Copied")
    }

    private fun hasContacts(): Boolean =
        ContextCompat.checkSelfPermission(this, Manifest.permission.READ_CONTACTS) == PackageManager.PERMISSION_GRANTED

    private fun findContacts(q: String): List<Pair<String, Uri>> {
        val out = mutableListOf<Pair<String, Uri>>()
        try {
            contentResolver.query(
                ContactsContract.Contacts.CONTENT_URI,
                arrayOf(
                    ContactsContract.Contacts._ID,
                    ContactsContract.Contacts.LOOKUP_KEY,
                    ContactsContract.Contacts.DISPLAY_NAME_PRIMARY
                ),
                ContactsContract.Contacts.DISPLAY_NAME_PRIMARY + " LIKE ?",
                arrayOf("%$q%"),
                ContactsContract.Contacts.DISPLAY_NAME_PRIMARY + " ASC LIMIT 3"
            )?.use { c ->
                while (c.moveToNext()) {
                    out.add(Pair(c.getString(2) ?: "", ContactsContract.Contacts.getLookupUri(c.getLong(0), c.getString(1))))
                }
            }
        } catch (e: Exception) {
            // ignore
        }
        return out
    }

    private fun openContact(uri: Uri) {
        try {
            startActivity(Intent(Intent.ACTION_VIEW, uri))
        } catch (e: Exception) {
            toast("Could not open contact")
        }
    }

    private fun webSearch(q: String) {
        try {
            startActivity(Intent(Intent.ACTION_WEB_SEARCH).putExtra(SearchManager.QUERY, q))
        } catch (e: Exception) {
            try {
                startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=" + Uri.encode(q))))
            } catch (e2: Exception) {
                toast("No browser found")
            }
        }
    }

    // =====================================================================
    // Shelf (swipe right on the first page)
    // =====================================================================
    private fun tryStart(i: Intent) {
        try {
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            startActivity(i)
        } catch (e: Exception) {
            toast("Not available on this phone")
        }
    }

    private fun toggleTorch() {
        try {
            val cm = getSystemService(Context.CAMERA_SERVICE) as CameraManager
            val id = cm.cameraIdList.firstOrNull {
                cm.getCameraCharacteristics(it).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
            } ?: return
            torchOn = !torchOn
            cm.setTorchMode(id, torchOn)
        } catch (e: Exception) {
            toast("Torch not available")
        }
    }

    private fun shelfCard(text: String, iconRes: Int, onClick: (() -> Unit)?): TextView {
        val t = TextView(this)
        t.text = text
        if (iconRes != 0) {
            t.setCompoundDrawablesRelativeWithIntrinsicBounds(iconRes, 0, 0, 0)
            t.compoundDrawablePadding = dp(12)
            t.gravity = Gravity.CENTER_VERTICAL
        }
        t.setTextColor(Color.WHITE)
        t.textSize = 15f
        t.setPadding(dp(18), dp(14), dp(18), dp(14))
        t.background = UiStyle.panel(this, cfg.uiStyle, 22f, cfg.glassStrength, t)
        val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        lp.setMargins(dp(16), dp(6), dp(16), dp(6))
        t.layoutParams = lp
        if (onClick != null) t.setOnClickListener { onClick() }
        return t
    }

    private fun shelfTitle(text: String): TextView {
        val t = TextView(this)
        t.text = text
        t.setTextColor(0xCCFFFFFF.toInt())
        t.textSize = 14f
        t.setPadding(dp(24), dp(18), dp(24), dp(4))
        return t
    }

    private fun appRow(apps: List<AppInfo>): View {
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.setPadding(dp(12), 0, dp(12), 0)
        for (app in apps) {
            val v = smallAppView(app)
            v.setOnClickListener {
                closeShelf()
                launch(app, v.findViewById(R.id.icon))
            }
            row.addView(v)
        }
        for (i in apps.size until 4) row.addView(View(this), LinearLayout.LayoutParams(0, 1, 1f))
        return row
    }

    private fun buildShelf() {
        shelfContent.removeAllViews()
        val title = TextView(this)
        title.text = "Shelf"
        title.setTextColor(Color.WHITE)
        title.textSize = 30f
        title.typeface = Typeface.create("sans-serif-light", Typeface.NORMAL)
        title.setPadding(dp(24), dp(24), dp(24), dp(8))
        shelfContent.addView(title)

        shelfContent.addView(shelfCard("Search apps, contacts, web", R.drawable.ic_search) {
            closeShelf()
            openDrawer()
        })

        // quick actions
        val actions = LinearLayout(this)
        actions.orientation = LinearLayout.HORIZONTAL
        actions.setPadding(dp(12), dp(6), dp(12), dp(6))
        val quick = listOf<Triple<String, Int, () -> Unit>>(
            Triple("Torch", R.drawable.ic_torch, { toggleTorch() }),
            Triple("Calc", R.drawable.ic_calc, {
                tryStart(Intent.makeMainSelectorActivity(Intent.ACTION_MAIN, Intent.CATEGORY_APP_CALCULATOR))
            }),
            Triple("Camera", R.drawable.ic_camera, { tryStart(Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA)) }),
            Triple("Clock", R.drawable.ic_clock, { tryStart(Intent(AlarmClock.ACTION_SHOW_ALARMS)) }),
            Triple("Settings", R.drawable.ic_settings, { tryStart(Intent(Settings.ACTION_SETTINGS)) })
        )
        for ((label, iconRes, action) in quick) {
            val b = TextView(this)
            b.text = label
            b.setCompoundDrawablesWithIntrinsicBounds(0, iconRes, 0, 0)
            b.compoundDrawablePadding = dp(6)
            b.gravity = Gravity.CENTER
            b.setTextColor(Color.WHITE)
            b.textSize = 12f
            b.setPadding(0, dp(12), 0, dp(12))
            b.background = UiStyle.panel(this, cfg.uiStyle, 20f, cfg.glassStrength, b)
            val lp = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            lp.setMargins(dp(4), 0, dp(4), 0)
            b.layoutParams = lp
            b.setOnClickListener { action() }
            actions.addView(b)
        }
        shelfContent.addView(actions)

        // today
        shelfContent.addView(shelfTitle("TODAY"))
        if (glance.weatherText.isNotEmpty()) shelfContent.addView(shelfCard(glance.weatherText.replace("\n", "  ·  "), glance.weatherIcon, null))
        if (glance.calendarText.isNotEmpty()) shelfContent.addView(shelfCard(glance.calendarText.replace("\n", "  ·  "), R.drawable.ic_calendar, null))
        if (glance.batteryText.isNotEmpty()) shelfContent.addView(shelfCard(glance.batteryText.replace("\n", "  ·  "), R.drawable.ic_battery, null))

        val frequent = Usage.top(this, 8).mapNotNull { appMap[it] }.filter { it.pkg !in cfg.hiddenApps }
        if (frequent.isNotEmpty()) {
            shelfContent.addView(shelfTitle("FREQUENTLY USED"))
            frequent.chunked(4).forEach { shelfContent.addView(appRow(it)) }
        }
        val recent = Usage.recent(this, 8).mapNotNull { appMap[it] }.filter { it.pkg !in cfg.hiddenApps }
        if (recent.isNotEmpty()) {
            shelfContent.addView(shelfTitle("RECENT"))
            recent.chunked(4).forEach { shelfContent.addView(appRow(it)) }
        }
    }

    private fun openShelf() {
        if (shelfOpen || drawerOpen || editMode || folderOpen) return
        shelfOpen = true
        buildShelf()
        shelf.visibility = View.VISIBLE
        shelf.animate().cancel()
        shelf.translationX = -root.width.toFloat()
        val sa = SpringAnimation(shelf, DynamicAnimation.TRANSLATION_X, 0f)
        sa.spring.setStiffness(SpringForce.STIFFNESS_LOW).setDampingRatio(0.85f)
        shelfSpring = sa
        sa.start()
        refreshBlur()
    }

    private fun closeShelf() {
        if (!shelfOpen) return
        shelfOpen = false
        refreshBlur()
        shelfSpring?.cancel()
        shelf.animate().translationX(-root.width.toFloat()).setDuration(cfg.dur(220))
            .withLayer().withEndAction { shelf.visibility = View.GONE }.start()
    }
}
